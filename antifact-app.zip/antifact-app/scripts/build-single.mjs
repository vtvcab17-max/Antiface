// Gộp public/ thành MỘT file dist/antifact.html (mở trực tiếp bằng trình duyệt, không cần máy chủ).
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const pub = join(fileURLToPath(new URL('.', import.meta.url)), '..', 'public');
const out = join(pub, '..', 'dist');
let html = await readFile(join(pub, 'index.html'), 'utf8');
const css = await readFile(join(pub, 'css/style.css'), 'utf8');
const js = await readFile(join(pub, 'js/app.js'), 'utf8');
html = html
  .replace('<link rel="stylesheet" href="/css/style.css">', () => `<style>\n${css}</style>`)
  .replace('<script src="/js/app.js"></script>', () => `<script>\n${js.replace(/<\/script/gi, '<\\/script')}</script>`)
  .replace(/<script src="\/js\/register-sw.js"><\/script>\n?/, '')
  .replace(/<link rel="(manifest|apple-touch-icon|icon)"[^>]*>\n?/g, '');
await mkdir(out, { recursive: true });
await writeFile(join(out, 'antifact.html'), html);
console.log('Đã tạo dist/antifact.html (' + Math.round(html.length / 1024) + ' KB)');
