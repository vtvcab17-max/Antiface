# Antifact 1.1

Chỉnh ảnh, thiết kế (kiểu Photoshop + Canva) và làm slide camera 2D / 2.5D / 3D ngay trên trình duyệt. Xuất project để ném thẳng sang **Bravin**, mỗi layer nằm trên một track riêng.

Đây là web app tĩnh (HTML + CSS + JS thuần, không cần build). Mọi thứ nằm trong `public/`.

```
public/
  index.html            giao diện
  css/style.css         style
  js/app.js             toàn bộ logic (editor, slide, camera, timeline, xuất video / GIF)
  js/register-sw.js     đăng ký service worker (chạy offline)
  sw.js                 service worker
  manifest.webmanifest  cài như app (PWA)
  icons/                icon app
  _headers              header cache / bảo mật cho Cloudflare
wrangler.toml           cấu hình Cloudflare
.github/workflows/deploy.yml   tự deploy khi push lên main
scripts/                serve.mjs (chạy thử), build-single.mjs (gộp 1 file)
```

## 1. Chạy thử trên máy

```bash
node scripts/serve.mjs          # mở http://localhost:8787
```

Hoặc `npx serve public`. Không mở bằng `file://` vì service worker và PWA cần http(s).

## 2. Đẩy lên GitHub

Tạo repo trống trên github.com (ví dụ `bravinall/antifact`, không tick thêm README), rồi:

```bash
cd antifact
git init -b main
git add .
git commit -m "Antifact 1.1"
git remote add origin https://github.com/<ten-ban>/antifact.git
git push -u origin main
```

## 3. Deploy lên Cloudflare

### Cách A: GitHub Actions (khuyên dùng, giống Bravin)

1. Cloudflare Dashboard → **My Profile → API Tokens → Create Token**, chọn mẫu **Edit Cloudflare Workers**, tạo xong copy token.
2. Lấy **Account ID** ở trang **Workers & Pages** (cột phải).
3. Trên GitHub: repo → **Settings → Secrets and variables → Actions → New repository secret**, thêm 2 secret:
   - `CLOUDFLARE_API_TOKEN`
   - `CLOUDFLARE_ACCOUNT_ID`
4. Push lên `main` (hoặc **Actions → Deploy Antifact → Run workflow**). Workflow chạy `wrangler deploy` và app lên tại `https://antifact.<tài-khoản>.workers.dev`.

### Cách B: Kết nối repo trong Cloudflare (không cần secret)

**Workers & Pages → Create → Import a repository**, chọn repo `antifact`. Build command để trống, deploy command `npx wrangler deploy`. Mỗi lần push Cloudflare tự deploy.

### Cách C: Deploy tay từ máy

```bash
npm install
npx wrangler login
npx wrangler deploy
```

### Tên miền riêng

Cloudflare Dashboard → Workers & Pages → `antifact` → **Settings → Domains & Routes → Add → Custom domain** (ví dụ `antifact.bravinall.com`).

> Nếu bạn muốn dùng **Cloudflare Pages** thay cho Workers: tạo Pages project từ repo, Build command để trống, Build output directory là `public`. File `_headers` đã tương thích.

## 4. Phát hành bản mới

Sửa code trong `public/`, đổi `VERSION` trong `public/sw.js` (ví dụ `antifact-1.1.1`) để người dùng nhận bản mới, rồi `git push`.

## 5. Bản một file

```bash
npm run build:single            # tạo dist/antifact.html
```

File này mở trực tiếp bằng trình duyệt, gửi qua chat hoặc nhúng ở đâu cũng được (không có chế độ offline / cài app).

## Lưu ý khi chạy

- Font Google và nhiều tính năng AI cần internet. Dữ liệu project lưu trong trình duyệt của từng người dùng (không có server).
- Trợ lý AI dùng API key do người dùng tự nhập (hoặc AI local), key không đi qua server nào của Antifact.
- Xuất MP4 cần trình duyệt hỗ trợ H.264 (Chrome / Edge / Safari); nếu không sẽ xuất WebM. Xuất video chạy thời gian thực nên phải giữ tab mở.
- Chế độ Không gian cần WebGL.
