"use strict";
/* ---------- icons ---------- */
const P={select:'<path d="M5 3l14 7-6 2-2 6z"/>',text:'<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',rect:'<rect x="4" y="5" width="16" height="14" rx="2"/>',ellipse:'<ellipse cx="12" cy="12" rx="8" ry="7"/>',brush:'<path d="M18 3l3 3-9 9-3-3zM9 15c-3 0-4 2-4 4 0 1 0 2-1 2 3 1 7 0 7-4"/>',eraser:'<path d="M7 20h13M5 14l8-9 6 6-6 7H8z"/>',image:'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M4 18l5-5 4 4 3-3 4 4"/>',undo:'<path d="M9 14L4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3"/>',redo:'<path d="M15 14l5-5-5-5M20 9H10a6 6 0 0 0 0 12h3"/>',eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',eyeoff:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><path d="M4 4l16 16"/>',lock:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',unlock:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7-2.6"/>',trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',copy:'<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/>',up:'<path d="M12 19V5M6 11l6-6 6 6"/>',down:'<path d="M12 5v14M6 13l6 6 6-6"/>',send:'<path d="M5 12h14M13 6l6 6-6 6"/>',plus:'<path d="M12 5v14M5 12h14"/>',minus:'<path d="M5 12h14"/>',dl:'<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',folder:'<path d="M3 7h6l2 2h10v10H3z"/>',fit:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',flipH:'<path d="M12 3v18M8 7l-5 5 5 5zM16 7l5 5-5 5z"/>',flipV:'<path d="M3 12h18M7 8l5-5 5 5zM7 16l5 5 5-5z"/>',
'al-l':'<path d="M4 4v16M8 8h12M8 14h8"/>','al-c':'<path d="M12 4v16M6 8h12M8 14h8"/>','al-r':'<path d="M20 4v16M4 8h12M8 14h8"/>','al-t':'<path d="M4 4h16M8 8v12M14 8v8"/>','al-m':'<path d="M4 12h16M8 6v12M14 8v8"/>','al-b':'<path d="M4 20h16M8 4v12M14 8v8"/>',
'ta-left':'<path d="M4 6h16M4 10h10M4 14h16M4 18h10"/>','ta-center':'<path d="M4 6h16M7 10h10M4 14h16M7 18h10"/>','ta-right':'<path d="M4 6h16M10 10h10M4 14h16M10 18h10"/>',layers:'<path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5"/>',chev:'<path d="M6 9l6 6 6-6"/>',spark:'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.7 1.8 1.8.7-1.8.7L19 21l-.7-1.8-1.8-.7 1.8-.7z"/>',home:'<path d="M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"/>',more:'<circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/>',grid:'<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',rows:'<path d="M4 6h16M4 12h16M4 18h16"/>',sortdir:'<path d="M8 4v16M4 16l4 4 4-4M16 20V4M12 8l4-4 4 4"/>'};
Object.assign(P,{marq:'<rect x="4" y="5" width="16" height="14" rx="1" stroke-dasharray="3 3"/>',lasso:'<path d="M12 4c5 0 8 2 8 5s-3 5-8 5-8-2-8-5 3-5 8-5z" stroke-dasharray="3 2.5"/><path d="M9 13c0 3-1 4-3 5 2 1 4 0 4-2"/>',qsel:'<circle cx="10" cy="10" r="6" stroke-dasharray="2.5 2.5"/><path d="M14.5 14.5L21 21"/>',wand:'<path d="M4 20L16 8M15 4v3M20 9h-3M18 5l-1.5 1.5M9 3v2M3 9h2"/>',razor:'<path d="M3 19L19 3l2 2L5 21zM14 8l2 2"/>',x:'<path d="M6 6l12 12M18 6L6 18"/>',crop:'<path d="M6 2v14a2 2 0 0 0 2 2h14M2 6h14a2 2 0 0 1 2 2v14"/>',dropper:'<path d="M20 4a2.1 2.1 0 0 0-3 0l-3 3-1-1-2 2 1 1-7 7v3h3l7-7 1 1 2-2-1-1 3-3a2.1 2.1 0 0 0 0-3z"/>',gradient:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9v6M11 8v8M15 7v10M19 9v6" opacity=".7"/>',hand:'<path d="M8 13V5.5a1.5 1.5 0 0 1 3 0V12M11 11V4.5a1.5 1.5 0 0 1 3 0V12M14 11V6.5a1.5 1.5 0 0 1 3 0V14M17 10.5a1.5 1.5 0 0 1 3 0V15a6 6 0 0 1-6 6h-1.5a6 6 0 0 1-5-2.7L5 14.5a1.5 1.5 0 0 1 2.4-1.8L8 13.5"/>',zoomt:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21M10.5 8v5M8 10.5h5"/>',swap:'<path d="M8 4L4 8l4 4M4 8h12M16 20l4-4-4-4M20 16H8"/>',dflt:'<rect x="4" y="4" width="10" height="10" rx="1.5"/><rect x="10" y="10" width="10" height="10" rx="1.5" fill="currentColor"/>'});
const ic=n=>`<svg class="i" viewBox="0 0 24 24" aria-hidden="true">${P[n]||''}</svg>`;
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

/* ---------- state ---------- */
const BLEND={normal:'source-over',multiply:'multiply',screen:'screen',overlay:'overlay',darken:'darken',lighten:'lighten','color-dodge':'color-dodge','soft-light':'soft-light',difference:'difference','color-burn':'color-burn','hard-light':'hard-light',exclusion:'exclusion',hue:'hue',saturation:'saturation',color:'color',luminosity:'luminosity',add:'lighter',pass:'source-over'};
const BLEND_VI={normal:'Bình thường',multiply:'Multiply',screen:'Screen',overlay:'Overlay',darken:'Darken',lighten:'Lighten','color-dodge':'Color Dodge','soft-light':'Soft Light',difference:'Difference','color-burn':'Color Burn','hard-light':'Hard Light',exclusion:'Exclusion',hue:'Hue',saturation:'Saturation',color:'Color',luminosity:'Luminosity',add:'Linear Dodge (Add)',pass:'Xuyên qua (nhóm)'};
const FONTS=['Bricolage Grotesque','Outfit','Be Vietnam Pro','Anton','Playfair Display','Pacifico','Lobster','JetBrains Mono'];
const PRESETS=[['Bản trình bày (Slide) 16:9',1920,1080],['Thumbnail YouTube',1280,720],['Bài đăng Instagram',1080,1080],['Story / Reels',1080,1920],['Ảnh bìa Facebook',1640,624],['Full HD',1920,1080],['A4 (300 dpi)',2480,3508],['Banner 3:1',1500,500]];
const customFonts={};
function regFont(name,url){return new FontFace(name,`url(${url})`,{weight:'100 900'}).load().then(f=>{document.fonts.add(f);customFonts[name]=url;if(!FONTS.includes(name))FONTS.push(name);return name})}
function saveFonts(){try{localStorage.setItem('af-fonts',JSON.stringify(customFonts))}catch(e){toast('Trình duyệt không cho nhớ font này (hết dung lượng hoặc bị chặn), nhưng font vẫn được lưu cùng project.')}}
async function importFonts(files){let last=null;
  for(const f of [...files]){if(!/\.(ttf|otf|woff2?)$/i.test(f.name)){toast('Chỉ nhận font .ttf .otf .woff .woff2');continue}
    const url=await new Promise(r=>{const fr=new FileReader();fr.onload=()=>r(fr.result);fr.onerror=()=>r(null);fr.readAsDataURL(f)});
    const name=f.name.replace(/\.[^.]+$/,'').replace(/[-_]+/g,' ').replace(/["<>&]/g,'').trim().slice(0,40)||'Font tùy chọn';
    try{last=await regFont(name,url)}catch(e){toast('Không đọc được font '+f.name)}}
  if(!last)return;saveFonts();const l=cur();
  if(l&&l.type==='text'){l.font=last;render();commit(true,'Đổi font')}else{buildProps();toast('Đã thêm font '+last)}}
try{const o=JSON.parse(localStorage.getItem('af-fonts')||'{}');Object.entries(o).forEach(([n,u])=>regFont(n,u).then(()=>{if(typeof render==='function'){render();if(typeof buildProps==='function')buildProps()}}).catch(()=>{}))}catch(e){}
const F0={brightness:100,contrast:100,saturate:100,hue:0,blur:0,gray:0,sepia:0};
const FILTER_PRESETS={'Gốc':{},'Sáng':{brightness:115,contrast:105,saturate:110},'Trắng đen':{gray:100,contrast:115},'Cổ điển':{sepia:60,contrast:92,saturate:85},'Lạnh':{hue:-12,saturate:110,brightness:102},'Ấm':{hue:10,sepia:25,saturate:115},'Tương phản':{contrast:150,saturate:120},'Mờ ảo':{blur:3,brightness:108,saturate:115}};
const NAMES={rect:'Hình chữ nhật',ellipse:'Hình tròn',text:'Chữ',image:'Ảnh',draw:'Nét vẽ',group:'Nhóm',adjust:'Điều chỉnh'};
const DEF={rect:{fill:'#ff4f99',grad:false,fill2:'#ffd43b',stroke:'#ffffff',sw:0,radius:0},ellipse:{fill:'#2fd0ee',grad:false,fill2:'#ffd43b',stroke:'#ffffff',sw:0},text:{text:'Nhập chữ',font:'Bricolage Grotesque',size:96,weight:700,align:'left',color:'#ffffff',stroke:'#000000',sw:0,ls:0,lh:1.15},image:{radius:0},draw:{}};

let doc={name:'Mẫu thumbnail',w:1280,h:720,bg:'#0c0d12'};
let layers=[],sel=null,tool='select',zoom=1,autoFit=true;
const brush={size:28,color:'#ff4f99'};
const store=new Map(),cache=new Map(),paint=new Map(),cnt={};
let seq=0;const uid=()=>'l'+(++seq)+Math.random().toString(36).slice(2,5);
let hist=[],hi=-1;
var msk=null,mskB=null,mskVer=0,selMode='new',marqShape='rect',tolV=32,contig=true,qsz=60,razorAll=false,antKey='',antRaf=0,hnames=[],bgc='#ffffff',snapOn=true,gridOn=false,gridSize=50,crop=null,cropRatio=null,paTab='sw',clip=null,lastPick=null,mySw=[],navT=0,menuEl=null,menuBtn=null;

const cur=()=>layers.find(l=>l.id===sel)||null;
const rgba=(h,a)=>{const n=parseInt(h.slice(1),16);return `rgba(${n>>16&255},${n>>8&255},${n&255},${a})`};
const fontStr=l=>`${l.italic?'italic ':''}${l.weight} ${l.size}px "${l.font}"`;
const keyId=()=>'a'+(++seq)+Math.random().toString(36).slice(2,6);

function getImg(key){let e=cache.get(key);if(!e){const im=new Image();e={im,ready:false};im.onload=()=>{e.ready=true;render();renderLayers()};im.src=store.get(key)||'';cache.set(key,e)}return e}

/* ---------- history ---------- */
const snap=()=>JSON.stringify({doc,layers,sel,deck:deck?{cur:deck.cur,slides:deck.slides.map((s,i)=>i===deck.cur?{...s,layers:null}:s)}:null},(k,v)=>k[0]==='_'?undefined:v);
function pushHist(label){hist=hist.slice(0,hi+1);hnames=hnames.slice(0,hi+1);hist.push(snap());hnames.push(label||'Chỉnh sửa');if(hist.length>80){hist.shift();hnames.shift()}hi=hist.length-1;updHistBtns()}
function loadSnap(s){const o=JSON.parse(s);doc=o.doc;layers=o.layers;deck=o.deck||null;if(deck){const c=deck.slides[deck.cur];c.layers=layers;c.bg=doc.bg;deck.slides.forEach(x=>{if(!x.layers)x.layers=[]})}sel=layers.some(l=>l.id===o.sel)?o.sel:null;paint.clear();syncDocUi();refresh()}
function undo(){if(hi>0){hi--;loadSnap(hist[hi]);updHistBtns()}}
function redo(){if(hi<hist.length-1){hi++;loadSnap(hist[hi]);updHistBtns()}}
function updHistBtns(){if(typeof renderHist==='function')renderHist();$('#undo').disabled=hi<=0;$('#redo').disabled=hi>=hist.length-1;if(typeof scheduleSave==='function')scheduleSave()}
function commit(rebuild=true,label){pushHist(label);refresh(rebuild)}
function refresh(rebuild=true){render();renderLayers();if(rebuild)buildProps();if(typeof stripSync==='function')stripSync();$('#hint').hidden=layers.length>0&&false}

/* ---------- drawing ---------- */
const ctx=$('#cv').getContext('2d');
const mctx=document.createElement('canvas').getContext('2d');
function layoutText(l){if(typeof gfEnsure==='function')gfEnsure(l.font);mctx.font=fontStr(l);if('letterSpacing' in mctx)mctx.letterSpacing=l.ls+'px';
  const lines=[];for(const para of (l.caps?String(l.text).toUpperCase():String(l.text)).split('\n')){let line='';for(const wd of para.split(' ')){const t=line?line+' '+wd:wd;if(line&&mctx.measureText(t).width>l.w){lines.push(line);line=wd}else line=t}lines.push(line)}
  l._lines=lines;l.h=Math.max(1,lines.length)*l.size*l.lh;return lines}
function rr(c,x,y,w,h,r){r=Math.max(0,Math.min(r,w/2,h/2));c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath()}
function filterStr(l){const f=l.f,a=[];
  if(f.brightness!==100)a.push(`brightness(${f.brightness}%)`);if(f.contrast!==100)a.push(`contrast(${f.contrast}%)`);if(f.saturate!==100)a.push(`saturate(${f.saturate}%)`);
  if(f.hue)a.push(`hue-rotate(${f.hue}deg)`);if(f.gray)a.push(`grayscale(${f.gray}%)`);if(f.sepia)a.push(`sepia(${f.sepia}%)`);if(f.blur)a.push(`blur(${f.blur}px)`);
  return a.join(' ')||'none'}
function drawLayer(c,l,plain,noSh){
  if(l.type==='text')layoutText(l);
  c.save();
  c.globalAlpha=plain?1:l.opacity;
  c.globalCompositeOperation=plain?'source-over':(BLEND[l.blend]||'source-over');
  c.filter=filterStr(l);
  if(l.sh.on&&!noSh){c.shadowColor=rgba(l.sh.color,l.sh.a);c.shadowBlur=l.sh.blur;c.shadowOffsetX=l.sh.x;c.shadowOffsetY=l.sh.y}
  c.translate(l.x+l.w/2,l.y+l.h/2);c.rotate(l.rot*Math.PI/180);c.scale(l.flipX?-1:1,l.flipY?-1:1);
  const w=l.w,h=l.h;
  if(l.type==='rect'||l.type==='ellipse'){
    if(l.type==='rect')rr(c,-w/2,-h/2,w,h,l.radius);else{c.beginPath();c.ellipse(0,0,Math.abs(w/2),Math.abs(h/2),0,0,Math.PI*2)}
    if(l.grad){let g;if(l.gang!=null){const a=l.gang*Math.PI/180,dx=Math.cos(a),dy=Math.sin(a),hl=(Math.abs(w*dx)+Math.abs(h*dy))/2;g=c.createLinearGradient(-dx*hl,-dy*hl,dx*hl,dy*hl)}else g=c.createLinearGradient(-w/2,-h/2,w/2,h/2);g.addColorStop(0,l.fill);g.addColorStop(1,l.fill2);c.fillStyle=g}else c.fillStyle=l.fill;
    c.fill();if(l.sw>0){c.lineWidth=l.sw;c.strokeStyle=l.stroke;c.stroke()}
  }else if(l.type==='text'){
    c.font=fontStr(l);c.textBaseline='top';c.textAlign=l.align;if('letterSpacing' in c)c.letterSpacing=l.ls+'px';
    const ax=l.align==='left'?-w/2:l.align==='right'?w/2:0;
    l._lines.forEach((t,i)=>{const y=-h/2+i*l.size*l.lh+(l.size*l.lh-l.size)/2;
      if(l.sw>0){c.lineWidth=l.sw*2;c.lineJoin='round';c.strokeStyle=l.stroke;c.strokeText(t,ax,y)}
      c.fillStyle=l.color;c.fillText(t,ax,y);
      if(l.under){const mw=c.measureText(t).width,xs=l.align==='left'?ax:l.align==='right'?ax-mw:ax-mw/2;c.fillRect(xs,y+l.size*1.04,mw,Math.max(1,l.size/16))}});
  }else{
    const src=l.type==='draw'&&paint.has(l.id)?paint.get(l.id):(()=>{const e=getImg(l.src);return e.ready?e.im:null})();
    if(src){if(l.radius){rr(c,-w/2,-h/2,w,h,l.radius);c.clip()}c.drawImage(src,-w/2,-h/2,w,h)}
  }
  c.restore()}
/* ---------- zoom & overlay ---------- */
const board=$('#board'),stage=$('#stage');
function applyZoom(){board.style.width=doc.w*zoom+'px';board.style.height=doc.h*zoom+'px';$('#zlabel').textContent=Math.round(zoom*100)+'%';const tz=$('#tabzoom');if(tz)tz.textContent='@ '+Math.round(zoom*100)+'%';const si=$('#stInfo');if(si)si.textContent=doc.w+' × '+doc.h+' px · '+layers.length+' layer';updGrid();showCrop();updNav();if(typeof queueAnts==='function')queueAnts()}
function setZoom(z){autoFit=false;zoom=Math.max(.05,Math.min(4,z));render()}
function fit(){autoFit=true;const w=stage.clientWidth-72,h=stage.clientHeight-72;zoom=Math.max(.05,Math.min(2,Math.min(w/doc.w,h/doc.h)));render()}
new ResizeObserver(()=>{if(autoFit)fit()}).observe(stage);
stage.addEventListener('wheel',e=>{if(e.ctrlKey||e.metaKey){e.preventDefault();setZoom(zoom*(e.deltaY<0?1.1:.9))}},{passive:false});

const HANDLES=[['nw',-1,-1,0,0],['n',0,-1,50,0],['ne',1,-1,100,0],['e',1,0,100,50],['se',1,1,100,100],['s',0,1,50,100],['sw',-1,1,0,100],['w',-1,0,0,50]];
const selbox=$('#selbox');
selbox.innerHTML=HANDLES.map(([n,sx,sy,px,py])=>`<span class="hd" data-h="${n}" style="left:${px}%;top:${py}%;cursor:${({n:'ns-resize',s:'ns-resize',e:'ew-resize',w:'ew-resize',nw:'nwse-resize',se:'nwse-resize',ne:'nesw-resize',sw:'nesw-resize'})[n]}"></span>`).join('')+'<span class="hd rot" data-h="rot" style="left:50%;top:-26px;cursor:grab"></span>';
function updateOverlay(){const l=cur();
  if(!l||!l.visible||l.type==='group'||l.type==='adjust'||['brush','eraser','crop','grad','hand','zoom','eyedrop','marq','lasso','qsel','wand','razor'].includes(tool)){selbox.hidden=true;return}
  selbox.hidden=false;
  Object.assign(selbox.style,{left:l.x*zoom+'px',top:l.y*zoom+'px',width:l.w*zoom+'px',height:l.h*zoom+'px',transform:`rotate(${l.rot}deg)`});
  selbox.querySelectorAll('.hd').forEach(h=>{const n=h.dataset.h;h.style.display=l.locked?'none':(l.type==='text'&&(n==='n'||n==='s'))?'none':''})}

/* ---------- geometry ---------- */
const toLocal=(l,p)=>{const r=l.rot*Math.PI/180,c=Math.cos(r),s=Math.sin(r),dx=p.x-(l.x+l.w/2),dy=p.y-(l.y+l.h/2);
  let x=dx*c+dy*s,y=-dx*s+dy*c;if(l.flipX)x=-x;if(l.flipY)y=-y;return{x,y}};
function hit(p){for(let i=layers.length-1;i>=0;i--){const l=layers[i];if(!effVis(l)||l.locked||l.type==='group'||l.type==='adjust')continue;
  const q=toLocal(l,p);if(Math.abs(q.x)>l.w/2||Math.abs(q.y)>l.h/2)continue;
  if(l.type==='ellipse'&&(q.x*q.x)/((l.w/2)**2)+(q.y*q.y)/((l.h/2)**2)>1)continue;
  if(l.type==='draw'&&paint.has(l.id)){const pc=paint.get(l.id);const px=Math.floor((q.x+l.w/2)*pc.width/l.w),py=Math.floor((q.y+l.h/2)*pc.height/l.h);
    try{if(pc.getContext('2d').getImageData(px,py,1,1).data[3]<12)continue}catch(e){}}
  return l}return null}
function docPt(e){const r=board.getBoundingClientRect();return{x:(e.clientX-r.left)/zoom,y:(e.clientY-r.top)/zoom}}

/* ---------- pointer interactions ---------- */
let drag=null;
board.addEventListener('pointerdown',e=>{
  if(e.button===1||(e.button===0&&spaceDown)){drag={mode:'pan',sx:e.clientX,sy:e.clientY,sl:stage.scrollLeft,st:stage.scrollTop};board.setPointerCapture(e.pointerId);return}
  if(e.button!==0)return;
  const p=docPt(e);
  if(e.target.dataset&&e.target.dataset.h){const l=cur();if(!l)return;const h=e.target.dataset.h;
    drag={mode:h==='rot'?'rotate':'resize',h,hd:HANDLES.find(x=>x[0]===h)?.slice(1,3),orig:{...l},moved:false,id:l.id};board.setPointerCapture(e.pointerId);return}
  if(SELT.includes(tool)){selDown(p,e);return}
  if(tool==='razor'){razorDown(p,e);return}
  if(tool==='hand'){drag={mode:'pan',sx:e.clientX,sy:e.clientY,sl:stage.scrollLeft,st:stage.scrollTop};board.setPointerCapture(e.pointerId);return}
  if(tool==='zoom'){zoomAt(e,e.altKey?1/1.25:1.25);return}
  if(tool==='eyedrop'){pick(p,e.altKey);drag={mode:'eyedrop'};board.setPointerCapture(e.pointerId);return}
  if(tool==='crop'){cropDown(p,e);return}
  if(tool==='grad'){gradDown(p,e);return}
  if(tool==='text'){const l=mk('text',{x:p.x,y:p.y,color:brush.color,w:Math.min(doc.w*.6,doc.w-p.x-10)});l.x=Math.max(0,Math.min(p.x,doc.w-l.w));addLayer(l);setTool('select');setTimeout(()=>{const t=$('#txt');if(t){t.focus();t.select()}},0);return}
  if(tool==='rect'||tool==='ellipse'){const l=mk(tool,{x:p.x,y:p.y,w:1,h:1});l.fill=brush.color;layers.push(l);sel=l.id;drag={mode:'create',sx:p.x,sy:p.y,id:l.id};board.setPointerCapture(e.pointerId);render();return}
  if(PIXTOOLS.includes(tool)){ptDown(p,e);return}
  const l=hit(p);
  if(l){sel=l.id;drag={mode:'move',sx:p.x,sy:p.y,orig:{...l},moved:false,id:l.id};board.setPointerCapture(e.pointerId);refresh();}
  else{sel=null;refresh()}
});
board.addEventListener('pointermove',e=>{updPos(e);if(!drag)return;
  if(drag.mode==='pan'){stage.scrollLeft=drag.sl-(e.clientX-drag.sx);stage.scrollTop=drag.st-(e.clientY-drag.sy);return}
  if(drag.mode==='crop'){cropMove(docPt(e));return}
  if(drag.mode==='sel'){selMove(docPt(e),e);return}
  if(drag.mode==='razor'){razorMove(docPt(e),e);return}
  if(drag.mode==='eyedrop'){pick(docPt(e),e.altKey);return}
  const p=docPt(e),l=layers.find(x=>x.id===drag.id);if(!l)return;
  if(drag.mode==='grad'){gradMove(l,p,e);return}
  if(drag.mode==='paint'){drag.pix?ptMove(p,e):paintTo(p);return}
  if(drag.mode==='create'){l.x=Math.min(drag.sx,p.x);l.y=Math.min(drag.sy,p.y);l.w=Math.max(1,Math.abs(p.x-drag.sx));l.h=Math.max(1,Math.abs(p.y-drag.sy));drag.moved=true;render();return}
  const o=drag.orig;drag.moved=true;
  if(drag.mode==='move'){let nx=o.x+p.x-drag.sx,ny=o.y+p.y-drag.sy;const th=6/zoom;let gx=null,gy=null;
    if(!e.altKey&&snapOn){
      for(const [off,t] of [[0,0],[l.w/2,doc.w/2],[l.w,doc.w]]){if(Math.abs(nx+off-t)<th){nx=t-off;gx=t;break}}
      for(const [off,t] of [[0,0],[l.h/2,doc.h/2],[l.h,doc.h]]){if(Math.abs(ny+off-t)<th){ny=t-off;gy=t;break}}}
    l.x=nx;l.y=ny;guides(gx,gy);render();syncPos(l);return}
  if(drag.mode==='rotate'){const cx=o.x+o.w/2,cy=o.y+o.h/2;let a=Math.atan2(p.y-cy,p.x-cx)*180/Math.PI+90;if(e.shiftKey)a=Math.round(a/15)*15;a=((a%360)+540)%360-180;l.rot=Math.round(a*10)/10;render();syncPos(l);return}
  if(drag.mode==='resize'){
    const rad=o.rot*Math.PI/180,cs=Math.cos(rad),sn=Math.sin(rad),cx=o.x+o.w/2,cy=o.y+o.h/2,dx=p.x-cx,dy=p.y-cy;
    const lx=dx*cs+dy*sn,ly=-dx*sn+dy*cs,[sx,sy]=drag.hd,ax=-sx*o.w/2,ay=-sy*o.h/2;
    let nw=sx?Math.max(8,sx*(lx-ax)):o.w,nh=sy?Math.max(8,sy*(ly-ay)):o.h;
    const corner=sx&&sy,keep=(l.type==='image'||l.type==='draw'||l.type==='text')!==e.shiftKey;
    if(corner&&keep){const s=Math.max(nw/o.w,nh/o.h);nw=o.w*s;nh=o.h*s}
    if(l.type==='text'&&corner){l.size=Math.max(6,Math.round(o.size*nw/o.w))}
    const nax=-sx*nw/2,nay=-sy*nh/2,Ax=cx+ax*cs-ay*sn,Ay=cy+ax*sn+ay*cs;
    const ncx=Ax-(nax*cs-nay*sn),ncy=Ay-(nax*sn+nay*cs);
    l.w=nw;l.h=nh;l.x=ncx-nw/2;l.y=ncy-nh/2;render();syncPos(l)}
});
function endDrag(){if(!drag)return;const d=drag;drag=null;guides(null,null);
  if(d.mode==='pan'||d.mode==='eyedrop')return;
  if(d.mode==='crop'){cropUp();return}
  if(d.mode==='sel'){selUp(d);return}
  if(d.mode==='razor'){razorUp(d);return}
  if(d.mode==='grad'){setTool('select');commit(true,'Chuyển màu');return}
  if(d.mode==='paint'){finishPaint(d);return}
  if(d.mode==='create'){const l=layers.find(x=>x.id===d.id);if(l&&(l.w<6||l.h<6)){l.x=d.sx-150;l.y=d.sy-100;l.w=300;l.h=200}setTool('select');commit(true,'Vẽ hình');return}
  if(d.moved)commit(true,{move:'Di chuyển',rotate:'Xoay',resize:'Đổi kích thước'}[d.mode]||'Chỉnh sửa');else refresh(false)}
board.addEventListener('pointerup',endDrag);board.addEventListener('pointercancel',endDrag);
board.addEventListener('dblclick',e=>{const l=hit(docPt(e));if(l&&l.type==='text'){sel=l.id;refresh();const t=$('#txt');if(t){t.focus();t.select()}}});
function guides(gx,gy){const v=$('#gv'),h=$('#gh');v.style.display=gx==null?'none':'block';h.style.display=gy==null?'none':'block';if(gx!=null)v.style.left=gx*zoom+'px';if(gy!=null)h.style.top=gy*zoom+'px'}
function syncPos(l){for(const k of['x','y','w','h','rot']){document.querySelectorAll(`#props [data-k="${k}"],#opts [data-k="${k}"]`).forEach(i=>{if(document.activeElement!==i)i.value=Math.round(l[k]*10)/10})}}

/* painting */
function getPaint(l){let c=paint.get(l.id);if(!c){c=document.createElement('canvas');c.width=l.pw||doc.w;c.height=l.ph||doc.h;const e=l.src?getImg(l.src):null;if(e&&e.ready)c.getContext('2d').drawImage(e.im,0,0,c.width,c.height);paint.set(l.id,c)}return c}
let lastPt=null;
function startPaint(p,e){if(inMask()){maskPaintStart(p,e);return}let l=cur();
  if(!l||l.type!=='draw'||l.locked||!l.visible){l=mk('draw',{x:0,y:0,w:doc.w,h:doc.h,pw:doc.w,ph:doc.h});const c=document.createElement('canvas');c.width=doc.w;c.height=doc.h;paint.set(l.id,c);l.src='';layers.push(l);sel=l.id;l._fresh=true}
  getPaint(l);drag={mode:'paint',id:l.id,moved:true};lastPt=null;board.setPointerCapture(e.pointerId);paintTo(p,true)}
function paintTo(p,first){if(drag&&drag.mask){maskPaintTo(p);return}const l=cur();if(!l)return;const c=getPaint(l),x=c.getContext('2d'),q=toLocal(l,p),k=c.width/l.w;
  const px=(q.x+l.w/2)*k,py=(q.y+l.h/2)*k;
  x.save();x.lineCap=x.lineJoin='round';x.lineWidth=brush.size*k;x.strokeStyle=x.fillStyle=brush.color;
  x.globalCompositeOperation=tool==='eraser'?'destination-out':'source-over';
  if(lastPt){x.beginPath();x.moveTo(lastPt.x,lastPt.y);x.lineTo(px,py);x.stroke()}else{x.beginPath();x.arc(px,py,brush.size*k/2,0,7);x.fill()}
  x.restore();lastPt={x:px,y:py};render()}
function finishPaint(d){if(d.pix){ptUp(d);return}if(d.mask){maskPaintEnd(d);return}const l=layers.find(x=>x.id===d.id);if(!l)return;const c=paint.get(l.id);l.pw=c.width;l.ph=c.height;
  const key=keyId();store.set(key,c.toDataURL('image/png'));l.src=key;delete l._fresh;commit(true,'Nét vẽ')}

/* ---------- layers ---------- */
function addLayer(l,select=true){layers.push(l);if(select)sel=l.id;commit(true,'Thêm '+l.name)}
function delLayer(id){layers=layers.filter(l=>l.id!==id);paint.delete(id);if(sel===id)sel=null;commit(true,'Xóa layer')}
function dupLayer(id){const s=layers.find(l=>l.id===id);if(!s)return;const n=JSON.parse(JSON.stringify(s,(k,v)=>k[0]==='_'?undefined:v));n.id=uid();n.name=s.name+' (bản sao)';n.x+=24;n.y+=24;
  if(s.type==='draw'&&paint.has(s.id)){const c=document.createElement('canvas'),o=paint.get(s.id);c.width=o.width;c.height=o.height;c.getContext('2d').drawImage(o,0,0);paint.set(n.id,c)}
  layers.splice(layers.indexOf(s)+1,0,n);sel=n.id;commit(true,'Nhân đôi layer')}
function moveLayer(id,d){const i=layers.findIndex(l=>l.id===id),j=i+d;if(i<0||j<0||j>=layers.length)return;[layers[i],layers[j]]=[layers[j],layers[i]];commit(false,'Đổi thứ tự')}
let raf=0;const queueLayers=()=>{if(!raf)raf=requestAnimationFrame(()=>{raf=0;renderLayers()})};
function renderLayers(){syncLctl();const list=$('#llist');const act=document.activeElement;if(act&&list.contains(act)&&act.tagName==='INPUT')return;
  $('#lcount').textContent=`Layer · ${layers.length}`;
  list.innerHTML='';
  if(!layers.length){list.innerHTML='<div class="empty" style="padding:6px 8px">Chưa có layer. Thêm ảnh, chữ hoặc hình ở thanh công cụ.</div>';renderFoot();return}
  [...layers].reverse().forEach(l=>{
    const d=document.createElement('div');d.className='li'+(l.id===sel?' on':'')+(l.visible?'':' off');d.draggable=true;d.dataset.id=l.id;
    d.innerHTML=`<canvas width="88" height="60"></canvas><div class="nm" title="${esc(l.name)}">${esc(l.name)}</div>${hasFx(l)?'<span class="fxb" title="Có hiệu ứng">fx</span>':''}<button data-a="vis" aria-label="Ẩn/hiện">${ic(l.visible?'eye':'eyeoff')}</button><button data-a="lock" aria-label="Khóa">${ic(l.locked?'lock':'unlock')}</button>`;
    const c=d.querySelector('canvas').getContext('2d');c.scale(88/doc.w,60/doc.h);if(l.visible||true)try{drawLayer(c,l,true)}catch(e){}
    list.appendChild(d)});
  renderFoot()}
function renderFoot(){const l=cur();$('#lfoot').innerHTML=`<button class="btn ic" data-a="new" title="Layer mới">${ic('plus')}</button><button class="btn ic" data-a="fx" title="Hiệu ứng" ${l?'':'disabled'} style="font:italic 700 12px var(--body)">fx</button><span class="vsep" style="min-height:18px"></span><button class="btn ic" data-a="up" title="Đưa lên trên" ${l?'':'disabled'}>${ic('up')}</button><button class="btn ic" data-a="down" title="Đưa xuống dưới" ${l?'':'disabled'}>${ic('down')}</button><button class="btn ic" data-a="dup" title="Nhân đôi (Ctrl+D)" ${l?'':'disabled'}>${ic('copy')}</button><span class="sp"></span><button class="btn ic" data-a="del" title="Xóa (Delete)" ${l?'':'disabled'}>${ic('trash')}</button>`}
$('#lfoot').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const a0=b.dataset.a;if(a0==='new'){newLayerMenu(b);return}if(!sel)return;if(a0==='fx'){fxMenu(b);return}({up:()=>moveLayer(sel,1),down:()=>moveLayer(sel,-1),dup:()=>dupLayer(sel),del:()=>delLayer(sel)})[b.dataset.a]?.()});
const llist=$('#llist');
llist.addEventListener('dblclick',e=>{const nm=e.target.closest('.nm');if(!nm)return;const li=nm.closest('.li'),l=layers.find(x=>x.id===li.dataset.id);
  nm.innerHTML=`<input type="text" value="${esc(l.name)}" aria-label="Tên layer">`;const i=nm.firstChild;i.focus();i.select();
  const done=()=>{l.name=i.value.trim()||l.name;commit(false)};i.addEventListener('blur',done);i.addEventListener('keydown',k=>{if(k.key==='Enter')i.blur();if(k.key==='Escape'){i.value=l.name;i.blur()}})});
/* ---------- properties ---------- */
const getPath=(o,k)=>k.split('.').reduce((a,b)=>a?.[b],o);
const setPath=(o,k,v)=>{const a=k.split('.');const last=a.pop();a.reduce((x,y)=>x[y],o)[last]=v};
const fm=v=>String(Math.round(v*100)/100);
function numF(l,lab,k,o={}){const v=getPath(l,k);return `<label class="fld"><span>${lab}</span><input type="number" data-k="${k}" value="${fm(v)}" step="${o.step||1}" ${o.ro?'readonly':''} ${o.min!=null?`min="${o.min}"`:''}></label>`}
function rngF(l,lab,k,min,max,step,sc=1,u=''){const v=getPath(l,k)*sc;return `<div class="rng"><span>${lab}</span><input type="range" data-k="${k}" data-sc="${sc}" data-u="${u}" min="${min}" max="${max}" step="${step}" value="${v}"><output>${fm(v)}${u}</output></div>`}
const colF=(l,k,lab)=>`<label class="fld" style="flex:none"><span style="width:auto">${lab||''}</span><input type="color" data-k="${k}" value="${getPath(l,k)}" aria-label="${lab||k}"></label>`;
const btnA=(a,i,t,on)=>`<button class="btn ic" data-act="${a}" title="${t}" aria-label="${t}" ${on?'style="background:var(--panel2);border-color:var(--accent);color:var(--accent)"':''}>${ic(i)}</button>`;
function buildProps(){buildProps0();buildOpts();buildChar()}
function buildProps0(){const el=$('#props'),l=cur();let h='';
  if(PIXTOOLS.includes(tool)){h+=paintProps()}
  if(!l){h+=slideSec();h+=`<div class="sec"><h4>Canvas</h4><div class="g2">${numF({w:doc.w},'W','w').replace('data-k="w"','data-d="w" min="16"')}${numF({h:doc.h},'H','h').replace('data-k="h"','data-d="h" min="16"')}</div>
    <div class="row"><label>Nền <input type="color" data-d="bg" value="${doc.bg||'#0c0d12'}"></label><label><input type="checkbox" data-d="tr" ${doc.bg?'':'checked'}> Trong suốt</label></div></div>
    <div class="sec"><h4>Kích thước nhanh</h4><div class="chips">${PRESETS.map((p,i)=>`<button class="chip" data-preset="${i}">${p[0]}</button>`).join('')}</div></div>
    <div class="sec"><h4>Bắt đầu</h4><div class="row" style="margin-top:0"><button class="btn" data-act="addimg">${ic('image')} Thêm ảnh</button><button class="btn" data-act="openproj">${ic('folder')} Mở project</button></div><div class="empty" style="margin-top:8px">Chọn một layer để chỉnh vị trí, màu, hiệu ứng và bóng đổ.</div></div>`;el.innerHTML=h;return}
  if(l.type==='adjust'||l.type==='group'){el.innerHTML=h+nodeProps(l);afterProps(l);return}
  h+=`<div class="sec"><h4>${esc(l.name)}</h4><div class="g2">${numF(l,'X','x')}${numF(l,'Y','y')}${numF(l,'W','w')}${numF(l,'H','h',{ro:l.type==='text'})}${numF(l,'∠','rot')}</div>
    <div class="row seg">${btnA('al-l','al-l','Căn trái canvas')}${btnA('al-c','al-c','Căn giữa ngang')}${btnA('al-r','al-r','Căn phải')}${btnA('al-t','al-t','Căn trên')}${btnA('al-m','al-m','Căn giữa dọc')}${btnA('al-b','al-b','Căn dưới')}<span class="sp"></span>${btnA('flipX','flipH','Lật ngang',l.flipX)}${btnA('flipY','flipV','Lật dọc',l.flipY)}</div></div>`;
  if(l.type==='text'){h+=`<div class="sec"><h4>Chữ</h4><textarea id="txt" data-k="text" data-t="s">${esc(l.text)}</textarea>
    <div class="row">${fontBtn(l)}
    <button class="btn ic" data-act="addfont" title="Nhập font từ máy (.ttf .otf .woff .woff2)" aria-label="Nhập font">${ic('plus')}</button>
    <select data-k="weight" data-t="n" aria-label="Độ đậm">${[400,500,600,700,800].map(w=>`<option value="${w}" ${w===l.weight?'selected':''}>${w}</option>`).join('')}</select></div>
    <div class="row">${numF(l,'Aa','size',{min:6})}${colF(l,'color','')}<span class="seg">${['left','center','right'].map(a=>btnA('ta-'+a,'ta-'+a,'Căn '+a,l.align===a)).join('')}</span></div>
    ${rngF(l,'Giãn chữ','ls',-5,40,.5,1,'px')}${rngF(l,'Giãn dòng','lh',.8,2.2,.05,1,'')}
    <div class="row"><label>Viền chữ ${colF(l,'stroke','')}</label></div>${rngF(l,'Độ dày viền','sw',0,30,1,1,'px')}</div>`}
  if(l.type==='rect'||l.type==='ellipse'){h+=`<div class="sec"><h4>Hình khối</h4><div class="row" style="margin-top:0">${colF(l,'fill','Màu')}<label><input type="checkbox" data-k="grad" data-rb="1" ${l.grad?'checked':''}> Chuyển màu</label>${l.grad?colF(l,'fill2',''):''}</div>
    ${l.grad?rngF({gang:l.gang==null?45:l.gang},'Góc chuyển','gang',-180,180,1,1,'°'):''}<div class="row"><label>Viền ${colF(l,'stroke','')}</label></div>${rngF(l,'Độ dày viền','sw',0,60,1,1,'px')}${l.type==='rect'?rngF(l,'Bo góc','radius',0,Math.round(Math.min(l.w,l.h)/2)||1,1,1,'px'):''}</div>`}
  if(l.type==='image'){h+=`<div class="sec"><h4>Ảnh</h4>${rngF(l,'Bo góc','radius',0,Math.round(Math.min(l.w,l.h)/2)||1,1,1,'px')}</div>`}
  h+=`<div class="sec"><h4>Hiển thị</h4>${rngF(l,'Độ mờ','opacity',0,100,1,100,'%')}<div class="row"><select data-k="blend" data-t="s" aria-label="Chế độ hòa trộn" style="width:100%">${Object.keys(BLEND).filter(b=>b!=='pass').map(b=>`<option value="${b}" ${b===l.blend?'selected':''}>${BLEND_VI[b]}</option>`).join('')}</select></div></div>
  <div class="sec"><h4>Chỉnh màu &amp; hiệu ứng</h4><div class="chips" style="margin-bottom:4px">${Object.keys(FILTER_PRESETS).map(n=>`<button class="chip" data-fp="${esc(n)}">${n}</button>`).join('')}</div>
    ${rngF(l,'Độ sáng','f.brightness',0,200,1,1,'%')}${rngF(l,'Tương phản','f.contrast',0,200,1,1,'%')}${rngF(l,'Bão hòa','f.saturate',0,200,1,1,'%')}${rngF(l,'Sắc độ','f.hue',-180,180,1,1,'°')}${rngF(l,'Trắng đen','f.gray',0,100,1,1,'%')}${rngF(l,'Nâu cổ điển','f.sepia',0,100,1,1,'%')}${rngF(l,'Làm mờ','f.blur',0,60,1,1,'px')}</div>
  <div class="sec"><h4>Bóng đổ</h4><div class="row" style="margin-top:0"><label><input type="checkbox" data-k="sh.on" data-rb="1" ${l.sh.on?'checked':''}> Bật bóng</label>${l.sh.on?colF(l,'sh.color',''):''}</div>${l.sh.on?rngF(l,'Độ đậm','sh.a',0,100,1,100,'%')+rngF(l,'Độ nhòe','sh.blur',0,100,1,1,'px')+rngF(l,'Lệch X','sh.x',-100,100,1,1,'px')+rngF(l,'Lệch Y','sh.y',-100,100,1,1,'px'):''}</div>`;
  h+=extraSecs(l);el.innerHTML=h}
const props=$('#props');
const onPI=e=>{const t=e.target;if(t.dataset.o){optIn(t);return}
  if(t.id==='bsize'){brush.size=+t.value;$('#bout').textContent=t.value+'px';return}
  if(t.id==='bcol'){brush.color=t.value;syncSw();return}
  if(t.dataset.d){const k=t.dataset.d;
    if(k==='tr'){doc.bg=t.checked?null:($('#props [data-d="bg"]').value);}else if(k==='bg'){doc.bg=t.value}else{const v=parseInt(t.value);if(!(v>=16))return;doc[k]=Math.min(8000,v);if(autoFit)fit()}
    syncDocUi();render();return}
  const k=t.dataset.k,l=cur();if(!k||!l)return;let v;
  if(t.type==='checkbox')v=t.checked;else if(t.dataset.t==='s')v=t.value;else if(t.dataset.t==='n')v=+t.value;else if(t.type==='color')v=t.value;else{v=parseFloat(t.value);if(isNaN(v))return;v/=(+t.dataset.sc||1)}
  setPath(l,k,v);
  if(t.type==='range'){const o=t.parentElement.querySelector('output');if(o)o.textContent=fm(+t.value)+(t.dataset.u||'')}
  if(t.dataset.k==='font')document.fonts.load(`${l.weight} 40px "${v}"`).then(render);
  render();queueLayers()};
const onPC=e=>{const t=e.target;if(t.dataset.o){if(t.dataset.o.startsWith('dk')){commit(t.dataset.o==='dkmode',null);if(typeof stripSync==='function')stripSync(true)}else optCh(t);return}
  if(t.id==='bsize'||t.id==='bcol')return;
  if(t.dataset.d){if(t.dataset.d==='tr'||t.dataset.d==='bg'||true)commit(t.dataset.d==='tr');return}
  if(!t.dataset.k)return;commit(!!t.dataset.rb||t.dataset.k==='w'||t.dataset.k==='h',lbl(t.dataset.k));syncPanels(e.currentTarget)};
const onPK=e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.o){optBtn(b);return}const l=cur();
  if(b.dataset.act&&stageAct(b.dataset.act,b))return;
  if(b.dataset.preset!==undefined){const p=PRESETS[+b.dataset.preset];doc.w=p[1];doc.h=p[2];syncDocUi();if(autoFit)fit();commit();return}
  if(b.dataset.fp){if(!l)return;l.f={...F0,...FILTER_PRESETS[b.dataset.fp]};commit();return}
  const a=b.dataset.act;if(a==='addimg'){$('#fileImg').click();return}if(a==='openproj'){$('#fileProj').click();return}if(a==='addfont'){$('#fileFont').click();return}
  if(!l||!a)return;
  if(a==='flipX')l.flipX=!l.flipX;else if(a==='flipY')l.flipY=!l.flipY;
  else if(a==='italic')l.italic=!l.italic;else if(a==='caps')l.caps=!l.caps;else if(a==='under')l.under=!l.under;
  else if(a.startsWith('ta-'))l.align=a.slice(3);
  else if(a==='al-l')l.x=0;else if(a==='al-c')l.x=(doc.w-l.w)/2;else if(a==='al-r')l.x=doc.w-l.w;
  else if(a==='al-t')l.y=0;else if(a==='al-m')l.y=(doc.h-l.h)/2;else if(a==='al-b')l.y=doc.h-l.h;
  commit(true,'Chỉnh '+a)};

/* ---------- toolbar / topbar ---------- */
const TOOLS=[['select','select','Di chuyển (V)','V'],['marq','marq','Marquee chọn vùng (M)','M'],['lasso','lasso','Lasso (L)','L'],['qsel','qsel','Quick Selection (W)','W'],['wand','wand','Magic Wand (Shift+W)','⇧W'],['razor','razor','Dao cắt layer (K)','K'],['crop','crop','Cắt canvas (C)','C'],['eyedrop','dropper','Lấy màu (I)','I'],['text','text','Chữ (T)','T'],['rect','rect','Hình chữ nhật (R)','R'],['ellipse','ellipse','Hình tròn (O)','O'],['grad','gradient','Chuyển màu (G)','G'],['brush','brush','Cọ vẽ (B)','B'],['eraser','eraser','Tẩy (E)','E'],['hand','hand','Bàn tay (H)','H'],['zoom','zoomt','Thu phóng (Z)','Z']];
$('#rail').innerHTML=TOOLS.map(t=>`<button class="tool" data-tool="${t[0]}" title="${t[2]}" aria-label="${t[2]}">${ic(t[1])}</button>`).join('')+`<hr><button class="tool" id="addImgBtn" title="Thêm ảnh" aria-label="Thêm ảnh">${ic('image')}</button><span class="sp"></span><div class="fgbg"><label class="sw bgc" title="Màu nền"><input type="color" id="bgIn" value="#ffffff" aria-label="Màu nền"></label><label class="sw fg" title="Màu trước"><input type="color" id="fgIn" value="#ff4f99" aria-label="Màu trước"></label><button class="mini" id="swapBtn" title="Đổi màu (X)" aria-label="Đổi màu trước và nền">${ic('swap')}</button><button class="dflt" id="defBtn" title="Mặc định (D)" aria-label="Màu mặc định">${ic('dflt')}</button></div>`;
$('#rail').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.id==='addImgBtn')$('#fileImg').click();else if(b.dataset.tool)setTool(b.dataset.tool)});
function setTool(t){if(typeof railSync==='function')railSync(t);tool=t;document.querySelectorAll('.tool[data-tool]').forEach(b=>b.classList.toggle('on',b.dataset.tool===t));
  board.style.cursor={select:'default',hand:'grab',zoom:'zoom-in'}[t]||'crosshair';
  if(t==='crop'){if(!crop)crop={x:0,y:0,w:doc.w,h:doc.h}}else crop=null;
  prev(null);showCrop();buildProps();updateOverlay()}
$('#undo').innerHTML=ic('undo');$('#redo').innerHTML=ic('redo');$('#zout').innerHTML=ic('minus');$('#zin').innerHTML=ic('plus');$('#zfit').innerHTML=ic('fit');
$('#exportBtn').innerHTML=ic('dl')+' Xuất';$('#bravinBtn').innerHTML=ic('send')+' Gửi sang Bravin';
$('#undo').onclick=undo;$('#redo').onclick=redo;$('#zout').onclick=()=>setZoom(zoom/1.2);$('#zin').onclick=()=>setZoom(zoom*1.2);$('#zfit').onclick=fit;
$('#docname').addEventListener('input',e=>{doc.name=e.target.value||'Untitled'});$('#docname').addEventListener('change',()=>pushHist());
const presetSel=$('#preset');
presetSel.innerHTML=PRESETS.map((p,i)=>`<option value="${i}">${p[0]} · ${p[1]}×${p[2]}</option>`).join('')+'<option value="x">Tùy chỉnh</option>';
presetSel.addEventListener('change',()=>{if(presetSel.value==='x')return;const p=PRESETS[+presetSel.value];doc.w=p[1];doc.h=p[2];if(autoFit)fit();commit()});
function syncDocUi(){const i=PRESETS.findIndex(p=>p[1]===doc.w&&p[2]===doc.h);presetSel.value=i<0?'x':String(i);$('#docname').value=doc.name}

/* ---------- images ---------- */
function loadImageFile(f){return new Promise(res=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{
  let src=r.result,w=im.naturalWidth,h=im.naturalHeight;const m=3000;
  if(Math.max(w,h)>m){const s=m/Math.max(w,h),c=document.createElement('canvas');c.width=Math.round(w*s);c.height=Math.round(h*s);c.getContext('2d').drawImage(im,0,0,c.width,c.height);src=c.toDataURL(f.type==='image/jpeg'?'image/jpeg':'image/png',.92);w=c.width;h=c.height}
  const key=keyId();store.set(key,src);const s=Math.min(1,doc.w*.8/w,doc.h*.8/h);
  const l=mk('image',{src:key,w:w*s,h:h*s,x:(doc.w-w*s)/2,y:(doc.h-h*s)/2,name:f.name.replace(/\.[^.]+$/,'').slice(0,40)||'Ảnh',nw:w,nh:h});res(l)};im.onerror=()=>res(null);im.src=r.result};r.onerror=()=>res(null);r.readAsDataURL(f)})}
async function addFiles(files){const imgs=[...files].filter(f=>f.type.startsWith('image/'));if(!imgs.length){toast('Chỉ nhận file ảnh.');return}
  for(const f of imgs){const l=await loadImageFile(f);if(l){layers.push(l);sel=l.id}else toast('Không đọc được '+f.name)}commit(true,'Thêm ảnh');setTool('select')}
$('#fileImg').addEventListener('change',e=>{addFiles(e.target.files);e.target.value=''});
stage.addEventListener('dragover',e=>{if([...e.dataTransfer.types].includes('Files'))e.preventDefault()});
stage.addEventListener('drop',e=>{if(e.dataTransfer.files.length){e.preventDefault();addFiles(e.dataTransfer.files)}});
window.addEventListener('paste',e=>{if(view!=='editor')return;if(/INPUT|TEXTAREA/.test(document.activeElement.tagName))return;const fs=[...(e.clipboardData?.files||[])];if(fs.length){e.preventDefault();addFiles(fs)}else if(clip){e.preventDefault();pasteLayer()}});

/* ---------- keyboard ---------- */
let spaceDown=false;
window.addEventListener('keydown',e=>{
  if(view!=='editor')return;
  if(e.code==='Space'&&!/INPUT|TEXTAREA|SELECT|BUTTON/.test(document.activeElement.tagName)){spaceDown=true;e.preventDefault()}
  if(/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName))return;
  const m=e.ctrlKey||e.metaKey,k=e.key.toLowerCase();
  if(m&&k==='z'){e.preventDefault();e.shiftKey?redo():undo();return}
  if(m&&k==='y'){e.preventDefault();redo();return}
  if(m&&k==='m'){e.preventDefault();deck?addSlide(false):convertToDeck();return}
  if(k==='f5'&&!e.shiftKey&&deck){e.preventDefault();present(deck.cur);return}
  if(m&&k==='g'){e.preventDefault();e.shiftKey?ungroupSel():e.altKey?toggleClip():groupSel();return}
  if(m&&k==='d'){e.preventDefault();sel&&dupLayer(sel);return}
  if(m&&k==='s'){e.preventDefault();saveNow().then(()=>toast('Đã lưu vào thư viện'));return}
  if(k==='f5'&&e.shiftKey){e.preventDefault();fillDialog();return}
  if(m&&k==='a'){e.preventDefault();selAll();return}
  if(m&&k==='j'){e.preventDefault();selLayer(false);return}
  if(m&&k==='backspace'&&msk){e.preventDefault();fillSel(bgc);return}
  if(m&&k==='c'){copyLayer();return}
  if(m&&k==='x'){if(cur()){copyLayer();delLayer(sel)}return}
  if(m&&(k==='='||k==='+')){e.preventDefault();setZoom(zoom*1.2);return}
  if(m&&k==='-'){e.preventDefault();setZoom(zoom/1.2);return}
  if(m&&k==='0'){e.preventDefault();fit();return}
  if(m&&k==='1'){e.preventDefault();setZoom(1);return}
  if(m)return;
  if(e.altKey&&(e.key===']'||e.key==='[')){e.preventDefault();selectRel(e.key===']'?1:-1);return}
  if(msk&&(k==='delete'||k==='backspace')){e.preventDefault();e.altKey?fillSel(brush.color):eraseSel();return}
  if(k==='escape'&&msk&&tool!=='crop'){selNone();return}
  if(k==='tab'){e.preventDefault();$('#app').classList.toggle('nodock');return}
  if(tool==='crop'&&k==='enter'){e.preventDefault();cropApply();return}
  if(tool==='crop'&&k==='escape'){crop={x:0,y:0,w:doc.w,h:doc.h};showCrop();buildOpts();return}
  if(k==='x'){swapColors();return}if(k==='d'){defColors();return}
  if(k==='['||k===']'){e.preventDefault();if(e.shiftKey){brush.hard=Math.max(0,Math.min(1,brush.hard+(k===']'?.1:-.1)))}else{brush.size=Math.max(2,Math.min(400,Math.round(brush.size*(k===']'?1.15:1/1.15)+(k===']'?1:-1))))}saveBrush();buildProps();return}
  const tk=TOOLKEYS[e.shiftKey?'S+'+k:k]||(k==='w'&&e.shiftKey)?(TOOLKEYS[e.shiftKey?'S+'+k:k]||'wand'):{v:'select',m:'marq',l:'lasso',w:'qsel',k:'razor',c:'crop',i:'eyedrop',t:'text',r:'rect',o:'ellipse',g:'grad',b:'brush',e:'eraser',h:'hand',z:'zoom'}[k];if(tk){setTool(tk);return}
  const l=cur();if(!l)return;
  if(k==='delete'||k==='backspace'){e.preventDefault();delLayer(l.id);return}
  const st=e.shiftKey?10:1,mv={arrowleft:[-st,0],arrowright:[st,0],arrowup:[0,-st],arrowdown:[0,st]}[k];
  if(mv&&!l.locked){e.preventDefault();l.x+=mv[0];l.y+=mv[1];render();syncPos(l);clearTimeout(window._nt);window._nt=setTimeout(()=>commit(false),350)}
  if(k==='escape'){sel=null;refresh()}
});
window.addEventListener('keyup',e=>{if(e.code==='Space')spaceDown=false});

/* ---------- save / export ---------- */
function toast(msg){const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),3200)}
async function saveFile(name,data){
  let dl=null;try{dl=window.claude?.use?await window.claude.use('downloads'):null}catch(e){}
  if(dl){try{const r=await dl.save({filename:name,data});toast(r.status==='saved'?'Đã lưu '+name:'Đã gửi '+name);return true}catch(e){toast(e&&e.code==='declined'?'Đã hủy lưu file.':'Không lưu được: '+(e&&e.message||'lỗi'));return false}}
  const blob=data instanceof Blob?data:new Blob([data]);const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000);toast('Đã tạo '+name);return true}
const fname=ext=>(doc.name||'antifact').replace(/[^\p{L}\p{N}_ -]+/gu,'').trim().replace(/\s+/g,'-')+ext;
const toBlob=(c,t,q)=>new Promise(r=>c.toBlob(r,t,q));
async function exportImg(kind){const c=flatten(kind==='jpg');const mime={png:'image/png',jpg:'image/jpeg',webp:'image/webp'}[kind];const b=await toBlob(c,mime,.92);if(!b){toast('Trình duyệt không hỗ trợ định dạng này.');return}saveFile(fname('.'+kind),b)}
function projectJson(){const keys=new Set(allLayers().flatMap(l=>[l.src,l.mask&&l.mask.key]).filter(Boolean));const assets={};keys.forEach(k=>assets[k]=store.get(k));const used=new Set(allLayers().filter(l=>l.type==='text').map(l=>l.font)),fonts={};used.forEach(n=>{if(customFonts[n])fonts[n]=customFonts[n]});syncCur();return JSON.stringify({format:'antifact-project',version:1,doc,layers,deck,assets,fonts},(k,v)=>k[0]==='_'?undefined:v)}
function openProject(txt){importProject(txt)}
$('#fileFont').addEventListener('change',e=>{importFonts(e.target.files);e.target.value=''});
$('#fileProj').addEventListener('change',async e=>{const f=e.target.files[0];e.target.value='';if(f)openProject(await f.text())});

async function buildBravin(o){const tracks=[];let i=0;
  for(const l of layers){if(!l.visible&&!o.hidden)continue;
    const b=bounds(l),bx=Math.max(0,Math.floor(b.x0)),by=Math.max(0,Math.floor(b.y0)),ex=Math.min(doc.w,Math.ceil(b.x1)),ey=Math.min(doc.h,Math.ceil(b.y1)),bw=ex-bx,bh=ey-by;
    if(bw<1||bh<1)continue;
    const c=document.createElement('canvas');c.width=bw;c.height=bh;const x=c.getContext('2d');x.translate(-bx,-by);drawLayer(x,l,true);
    tracks.push({id:'track-'+(++i),name:l.name,index:i-1,enabled:l.visible,locked:l.locked,clips:[{id:'clip-'+i,name:l.name,start:0,duration:o.duration,opacity:l.opacity,blendMode:l.blend,
      position:{x:bx,y:by,width:bw,height:bh},media:{type:'image',mime:'image/png',encoding:'data-url',data:c.toDataURL('image/png')}}]});
    await new Promise(r=>setTimeout(r,0))}
  return JSON.stringify({format:'bravin-project',schema:1,generator:'Antifact 1.1',createdAt:new Date().toISOString(),
    canvas:{width:doc.w,height:doc.h,background:doc.bg||null},timeline:{fps:o.fps,duration:o.duration,trackOrder:'bottom-to-top'},tracks})}
function modal(html){const m=document.createElement('div');m.className='modal';m.innerHTML=`<div class="card" role="dialog" aria-modal="true">${html}</div>`;m.addEventListener('pointerdown',e=>{if(e.target===m)m.remove()});document.body.appendChild(m);return m}
function bravinDialog(){
  const list=exportOrder().filter(l=>!l.clipTo);
  const m=modal(`<h2>Gửi sang Bravin</h2><p>Mỗi layer thành một track riêng trên timeline của Bravin, giữ nguyên vị trí, độ mờ và chế độ hòa trộn. Layer trên cùng của Antifact nằm ở track cao nhất.</p>
  <div class="tracks">${list.length?[...list].reverse().map((l,i)=>`<div class="tr"><b>V${list.length-i}</b><span>${esc(l.name)}</span><i>${l.visible?l.type:'ẩn'}</i></div>`).join(''):'<div class="tr"><span>Chưa có layer để xuất.</span></div>'}</div>
  <div class="g2" style="margin-bottom:10px"><label class="fld"><span style="width:auto">Thời lượng</span><input type="number" id="bdur" value="5" min="1" max="600"> <span style="width:auto">giây</span></label>
  <label class="fld"><span style="width:auto">FPS</span><select id="bfps"><option>24</option><option selected>30</option><option>60</option></select></label></div>
  <label class="row" style="margin:0 0 8px"><input type="checkbox" id="bhid"> Gồm cả layer đang ẩn (xuất ở dạng track tắt)</label>
  <label class="row" style="margin:0 0 14px"><input type="checkbox" id="bbake" checked> Áp layer điều chỉnh, mask, nhóm và hiệu ứng vào từng layer (Bravin chưa hiểu các thứ này)</label>
  <div class="row" style="justify-content:flex-end;margin:0"><button class="btn" id="bcopy">Sao chép JSON</button><button class="btn" id="bclose">Đóng</button><button class="btn pri" id="bgo">${ic('send')} Tải file .bravin.json</button></div>`);
  const run=async(fn)=>{const g=m.querySelector('#bgo');g.disabled=true;const old=g.innerHTML;g.textContent='Đang tạo...';try{const json=await buildBravin({duration:Math.max(1,+m.querySelector('#bdur').value||5),fps:+m.querySelector('#bfps').value,hidden:m.querySelector('#bhid').checked,bake:m.querySelector('#bbake').checked});await fn(json)}finally{g.disabled=false;g.innerHTML=old}};
  m.querySelector('#bclose').onclick=()=>m.remove();
  m.querySelector('#bgo').onclick=()=>run(async j=>{if(await saveFile(fname('.bravin.json'),j))m.remove()});
  m.querySelector('#bcopy').onclick=()=>run(async j=>{try{await navigator.clipboard.writeText(j);toast('Đã sao chép project Bravin')}catch(e){toast('Không sao chép được, hãy dùng nút Tải file.')}});
  if(!list.length)m.querySelector('#bgo').disabled=true}
function exportMenu(){const old=$('.pop');if(old){old.remove();return}
  const r=$('#exportBtn').getBoundingClientRect(),p=document.createElement('div');p.className='pop';p.style.top=r.bottom+6+'px';p.style.right=Math.max(8,innerWidth-r.right)+'px';
  p.innerHTML=`<button data-x="png">${ic('image')} Ảnh PNG <small>trong suốt</small></button><button data-x="jpg">${ic('image')} Ảnh JPG</button><button data-x="webp">${ic('image')} Ảnh WebP</button><hr><button data-x="save">${ic('dl')} Lưu project Antifact <small>.json</small></button><button data-x="open">${ic('folder')} Mở project</button>`;
  p.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;p.remove();const x=b.dataset.x;
    if(x==='save')saveFile(fname('.antifact.json'),projectJson());else if(x==='open')$('#fileProj').click();else exportImg(x)});
  document.body.appendChild(p);setTimeout(()=>document.addEventListener('pointerdown',function f(e){if(!p.contains(e.target)&&e.target.id!=='exportBtn'){p.remove()}document.removeEventListener('pointerdown',f)},{once:false}),0)}
$('#slideBtn').onclick=()=>deck?openCam():slideDialog();syncSlideBtn();
$('#exportBtn').onclick=exportMenu;$('#bravinBtn').onclick=bravinDialog;

/* ---------- sample project ---------- */
function sample(){
  const L=[];const A=(t,p)=>{const l=mk(t,p);L.push(l);return l};
  A('rect',{name:'Nền',x:0,y:0,w:1280,h:720,fill:'#1b1440',grad:true,fill2:'#0c0d12'});
  A('ellipse',{name:'Quầng magenta',x:700,y:-160,w:760,h:760,fill:'#ff4f99',opacity:.5}).f.blur=90;
  A('ellipse',{name:'Quầng cyan',x:-180,y:430,w:520,h:520,fill:'#2fd0ee',opacity:.32}).f.blur=90;
  A('rect',{name:'Nhãn nền',x:80,y:92,w:318,h:56,radius:28,fill:'#ffd43b'});
  A('text',{name:'Nhãn chữ',text:'ĐANG PHÁT TRIỂN',font:'JetBrains Mono',size:24,weight:700,color:'#0c0d12',align:'center',x:80,y:106,w:318,ls:1});
  A('text',{name:'Tiêu đề',text:'Antifact',font:'Bricolage Grotesque',size:220,weight:800,x:74,y:176,w:1000,lh:1.05,ls:-6});
  A('text',{name:'Mô tả',text:'Chỉnh ảnh và thiết kế ngay trên trình duyệt.\nXuất thẳng sang Bravin, mỗi layer một track.',font:'Be Vietnam Pro',size:34,weight:500,color:'#c9cbdb',x:82,y:446,w:760,lh:1.4});
  A('rect',{name:'Nút nền',x:82,y:590,w:372,h:72,radius:36,fill:'#ff4f99'});
  A('text',{name:'Nút chữ',text:'Layer → Track Bravin',font:'Bricolage Grotesque',size:30,weight:700,color:'#0c0d12',align:'center',x:82,y:608,w:372});
  layers=L;sel=null}


/* ---------- home / projects ---------- */
let view='home',projects=[],currentId=null,hNav='home',hSort='recent',hAsc=false,hView='grid',hFilter='';
try{hView=localStorage.getItem('af-view')==='rows'?'rows':'grid'}catch(e){}
let idb=null;const mem={data:new Map(),meta:new Map()};
function idbOpen(){return new Promise(res=>{try{const r=indexedDB.open('antifact-1',1);r.onupgradeneeded=()=>{const d=r.result;d.createObjectStore('meta',{keyPath:'id'});d.createObjectStore('data')};r.onsuccess=()=>res(r.result);r.onerror=r.onblocked=()=>res(null)}catch(e){res(null)}})}
function idbReq(st,mode,op){return new Promise(res=>{if(!idb)return res(null);try{const t=idb.transaction(st,mode);const r=op(t.objectStore(st));t.oncomplete=()=>res(r&&'result' in r?(r.result===undefined?true:r.result):true);t.onerror=t.onabort=()=>res(null)}catch(e){res(null)}})}
const dbAllMeta=async()=>idb?((await idbReq('meta','readonly',s=>s.getAll()))||[]):[...mem.meta.values()];
const dbPutMeta=async m=>{if(idb)await idbReq('meta','readwrite',s=>s.put(JSON.parse(JSON.stringify(m))));else mem.meta.set(m.id,m)};
const dbPutData=async(id,d)=>{if(idb)await idbReq('data','readwrite',s=>s.put(d,id));else mem.data.set(id,d)};
const dbGetData=async id=>idb?await idbReq('data','readonly',s=>s.get(id)):(mem.data.get(id)||null);
const dbDel=async id=>{if(idb){await idbReq('meta','readwrite',s=>s.delete(id));await idbReq('data','readwrite',s=>s.delete(id))}else{mem.meta.delete(id);mem.data.delete(id)}};
const ago=t=>{const s=(Date.now()-t)/1000;if(s<45)return'vừa xong';const m=s/60;if(m<60)return Math.round(m)+' phút trước';const h=m/60;if(h<24)return Math.round(h)+' giờ trước';const d=h/24;if(d<30)return Math.round(d)+' ngày trước';const mo=d/30;if(mo<12)return Math.round(mo)+' tháng trước';return Math.round(mo/12)+' năm trước'};
const metaOf=id=>projects.find(p=>p.id===id);
function makeThumb(){const f=flatten();const k=Math.min(1,480/doc.w,360/doc.h);const c=document.createElement('canvas');c.width=Math.max(1,Math.round(doc.w*k));c.height=Math.max(1,Math.round(doc.h*k));const x=c.getContext('2d');if(!doc.bg){x.fillStyle='#20212b';x.fillRect(0,0,c.width,c.height)}x.drawImage(f,0,0,c.width,c.height);return c.toDataURL('image/jpeg',.82)}
let saveT=0;const setSave=t=>{const e=$('#saveState');if(e)e.textContent=t};
function scheduleSave(){if(!currentId||view!=='editor')return;clearTimeout(saveT);setSave('Đang lưu...');saveT=setTimeout(saveNow,800)}
async function saveNow(){clearTimeout(saveT);if(!currentId)return;const id=currentId;let m=metaOf(id);if(!m){m={id,created:Date.now(),trashed:false};projects.push(m)}
  Object.assign(m,{name:doc.name,w:doc.w,h:doc.h,updated:Date.now(),thumb:makeThumb()});
  await dbPutData(id,projectJson());await dbPutMeta(m);setSave(idb?'Đã lưu':'Chưa lưu được')}
window.addEventListener('pagehide',()=>{if(view==='editor')saveNow()});
function enterEditor(){view='editor';stripSig='';$('#home').hidden=true;syncDocUi();setTool('select');setSave('Đã lưu');autoFit=true;refresh();fit()}
function resetHist(){sel=null;paint.clear();hist=[];hnames=[];hi=-1;currentId=null;if(typeof mskClear==='function')mskClear();pushHist('Ban đầu')}
async function createProject({name,w,h,bg,lay,asDeck}){doc={name:name||'Chưa đặt tên',w,h,bg};layers=lay||[];deck=null;if(asDeck)deckInit();resetHist();currentId=uid();await saveNow();enterEditor()}
async function openRecord(id){const m=metaOf(id);const txt=await dbGetData(id);if(!txt){toast('Không mở được project này.');return}
  try{const o=JSON.parse(txt);Object.entries(o.assets||{}).forEach(([k,v])=>store.set(k,v));let nf=0;for(const [n,u] of Object.entries(o.fonts||{})){if(!customFonts[n]){try{await regFont(n,u);nf++}catch(e){}}}if(nf)saveFonts();doc=o.doc;doc.name=m.name;layers=o.layers;deck=o.deck||null;if(deck){deck.cur=Math.min(deck.cur||0,deck.slides.length-1);layers=deck.slides[deck.cur].layers;doc.bg=deck.slides[deck.cur].bg}}catch(e){toast('File project bị lỗi.');return}
  resetHist();currentId=id;enterEditor()}
async function importProject(txt){let o;try{o=JSON.parse(txt);if(o.format!=='antifact-project')throw 0}catch(e){toast('File không phải project Antifact.');return}
  Object.entries(o.assets||{}).forEach(([k,v])=>store.set(k,v));doc=o.doc;layers=o.layers;deck=o.deck||null;if(deck){deck.cur=Math.min(deck.cur||0,deck.slides.length-1);layers=deck.slides[deck.cur].layers;doc.bg=deck.slides[deck.cur].bg}resetHist();currentId=uid();await saveNow();enterEditor();toast('Đã mở project')}
async function goHome(){await saveNow();currentId=null;view='home';renderHome();$('#home').hidden=false}
async function dupProject(id){const m=metaOf(id),d=await dbGetData(id);if(!m||!d)return;const n={...m,id:uid(),name:m.name+' (bản sao)',created:Date.now(),updated:Date.now()};await dbPutData(n.id,d);await dbPutMeta(n);projects.push(n);renderList()}
async function setTrash(id,v){const m=metaOf(id);if(!m)return;m.trashed=v;await dbPutMeta(m);renderList();toast(v?'Đã chuyển vào thùng rác':'Đã khôi phục')}
async function purge(id){await dbDel(id);projects=projects.filter(p=>p.id!==id);renderList()}

function renderSide(){$('#hside').innerHTML=`<button class="btn pri big" data-a="new">${ic('plus')} Tệp mới</button><button class="hopen" data-a="open">${ic('folder')} Mở file</button><hr>
 <button class="nav ${hNav==='home'?'on':''}" data-a="nav" data-nav="home">${ic('home')} Trang chủ</button><button class="nav ${hNav==='trash'?'on':''}" data-a="nav" data-nav="trash">${ic('trash')} Đã xóa</button>
 <p class="hnote">Project lưu ngay trong trình duyệt này, không lên máy chủ. Muốn mang sang máy khác, dùng Xuất &gt; Lưu project.</p>`}
function renderHome(){renderSide();const h=$('#hmain'),trash=hNav==='trash';
  const quick=!trash?`<h2 style="margin-bottom:12px">Bắt đầu nhanh</h2><div class="quick">${PRESETS.map((p,i)=>{const k=40/Math.max(p[1],p[2]);return `<button class="qt" data-a="quick" data-i="${i}"><span class="sh"><i style="width:${Math.max(10,p[1]*k)}px;height:${Math.max(10,p[2]*k)}px"></i></span><b>${p[0]}</b><span class="mono">${p[1]} × ${p[2]}</span></button>`}).join('')}</div>`:'';
  h.innerHTML=`<h1>${trash?'Đã xóa':'Chào mừng đến Antifact'}</h1><p class="sub">${trash?'Project trong thùng rác. Khôi phục hoặc xóa hẳn.':'Chọn một project gần đây hoặc tạo tệp mới để bắt đầu.'}</p>${quick}
  <div class="hbar"><h2>${trash?'Thùng rác':'Gần đây'}</h2><span class="sp"></span>
   <label>Sắp xếp <select id="hsort" aria-label="Sắp xếp"><option value="recent" ${hSort==='recent'?'selected':''}>Gần đây</option><option value="name" ${hSort==='name'?'selected':''}>Tên</option></select></label>
   <button class="btn ic" data-a="dir" title="Đảo thứ tự" aria-label="Đảo thứ tự">${ic('sortdir')}</button>
   <label>Lọc <input type="search" id="hfilter" placeholder="Tìm theo tên" value="${esc(hFilter)}"></label>
   <span class="seg2"><button class="btn ic ${hView==='grid'?'on':''}" data-a="view" data-v="grid" title="Dạng lưới" aria-label="Dạng lưới">${ic('grid')}</button><button class="btn ic ${hView==='rows'?'on':''}" data-a="view" data-v="rows" title="Dạng danh sách" aria-label="Dạng danh sách">${ic('rows')}</button></span></div>
  <div class="plist ${hView==='rows'?'rows':''}" id="plist"></div>`;renderList()}
function renderList(){const el=$('#plist');if(!el)return;const trash=hNav==='trash';
  let list=projects.filter(p=>!!p.trashed===trash);const q=hFilter.trim().toLowerCase();if(q)list=list.filter(p=>p.name.toLowerCase().includes(q));
  list.sort((a,b)=>hSort==='name'?a.name.localeCompare(b.name,'vi'):b.updated-a.updated);if(hAsc)list.reverse();
  el.className='plist'+(hView==='rows'?' rows':'');
  if(!list.length){el.innerHTML=`<div class="hempty">${q?`Không có project nào khớp "${esc(hFilter)}".`:trash?'Thùng rác trống.':'Chưa có project nào. Bấm Tệp mới hoặc chọn một kích thước ở trên.'}</div>`;return}
  el.innerHTML=list.map(p=>`<article class="pc" data-id="${p.id}"><button class="pthumb" data-a="openp" ${trash?'disabled':''} aria-label="Mở ${esc(p.name)}"><img alt="" src="${p.thumb||''}"></button>${trash?'':`<button class="pslide" data-a="toslide" title="Chuyển thiết kế này thành slide có camera và chuyển động">${ic('layers')} Chuyển thành slide</button>`}<div class="pinfo"><div class="pname" title="${esc(p.name)}">${esc(p.name)}</div><div class="pmeta"><span>${ago(p.updated)}</span><span class="mono">${p.w} × ${p.h}</span></div></div><button class="pmore" data-a="menu" aria-label="Tùy chọn">${ic('more')}</button></article>`).join('')}
function closePop(){document.querySelectorAll('.pop').forEach(p=>p.remove())}
function cardMenu(btn,id){closePop();const m=metaOf(id);if(!m)return;const r=btn.getBoundingClientRect(),p=document.createElement('div');p.className='pop';p.style.top=Math.max(8,Math.min(r.bottom+4,innerHeight-220))+'px';p.style.left=Math.max(8,Math.min(r.right-230,innerWidth-240))+'px';p.style.minWidth='220px';
  p.innerHTML=m.trashed?`<button data-x="restore">${ic('undo')} Khôi phục</button><button data-x="purge">${ic('trash')} <span>Xóa hẳn</span></button>`:`<button data-x="open">${ic('folder')} Mở</button><button data-x="slide">${ic('layers')} Chuyển thành slide…</button><button data-x="rename">${ic('text')} Đổi tên</button><button data-x="dup">${ic('copy')} Nhân đôi</button><hr><button data-x="trash">${ic('trash')} Chuyển vào thùng rác</button>`;
  p.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const x=b.dataset.x;
    if(x==='purge'&&!b.dataset.sure){b.dataset.sure='1';b.querySelector('span').textContent='Bấm lần nữa để xóa hẳn';return}
    closePop();
    if(x==='open')openRecord(id);else if(x==='slide')openRecord(id).then(()=>slideDialog());else if(x==='dup')dupProject(id);else if(x==='trash')setTrash(id,true);else if(x==='restore')setTrash(id,false);else if(x==='purge')purge(id);
    else if(x==='rename'){const n=document.querySelector(`.pc[data-id="${id}"] .pname`);if(!n)return;n.innerHTML=`<input type="text" value="${esc(m.name)}" aria-label="Tên project">`;const i=n.firstChild;i.focus();i.select();
      const done=async()=>{m.name=i.value.trim()||m.name;await dbPutMeta(m);renderList()};i.addEventListener('blur',done);i.addEventListener('keydown',k=>{if(k.key==='Enter')i.blur();if(k.key==='Escape'){i.value=m.name;i.blur()}})}});
  document.body.appendChild(p);setTimeout(()=>document.addEventListener('pointerdown',function f(e){if(!p.contains(e.target))p.remove();document.removeEventListener('pointerdown',f)}),0)}
function newDialog(){let sp=0;
  const m=modal(`<h2>Tệp mới</h2><p>Chọn kích thước canvas. Bạn có thể đổi sau trong editor.</p>
  <label class="fld" style="margin-bottom:12px"><span style="width:auto">Tên</span><input type="text" id="nfName" value="Chưa đặt tên"></label>
  <div class="chips" id="nfChips" style="margin-bottom:12px">${PRESETS.map((p,i)=>`<button class="chip ${i===0?'on':''}" data-i="${i}">${p[0]}</button>`).join('')}</div>
  <div class="g2" style="margin-bottom:12px"><label class="fld"><span>W</span><input type="number" id="nfW" value="${PRESETS[0][1]}" min="16" max="8000"></label><label class="fld"><span>H</span><input type="number" id="nfH" value="${PRESETS[0][2]}" min="16" max="8000"></label></div>
  <div class="row" style="margin:0 0 18px"><label>Nền <input type="color" id="nfBg" value="#ffffff"></label><label><input type="checkbox" id="nfTr"> Trong suốt</label></div>
  <div class="row" style="justify-content:flex-end;margin:0"><button class="btn" id="nfCancel">Hủy</button><button class="btn pri" id="nfGo">Tạo</button></div>`);
  m.querySelector('#nfChips').addEventListener('click',e=>{const b=e.target.closest('.chip');if(!b)return;m.querySelectorAll('.chip').forEach(c=>c.classList.toggle('on',c===b));const p=PRESETS[+b.dataset.i];m.querySelector('#nfW').value=p[1];m.querySelector('#nfH').value=p[2]});
  m.querySelector('#nfCancel').onclick=()=>m.remove();
  m.querySelector('#nfGo').onclick=()=>{const w=Math.max(16,Math.min(8000,parseInt(m.querySelector('#nfW').value)||0)),h=Math.max(16,Math.min(8000,parseInt(m.querySelector('#nfH').value)||0));if(!w||!h){toast('Nhập chiều rộng và chiều cao.');return}
    const tr=m.querySelector('#nfTr').checked;const pn=(PRESETS[+(m.querySelector('#nfChips .on')||{dataset:{i:-1}}).dataset.i]||[''])[0]||'';m.remove();createProject({name:m.querySelector('#nfName').value.trim(),w,h,bg:tr?null:m.querySelector('#nfBg').value,asDeck:pn.startsWith('Bản trình bày')})};
  setTimeout(()=>{const i=m.querySelector('#nfName');i.focus();i.select()},0)}
$('#home').addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,card=b.closest('.pc');
  if(a==='new')newDialog();else if(a==='open')$('#fileOpen').click();
  else if(a==='nav'){hNav=b.dataset.nav;hFilter='';renderHome()}
  else if(a==='quick'){const p=PRESETS[+b.dataset.i];createProject({name:p[0].startsWith('Bản trình bày')?'Bản trình bày':'Chưa đặt tên',w:p[1],h:p[2],bg:'#ffffff',asDeck:p[0].startsWith('Bản trình bày')})}
  else if(a==='openp'&&card)openRecord(card.dataset.id);
  else if(a==='toslide'&&card)openRecord(card.dataset.id).then(()=>slideDialog());
  else if(a==='menu'&&card)cardMenu(b,card.dataset.id);
  else if(a==='dir'){hAsc=!hAsc;renderList()}
  else if(a==='view'){hView=b.dataset.v;try{localStorage.setItem('af-view',hView)}catch(x){}renderHome()}});
$('#home').addEventListener('input',e=>{if(e.target.id==='hfilter'){hFilter=e.target.value;renderList()}});
$('#home').addEventListener('change',e=>{if(e.target.id==='hsort'){hSort=e.target.value;renderList()}});
$('#fileOpen').addEventListener('change',async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;
  if(f.type.startsWith('image/')){const l=await loadImageFile(f);if(!l){toast('Không đọc được ảnh.');return}
    const k=Math.min(1,4096/Math.max(l.nw,l.nh));l.x=0;l.y=0;l.w=Math.round(l.nw*k);l.h=Math.round(l.nh*k);createProject({name:l.name,w:l.w,h:l.h,bg:null,lay:[l]})}
  else importProject(await f.text())});
$('#homeBtn').innerHTML=ic('home');$('#homeBtn').onclick=goHome;
async function initHome(){const lg=document.querySelector('.menubar .logo');$('#hbrand').innerHTML=(lg?lg.outerHTML:'')+'Antifact';
  idb=await idbOpen();projects=await dbAllMeta();
  if(!projects.length){try{if(localStorage.getItem('af-seeded'))throw 0}catch(e){if(e===0){renderHome();return}}
    await Promise.race([fontsReady,new Promise(r=>setTimeout(r,2500))]);sample();doc={name:'Mẫu thumbnail',w:1280,h:720,bg:'#0c0d12'};resetHist();currentId=uid();view='editor';await saveNow();view='home';currentId=null;try{localStorage.setItem('af-seeded','1')}catch(e){}}
  renderHome()}


/* ---------- AI assistant ---------- */
let aiSample=null,aiLimits=null,aiBusy=false,aiCtl=null,aiTurns=[];
const AI_RULES=`Bạn là trợ lý thiết kế trong Antifact, một trình chỉnh sửa ảnh và thiết kế chạy trên web.
- Trả lời bằng tiếng Việt, 1 đến 3 câu, nói ngắn gọn bạn đã làm gì. Nếu yêu cầu mơ hồ, chọn cách hợp lý nhất và nói bạn đã chọn gì.
- Mọi thay đổi phải làm bằng công cụ. Không mô tả một thay đổi mà không gọi công cụ.
- Toạ độ tính bằng px trên canvas, gốc ở góc trên trái. x,y là góc trên trái của khung layer. Danh sách layer xếp từ dưới lên trên (z tăng dần).
- Layer chữ: w là bề rộng để xuống dòng, chiều cao tự tính. Muốn chữ to hơn thì tăng size.
- Bạn không tạo được ảnh mới, không xóa nền và không chỉnh điểm ảnh bên trong ảnh. Nếu được yêu cầu, nói rõ và đề xuất cách khác bằng chữ, hình khối, bộ lọc màu.
- Giữ nguyên nội dung chữ của người dùng trừ khi họ yêu cầu viết lại. Không sửa layer bị khóa. Chỉ sửa layer liên quan đến yêu cầu.
- Nếu người dùng nói "cái này", "nó" thì đó là layer selectedId.
- Khi người dùng không nêu màu, ưu tiên bảng màu Antifact: ink #0c0d12, cyan #2fd0ee, magenta #ff4f99, vàng #ffd43b, chữ sáng #eceef6. Chữ phải đủ tương phản với nền và nằm trong canvas.
- Gom nhiều thay đổi vào một lần gọi update_layers.`;
const hexc=v=>{v=String(v).trim();if(/^#[0-9a-f]{3}$/i.test(v))v='#'+v.slice(1).split('').map(c=>c+c).join('');return /^#[0-9a-f]{6}$/i.test(v)?v.toLowerCase():null};
const clampn=(v,a,b)=>Math.min(b,Math.max(a,v));
const NUMR={x:[-20000,20000],y:[-20000,20000],w:[1,20000],h:[1,20000],rot:[-360,360],opacity:[0,1],size:[4,2000],weight:[100,900],sw:[0,500],ls:[-50,200],lh:[.5,4],radius:[0,5000]};
const FOR={text:['text','font','size','weight','align','color','stroke','sw','ls','lh'],rect:['fill','fill2','grad','stroke','sw','radius'],ellipse:['fill','fill2','grad','stroke','sw'],image:['radius'],draw:[]};
const FILT={brightness:[0,200],contrast:[0,200],saturate:[0,200],hue:[-180,180],gray:[0,100],sepia:[0,100],blur:[0,60]};
const SHN={blur:[0,100],x:[-200,200],y:[-200,200]};
function applyProps(l,p){const done=[],ign=[];const common=['name','x','y','w','h','rot','opacity','blend','visible','locked','flipX','flipY'];
  for(const [k,v] of Object.entries(p||{})){
    if(k==='filters'&&v&&typeof v==='object'){for(const [fk,fv] of Object.entries(v)){if(FILT[fk]&&isFinite(+fv)){l.f[fk]=clampn(+fv,...FILT[fk]);done.push('filters.'+fk)}else ign.push('filters.'+fk)}continue}
    if(k==='shadow'&&v&&typeof v==='object'){for(const [sk,sv] of Object.entries(v)){
      if(sk==='on'){l.sh.on=!!sv;done.push('shadow.on')}else if(sk==='color'&&hexc(sv)){l.sh.color=hexc(sv);done.push('shadow.color')}else if(sk==='a'&&isFinite(+sv)){l.sh.a=clampn(+sv,0,1);done.push('shadow.a')}else if(SHN[sk]&&isFinite(+sv)){l.sh[sk]=clampn(+sv,...SHN[sk]);done.push('shadow.'+sk)}else ign.push('shadow.'+sk)}continue}
    if(!common.includes(k)&&!(FOR[l.type]||[]).includes(k)){ign.push(k);continue}
    if(k==='h'&&l.type==='text'){ign.push('h (chữ tự tính chiều cao)');continue}
    if(NUMR[k]){const n=+v;if(!isFinite(n)){ign.push(k);continue}l[k]=clampn(n,...NUMR[k])}
    else if(['color','stroke','fill','fill2'].includes(k)){const c=hexc(v);if(!c){ign.push(k+' (cần mã hex #rrggbb)');continue}l[k]=c}
    else if(k==='font'){if(!FONTS.includes(v)){ign.push('font (chỉ có: '+FONTS.join(', ')+')');continue}l.font=v}
    else if(k==='align'){if(!['left','center','right'].includes(v)){ign.push(k);continue}l.align=v}
    else if(k==='blend'){if(!BLEND[v]){ign.push('blend (chỉ có: '+Object.keys(BLEND).join(', ')+')');continue}l.blend=v}
    else if(k==='text')l.text=String(v).slice(0,2000);
    else if(k==='name')l.name=String(v).slice(0,60);
    else if(['visible','locked','flipX','flipY','grad'].includes(k))l[k]=!!v;
    else{ign.push(k);continue}
    done.push(k)}
  if(l.type==='text')layoutText(l);return{done,ign}}
const r1=n=>Math.round(n*10)/10;
function brief(l,z){if(l.type==='text')layoutText(l);const o={id:l.id,z,name:l.name,type:l.type,x:r1(l.x),y:r1(l.y),w:r1(l.w),h:r1(l.h),rot:r1(l.rot),opacity:l.opacity,blend:l.blend,visible:l.visible,locked:l.locked};
  if(l.type==='text')Object.assign(o,{text:l.text,font:l.font,size:l.size,weight:l.weight,align:l.align,color:l.color,stroke:l.sw?l.stroke:undefined,sw:l.sw||undefined});
  else if(l.type==='rect'||l.type==='ellipse')Object.assign(o,{fill:l.fill,grad:l.grad||undefined,fill2:l.grad?l.fill2:undefined,stroke:l.sw?l.stroke:undefined,sw:l.sw||undefined,radius:l.radius||undefined});
  const f=Object.entries(l.f).filter(([k,v])=>v!==F0[k]);if(f.length)o.filters=Object.fromEntries(f);if(l.sh.on)o.shadow=l.sh;return o}
const aiState=()=>JSON.stringify({canvas:{w:doc.w,h:doc.h,bg:doc.bg},selectedId:sel,layers:layers.map((l,i)=>brief(l,i))});
const needL=id=>{const l=layers.find(x=>x.id===String(id));if(!l)throw new Error('Không có layer id '+id+'. Gọi get_layers để xem danh sách.');return l};
let aiActs=null;const act=t=>{if(aiActs){const s=document.createElement('span');s.textContent=t;aiActs.appendChild(s);const m=$('#aiMsgs');m.scrollTop=m.scrollHeight}};
const touch=()=>{render();queueLayers()};
const PROPS_DOC='Các khóa: name,x,y,w,h,rot,opacity(0-1),blend,visible,locked,flipX,flipY. Chữ: text,font,size,weight,align(left|center|right),color,stroke,sw,ls,lh. Hình: fill,fill2,grad(bool),stroke,sw,radius. filters:{brightness,contrast,saturate,hue,gray,sepia,blur}. shadow:{on,color,a,blur,x,y}. Màu dạng #rrggbb. Font: '+FONTS.join(', ')+'.';
const AI_TOOLS=[
 {name:'get_layers',description:'Trả về canvas và danh sách layer hiện tại (id, vị trí, kích thước, màu, chữ). Gọi khi cần đọc lại trạng thái sau khi đã sửa.',execute:()=>aiState()},
 {name:'update_layers',description:'Sửa thuộc tính của một hoặc nhiều layer cùng lúc. Trả về phần đã áp dụng và phần bị bỏ qua.',inputSchema:{type:'object',properties:{updates:{type:'array',items:{type:'object',properties:{id:{type:'string'},props:{type:'object',description:PROPS_DOC}},required:['id','props']}}},required:['updates']},
  execute:({updates})=>{if(!Array.isArray(updates))throw new Error('updates phải là mảng');const out=[];
    for(const u of updates){const l=needL(u.id);const p=u.props||{};
      if(l.locked&&!(Object.keys(p).length===1&&p.locked===false)){out.push({id:l.id,error:'layer bị khóa'});continue}
      const r=applyProps(l,p);if(r.done.length)act(`Sửa "${l.name}": ${r.done.join(', ')}`);out.push({id:l.id,applied:r.done,ignored:r.ign.length?r.ign:undefined,layer:brief(l,layers.indexOf(l))})}
    touch();return out}},
 {name:'add_layer',description:'Thêm layer chữ, hình chữ nhật hoặc hình tròn. Nếu không đưa x,y thì đặt giữa canvas. Trả về id và kích thước.',inputSchema:{type:'object',properties:{type:{type:'string',enum:['text','rect','ellipse']},props:{type:'object',description:PROPS_DOC}},required:['type']},
  execute:({type,props})=>{if(!['text','rect','ellipse'].includes(type))throw new Error('type phải là text, rect hoặc ellipse');
    const p=props||{};const l=mk(type,type==='text'?{w:Math.round(doc.w*.6),color:'#eceef6'}:{w:Math.round(doc.w*.3),h:Math.round(doc.h*.3)});const r=applyProps(l,p);
    if(l.type==='text')layoutText(l);if(p.x==null)l.x=Math.round((doc.w-l.w)/2);if(p.y==null)l.y=Math.round((doc.h-l.h)/2);
    layers.push(l);sel=l.id;act(`Thêm ${NAMES[type].toLowerCase()} "${l.name}"`);touch();return{id:l.id,applied:r.done,ignored:r.ign.length?r.ign:undefined,layer:brief(l,layers.length-1)}}},
 {name:'delete_layer',description:'Xóa một layer theo id.',inputSchema:{type:'object',properties:{id:{type:'string'}},required:['id']},
  execute:({id})=>{const l=needL(id);if(l.locked)throw new Error('layer bị khóa');layers=layers.filter(x=>x!==l);paint.delete(l.id);if(sel===l.id)sel=null;act(`Xóa "${l.name}"`);touch();return{ok:true}}},
 {name:'reorder_layer',description:'Đổi thứ tự xếp chồng của layer: front (trên cùng), back (dưới cùng), forward (lên một bậc), backward (xuống một bậc).',inputSchema:{type:'object',properties:{id:{type:'string'},to:{type:'string',enum:['front','back','forward','backward']}},required:['id','to']},
  execute:({id,to})=>{const l=needL(id);const i=layers.indexOf(l);layers.splice(i,1);const n={front:layers.length,back:0,forward:Math.min(layers.length,i+1),backward:Math.max(0,i-1)}[to];if(n==null)throw new Error('to không hợp lệ');layers.splice(n,0,l);act(`Đổi thứ tự "${l.name}": ${to}`);touch();return{ok:true,z:layers.indexOf(l)}}},
 {name:'set_canvas',description:'Đổi kích thước canvas (16 đến 8000 px) và/hoặc màu nền (hex, hoặc null cho trong suốt). Layer giữ nguyên vị trí.',inputSchema:{type:'object',properties:{w:{type:'number'},h:{type:'number'},bg:{type:['string','null']}}},
  execute:({w,h,bg})=>{if(w!=null&&isFinite(+w))doc.w=Math.round(clampn(+w,16,8000));if(h!=null&&isFinite(+h))doc.h=Math.round(clampn(+h,16,8000));
    if(bg===null)doc.bg=null;else if(bg!=null){const c=hexc(bg);if(!c)throw new Error('bg cần mã hex #rrggbb hoặc null');doc.bg=c}
    syncDocUi();if(autoFit)fit();act(`Canvas ${doc.w}×${doc.h}`+(doc.bg===null?', nền trong suốt':', nền '+doc.bg));touch();return{w:doc.w,h:doc.h,bg:doc.bg}}}
];
const AI_SUGGEST=['Làm tiêu đề nổi bật hơn','Căn giữa mọi layer chữ trên canvas','Đổi bảng màu sang tông ấm','Thêm nhãn "GIẢM 50%" ở góc phải trên','Gợi ý cách sắp xếp bố cục tốt hơn'];
function aiMsg(role,text){const m=document.createElement('div');m.className='m '+(role==='user'?'u':'a');const t=document.createElement('div');t.textContent=text;m.appendChild(t);const a=document.createElement('div');a.className='acts';m.appendChild(a);const box=$('#aiMsgs');const sg=box.querySelector('.aisug');if(sg)sg.remove();box.appendChild(m);box.scrollTop=box.scrollHeight;return{el:m,txt:t,acts:a}}

const AI_PROV={
 claude:{label:'Claude (có sẵn trong khung Claude)',proto:'claude'},
 openai:{label:'OpenAI',proto:'openai',base:'https://api.openai.com/v1',models:['gpt-4.1-mini','gpt-4.1','gpt-4o-mini'],key:true},
 anthropic:{label:'Anthropic API',proto:'anthropic',base:'https://api.anthropic.com',models:['claude-sonnet-5-5','claude-haiku-5-5','claude-opus-5-5'],key:true},
 ollama:{label:'Ollama (máy của bạn)',proto:'openai',base:'http://localhost:11434/v1',models:['qwen2.5:7b','llama3.1:8b'],key:false,local:true},
 lmstudio:{label:'LM Studio (máy của bạn)',proto:'openai',base:'http://localhost:1234/v1',models:[],key:false,local:true},
 custom:{label:'OpenAI-compatible khác (OpenRouter, Groq...)',proto:'openai',base:'',models:[],key:true}
};
const inFrame=(()=>{try{return window.self!==window.top}catch(e){return true}})();
const FRAME_MSG='Trang này đang chạy trong khung Claude, nơi chặn kết nối tới API bên ngoài và AI trên máy bạn. Hãy tải bản Antifact về, mở trên máy hoặc đặt lên hosting của bạn để dùng API key hoặc AI local.';
let aiStore={provider:null,byProv:{},see:{}};const aiKeyMem={};
try{const o=JSON.parse(localStorage.getItem('af-ai')||'null');if(o&&typeof o==='object')aiStore=Object.assign(aiStore,o)}catch(e){}
function aiPersist(){try{const c=JSON.parse(JSON.stringify(aiStore));for(const p in c.byProv){if(!c.byProv[p].rem)delete c.byProv[p].key}localStorage.setItem('af-ai',JSON.stringify(c))}catch(e){}}
const aiProvId=()=>aiStore.provider&&AI_PROV[aiStore.provider]&&(aiStore.provider!=='claude'||aiSample)?aiStore.provider:(aiSample?'claude':'openai');
function aiCfg(p){p=p||aiProvId();const d=AI_PROV[p],c=aiStore.byProv[p]||{};return{provider:p,proto:d.proto,base:(c.base!=null?c.base:d.base)||'',key:c.rem===false?(aiKeyMem[p]||''):(c.key!=null?c.key:(aiKeyMem[p]||'')),model:c.model!=null?c.model:((d.models&&d.models[0])||''),json:!!c.json,rem:c.rem!==false}}
function aiReady(){const c=aiCfg();if(c.provider==='claude')return !!aiSample;const d=AI_PROV[c.provider];return !!(c.base.trim()&&c.model.trim()&&(!d.key||c.key.trim()))}
function aiSummary(){const c=aiCfg(),d=AI_PROV[c.provider];$('#aiSum').innerHTML=`${ic('chev')} Cài đặt AI <small>${esc(c.provider==='claude'?'Claude':d.label.split(' (')[0]+(c.model?' · '+c.model:''))}</small>`}
function aiFillForm(){const p=aiProvId(),c=aiCfg(p),d=AI_PROV[p];
  $('#aiProv').innerHTML=Object.entries(AI_PROV).filter(([k])=>k!=='claude'||aiSample).map(([k,v])=>`<option value="${k}" ${k===p?'selected':''}>${esc(v.label)}</option>`).join('');
  const cl=p==='claude';['aiBase','aiModel'].forEach(i=>$('#'+i).closest('label').hidden=cl);$('#aiJson').closest('label').hidden=cl;$('#aiTest').closest('.row').hidden=cl;$('#aiTestOut').hidden=cl;
  $('#aiKeyRow').hidden=cl||!d.key&&false;$('#aiRemRow').hidden=cl;$('#aiTierRow').hidden=!cl;
  $('#aiBase').value=c.base;$('#aiKey').value=c.key;$('#aiKey').placeholder=d.key?'sk-...':'Không bắt buộc với AI local';$('#aiModel').value=c.model;$('#aiJson').checked=c.json;$('#aiRem').checked=c.rem;
  $('#aiModels').innerHTML=(d.models||[]).map(m=>`<option value="${esc(m)}">`).join('');$('#aiTestOut').textContent='';
  const see=aiStore.see[p];$('#aiSee').checked=see!=null?see:(p==='claude');aiSummary()}
function aiSaveForm(){const p=aiProvId();if(p==='claude')return;const rem=$('#aiRem').checked;
  aiStore.provider=p;aiStore.byProv[p]={base:$('#aiBase').value.trim(),key:$('#aiKey').value.trim(),model:$('#aiModel').value.trim(),json:$('#aiJson').checked,rem};aiKeyMem[p]=$('#aiKey').value.trim();aiPersist();aiSummary();aiUi()}
$('#aiProv').addEventListener('change',e=>{aiSaveForm();aiStore.provider=e.target.value;aiPersist();aiFillForm();aiEmpty();aiUi()});
['aiBase','aiKey','aiModel'].forEach(i=>$('#'+i).addEventListener('input',()=>{aiSaveForm();aiEmpty()}));
['aiJson','aiRem'].forEach(i=>$('#'+i).addEventListener('change',()=>aiSaveForm()));
$('#aiSee').addEventListener('change',()=>{aiStore.see[aiProvId()]=$('#aiSee').checked;aiPersist()});

function aiErrText(e,cfg){if(e&&e.net)return inFrame?FRAME_MSG:(AI_PROV[cfg.provider].local?`Không kết nối được tới ${cfg.base}. Kiểm tra server đang chạy và đã bật CORS (Ollama: đặt OLLAMA_ORIGINS=*; LM Studio: bật CORS trong Developer).`:'Không kết nối được. Kiểm tra mạng, Base URL và CORS của nhà cung cấp.');
  const st=e&&e.status;if(st===401||st===403)return'API key không đúng hoặc không có quyền dùng model này.';if(st===404)return'Không tìm thấy model hoặc địa chỉ API. Kiểm tra tên model và Base URL.';if(st===429)return'Hết hạn mức hoặc gọi quá nhanh. Thử lại sau ít phút.';
  if(st){let d='';try{const j=JSON.parse(e.body);d=(j.error&&(j.error.message||j.error))||j.message||''}catch(x){d=e.body||''}return`Máy chủ trả lỗi ${st}${d?': '+String(d).slice(0,200):''}`}
  return e&&e.message?e.message:'Không hoàn thành được yêu cầu.'}
async function aiFetch(url,init){let r;try{r=await fetch(url,init)}catch(e){if(e&&e.name==='AbortError'){const c=new Error('cancelled');c.code='cancelled';throw c}const n=new Error('network');n.net=true;throw n}
  if(!r.ok){let t='';try{t=await r.text()}catch(e){}const er=new Error('HTTP '+r.status);er.status=r.status;er.body=t.slice(0,600);throw er}return r}
const aiBase=c=>c.base.trim().replace(/\/+$/,'');
function aiHeaders(c){if(c.proto==='anthropic')return{'Content-Type':'application/json','x-api-key':c.key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'};const h={'Content-Type':'application/json'};if(c.key)h.Authorization='Bearer '+c.key;return h}
async function aiRunTool(name,args,signal){const t=AI_TOOLS.find(x=>x.name===name);if(!t)return'Error: Không có công cụ '+name;try{const r=await t.execute(args||{},{signal});return typeof r==='string'?r:JSON.stringify(r)}catch(e){return'Error: '+(e&&e.message||e)}}
const toolSchema=t=>t.inputSchema||{type:'object',properties:{}};
async function runOpenAI(c,{history,last,img,signal,onText}){const msgs=[{role:'system',content:AI_RULES},...history,{role:'user',content:img?[{type:'text',text:last},{type:'image_url',image_url:{url:img}}]:last}];
  const tools=AI_TOOLS.map(t=>({type:'function',function:{name:t.name,description:t.description,parameters:toolSchema(t)}}));let out='';
  for(let i=0;i<8;i++){const r=await aiFetch(aiBase(c)+'/chat/completions',{method:'POST',headers:aiHeaders(c),signal,body:JSON.stringify({model:c.model,messages:msgs,tools,tool_choice:'auto'})});
    const j=await r.json();const m=j.choices&&j.choices[0]&&j.choices[0].message;if(!m)throw new Error('Máy chủ không trả về nội dung.');
    msgs.push({role:'assistant',content:m.content||null,...(m.tool_calls&&m.tool_calls.length?{tool_calls:m.tool_calls}:{})});
    if(m.content){out=out?out+'\n\n'+m.content:m.content;onText(out)}
    if(!m.tool_calls||!m.tool_calls.length)break;
    for(const tc of m.tool_calls){let args={},bad=null;try{args=JSON.parse(tc.function.arguments||'{}')}catch(e){bad='Error: arguments không phải JSON hợp lệ'}
      msgs.push({role:'tool',tool_call_id:tc.id,content:bad||await aiRunTool(tc.function.name,args,signal)})}}
  return{text:out||'Đã xong.'}}
async function runAnthropic(c,{history,last,img,signal,onText}){const content=img?[{type:'image',source:{type:'base64',media_type:'image/jpeg',data:img.split(',')[1]}},{type:'text',text:last}]:last;
  const msgs=[...history,{role:'user',content}];const tools=AI_TOOLS.map(t=>({name:t.name,description:t.description,input_schema:toolSchema(t)}));let out='';
  for(let i=0;i<8;i++){const r=await aiFetch(aiBase(c)+'/v1/messages',{method:'POST',headers:aiHeaders(c),signal,body:JSON.stringify({model:c.model,max_tokens:4096,system:AI_RULES,messages:msgs,tools})});
    const j=await r.json();const blocks=j.content||[];msgs.push({role:'assistant',content:blocks});
    const txt=blocks.filter(b=>b.type==='text').map(b=>b.text).join('');if(txt){out=out?out+'\n\n'+txt:txt;onText(out)}
    const uses=blocks.filter(b=>b.type==='tool_use');if(!uses.length||j.stop_reason!=='tool_use')break;
    const res=[];for(const u of uses)res.push({type:'tool_result',tool_use_id:u.id,content:await aiRunTool(u.name,u.input,signal)});msgs.push({role:'user',content:res})}
  return{text:out||'Đã xong.'}}
async function chatOnce(c,{system,history,last,img,signal}){
  if(c.proto==='anthropic'){const content=img?[{type:'image',source:{type:'base64',media_type:'image/jpeg',data:img.split(',')[1]}},{type:'text',text:last}]:last;
    const r=await aiFetch(aiBase(c)+'/v1/messages',{method:'POST',headers:aiHeaders(c),signal,body:JSON.stringify({model:c.model,max_tokens:4096,system,messages:[...history,{role:'user',content}]})});const j=await r.json();return(j.content||[]).filter(b=>b.type==='text').map(b=>b.text).join('')}
  const r=await aiFetch(aiBase(c)+'/chat/completions',{method:'POST',headers:aiHeaders(c),signal,body:JSON.stringify({model:c.model,messages:[{role:'system',content:system},...history,{role:'user',content:img?[{type:'text',text:last},{type:'image_url',image_url:{url:img}}]:last}]})});
  const j=await r.json();return(j.choices&&j.choices[0]&&j.choices[0].message&&j.choices[0].message.content)||''}
async function runJsonMode(c,{history,last,img,signal,onText}){
  const sys=AI_RULES+'\n\nBạn KHÔNG có tool calling. Hãy trả lời CHỈ bằng một đối tượng JSON, không thêm chữ nào ngoài JSON, theo dạng:\n{"reply":"câu trả lời ngắn bằng tiếng Việt","actions":[{"tool":"tên công cụ","args":{...}}]}\nCác công cụ:\n'+AI_TOOLS.filter(t=>t.name!=='get_layers').map(t=>`- ${t.name}: ${t.description} Tham số: ${JSON.stringify(toolSchema(t))}`).join('\n');
  const raw=await chatOnce(c,{system:sys,history,last,img,signal});let o=null;const m=raw.match(/\{[\s\S]*\}/);try{o=JSON.parse(m?m[0]:raw)}catch(e){}
  if(!o||typeof o!=='object')return{text:raw.trim()||'Không hiểu phản hồi của model. Thử bật model mạnh hơn hoặc diễn đạt lại.'};
  const errs=[];for(const a of (Array.isArray(o.actions)?o.actions:[])){const r=await aiRunTool(a.tool,a.args,signal);if(String(r).startsWith('Error:'))errs.push(a.tool+': '+r.slice(7))}
  const text=String(o.reply||'Đã xong.')+(errs.length?'\nMột số bước không áp dụng được: '+errs.join('; '):'');onText(text);return{text}}
async function aiTest(){const c=aiCfg(),out=$('#aiTestOut');out.className='aitest';if(!aiReady()){out.className='aitest bad';out.textContent='Điền đủ Base URL, model và key (nếu dùng dịch vụ có key).';return}
  out.textContent='Đang kiểm tra...';try{const r=await aiFetch(aiBase(c)+(c.proto==='anthropic'?'/v1/models':'/models'),{headers:aiHeaders(c)});const j=await r.json();const ids=(j.data||j.models||[]).map(m=>m.id||m.name).filter(Boolean);
    if(ids.length){$('#aiModels').innerHTML=ids.slice(0,200).map(m=>`<option value="${esc(m)}">`).join('')}
    out.className='aitest ok';out.textContent=`Kết nối được${ids.length?`, thấy ${ids.length} model. Bấm vào ô Model để chọn.`:'.'}`}catch(e){out.className='aitest bad';out.textContent=aiErrText(e,c)}}
$('#aiTest').onclick=aiTest;
$('#aiSet').addEventListener('toggle',()=>document.querySelector('.side').classList.toggle('setopen',$('#aiSet').open));

const AI_ERR={not_granted:'Bạn chưa cho phép trang này dùng Claude.',sampling_disabled:'Tài khoản hoặc tổ chức của bạn chưa bật Claude cho tính năng này.',rate_limited:'Đã gọi quá nhiều hoặc hết lượt dùng. Thử lại sau ít phút.',session_expired:'Phiên đăng nhập đã hết hạn. Hãy đăng nhập lại.',refused:'Claude từ chối yêu cầu này. Hãy thử mô tả khác.',empty_completion:'Claude không trả lời. Hãy thử diễn đạt lại.',prompt_too_large:'Thiết kế quá lớn để gửi. Hãy bớt layer rồi thử lại.',image_rejected:'Không gửi được ảnh canvas. Bỏ chọn "Cho AI xem canvas" rồi thử lại.',tools_unavailable:'Chế độ xem này chưa cho trợ lý chỉnh trực tiếp.',upstream_error:'Kết nối bị gián đoạn. Bấm Gửi để thử lại.'};
function aiCanvasBlob(){return new Promise(res=>{const f=flatten(true),k=Math.min(1,1024/Math.max(doc.w,doc.h)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(doc.w*k));c.height=Math.max(1,Math.round(doc.h*k));c.getContext('2d').drawImage(f,0,0,c.width,c.height);c.toBlob(b=>res(b),'image/jpeg',.85)})}
function aiEmpty(){const box=$('#aiMsgs');if(box.querySelector('.m'))return;box.innerHTML='';const d=document.createElement('div');d.className='aisug';
  if(!aiReady()){d.innerHTML='<p>Chưa có AI nào được kết nối. Mở Cài đặt AI ở trên để nhập API key hoặc địa chỉ AI chạy trên máy bạn.</p>'+(inFrame?`<p>${esc(FRAME_MSG)}</p>`:'');box.appendChild(d);return}
  d.innerHTML='<p>Mô tả việc bạn muốn làm với thiết kế. Một vài gợi ý:</p>'+AI_SUGGEST.map(t=>`<button class="chip" data-s="${esc(t)}">${esc(t)}</button>`).join('');box.appendChild(d)}
function aiCanvasDataUrl(){const f=flatten(true),k=Math.min(1,1024/Math.max(doc.w,doc.h)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(doc.w*k));c.height=Math.max(1,Math.round(doc.h*k));c.getContext('2d').drawImage(f,0,0,c.width,c.height);return c.toDataURL('image/jpeg',.85)}
function aiUi(){const send=$('#aiSend'),ok=aiReady();send.textContent=aiBusy?'Dừng':'Gửi';send.classList.toggle('pri',!aiBusy);$('#aiIn').disabled=!ok;send.disabled=!ok&&!aiBusy}
async function aiGo(text){text=(text||'').trim();if(!text||!aiReady())return;if(aiBusy)return;
  const c=aiCfg();$('#aiSet').open=false;aiBusy=true;aiUi();aiMsg('user',text);const b=aiMsg('assistant','Đang nghĩ...');aiActs=b.acts;const before=snap();aiCtl=new AbortController();
  const onText=t=>{b.txt.textContent=t;const m=$('#aiMsgs');m.scrollTop=m.scrollHeight};
  try{
    const see=$('#aiSee').checked;
    const lastOf=has=>`Trạng thái thiết kế hiện tại (JSON):\n${aiState()}\n\n${has?'Ảnh đính kèm là canvas hiện tại.\n\n':''}Yêu cầu của người dùng: ${text}`;
    let res;
    if(c.provider==='claude'){
      const opts={signal:aiCtl.signal,modelTier:$('#aiTier').value,tools:AI_TOOLS,onText:({text:t})=>onText(t)};
      if(see&&aiLimits&&aiLimits.images){const bl=await aiCanvasBlob();if(bl)opts.images=bl}
      res=await aiSample([{role:'user',content:AI_RULES},...aiTurns.slice(-8),{role:'user',content:lastOf(!!opts.images)}],opts)
    }else{
      const img=see?aiCanvasDataUrl():null;const args={history:aiTurns.slice(-8),last:lastOf(!!img),img,signal:aiCtl.signal,onText};
      const run=c.json?runJsonMode:(c.proto==='anthropic'?runAnthropic:runOpenAI);
      try{res=await run(c,args)}catch(e){
        if(!c.json&&e&&(e.status===400||e.status===422)&&/tool|function/i.test(e.body||'')){onText('Model này chưa hỗ trợ tool calling, chuyển sang chế độ JSON...');res=await runJsonMode(c,args)}else throw e}
    }
    aiTurns.push({role:'user',content:text},{role:'assistant',content:res.text});
    b.txt.textContent=res.text+(res.truncated?'\n(Câu trả lời bị cắt ngắn.)':'')
  }catch(e){
    const code=e&&e.code;
    if(code==='cancelled'){b.txt.textContent=(e.text?e.text+'\n':'')+'Đã dừng. Những thay đổi đã áp dụng vẫn còn, bấm Hoàn tác nếu muốn bỏ.'}
    else{b.el.classList.add('err');b.txt.textContent=(e&&e.text?e.text+'\n':'')+(c.provider==='claude'?(AI_ERR[code]||'Không hoàn thành được yêu cầu. Thử lại sau.'):aiErrText(e,c))}
  }finally{
    aiBusy=false;aiCtl=null;aiActs=null;aiUi();
    if(snap()!==before)commit(true,'Trợ lý AI');else refresh(false)}}
function setTab(t){const ai=t==='ai';$('#side').classList.toggle('aimode',ai);$('#props').hidden=ai;$('#ai').hidden=!ai;$('#tabProps').classList.toggle('on',!ai);$('#tabAi').classList.toggle('on',ai);$('#tabProps').setAttribute('aria-selected',!ai);$('#tabAi').setAttribute('aria-selected',ai);if(ai){if(!aiReady())$('#aiSet').open=true;setTimeout(()=>{const i=$('#aiIn');if(!i.disabled)i.focus()},0)}}
$('#tabProps').innerHTML='Thuộc tính';$('#tabAi').innerHTML=ic('spark')+' Trợ lý AI';$('#aiNew').innerHTML=ic('plus');
$('#tabsB').addEventListener('click',e=>{const b=e.target.closest('button');if(b)setTab(b.dataset.tab)});
$('#aiNew').onclick=()=>{if(aiBusy)return;aiTurns=[];$('#aiMsgs').innerHTML='';aiEmpty()};
$('#aiSend').onclick=()=>{if(aiBusy){aiCtl&&aiCtl.abort();return}const v=$('#aiIn').value;$('#aiIn').value='';aiGo(v)};
$('#aiIn').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();if(!aiBusy){const v=$('#aiIn').value;$('#aiIn').value='';aiGo(v)}}});
$('#aiMsgs').addEventListener('click',e=>{const c=e.target.closest('[data-s]');if(c&&!aiBusy)aiGo(c.dataset.s)});
(async()=>{aiFillForm();aiEmpty();aiUi();
  try{aiSample=window.claude&&window.claude.use?await window.claude.use('sample'):null}catch(e){aiSample=null}
  if(aiSample){try{aiLimits=await aiSample.limits()}catch(e){aiLimits=null}if(!(aiLimits&&aiLimits.tools))aiSample=null}
  if(aiSample&&!aiStore.provider)aiStore.provider='claude';
  aiFillForm();$('#aiMsgs').innerHTML='';aiEmpty();aiUi()})();

/* ---------- Photoshop-style workspace ---------- */
const clampv=(v,a,b)=>Math.min(b,Math.max(a,v));
const normA=a=>((a%360)+540)%360-180;
const BRAND=['#2fd0ee','#ff4f99','#ffd43b','#8b7cf6','#ff8a4c','#4fd88a','#1b1440','#0c0d12','#eceef6'];
const SW=['#000000','#1a1a1a','#4d4d4d','#808080','#b3b3b3','#e6e6e6','#ffffff','#7f0000','#ff0000','#ff7f00','#ffff00','#7fff00','#00ff00','#00ff7f','#00ffff','#007fff','#0000ff','#7f00ff','#ff00ff','#ff007f','#c69c6d','#8b5e3c','#f7d7b5','#3b2f2f','#ffb3c1','#b8f2e6','#cdb4db','#ffd6a5'];
try{const m=JSON.parse(localStorage.getItem('af-sw')||'[]');if(Array.isArray(m))mySw=m.filter(c=>/^#[0-9a-f]{6}$/i.test(c)).slice(0,28)}catch(e){}
const KL={x:'vị trí',y:'vị trí',w:'kích thước',h:'kích thước',rot:'góc xoay',opacity:'độ mờ',blend:'hòa trộn',text:'nội dung chữ',font:'font',size:'cỡ chữ',weight:'độ đậm',color:'màu chữ',fill:'màu nền',fill2:'màu 2',stroke:'màu viền',sw:'viền',radius:'bo góc',ls:'giãn chữ',lh:'giãn dòng',grad:'chuyển màu',gang:'góc chuyển'};
function lbl(k){if(!k)return 'Chỉnh sửa';if(k.startsWith('f.'))return 'Đổi bộ lọc';if(k.startsWith('sh.'))return 'Đổi bóng đổ';return 'Đổi '+(KL[k]||k)}

/* colors */
function syncSw(){const f=$('#fgIn'),b=$('#bgIn');if(f)f.value=brush.color;if(b)b.value=bgc;const bc=$('#bcol');if(bc)bc.value=brush.color;
  if(typeof cpIn!=='undefined'&&cpIn){cpIn.setColor(cpTarget==='fg'?brush.color:bgc,true);const a=$('#tgFg'),c=$('#tgBg');if(a)a.style.background=brush.color;if(c)c.style.background=bgc}}
function setFg(c){brush.color=c;syncSw();if(tool==='grad'||tool==='eyedrop')buildOpts()}
function setBg(c){bgc=c;syncSw();if(tool==='grad')buildOpts()}
function swapColors(){const t=brush.color;brush.color=bgc;bgc=t;syncSw()}
function defColors(){brush.color='#000000';bgc='#ffffff';syncSw()}
function pick(p,alt){const x=Math.floor(p.x),y=Math.floor(p.y);if(x<0||y<0||x>=doc.w||y>=doc.h)return;
  let d;try{d=ctx.getImageData(x,y,1,1).data}catch(e){return}
  const hex='#'+[d[0],d[1],d[2]].map(v=>v.toString(16).padStart(2,'0')).join('');lastPick=hex;alt?setBg(hex):setFg(hex);if(tool==='eyedrop')buildOpts()}

/* status */
function updPos(e){const p=docPt(e);$('#stPos').textContent=Math.round(p.x)+', '+Math.round(p.y)+' px'}
board.addEventListener('pointerleave',()=>{$('#stPos').textContent=''});
function updGrid(){const g=$('#gridov');if(!g)return;g.hidden=!gridOn;const s=gridSize*zoom;g.style.backgroundSize=s+'px '+s+'px'}
function zoomAt(e,f){const p=docPt(e);setZoom(zoom*f);const r=board.getBoundingClientRect();stage.scrollLeft+=r.left+p.x*zoom-e.clientX;stage.scrollTop+=r.top+p.y*zoom-e.clientY}

/* crop */
function showCrop(){const b=$('#cropbox');if(!b)return;if(!crop||tool!=='crop'){b.hidden=true;return}b.hidden=false;Object.assign(b.style,{left:crop.x*zoom+'px',top:crop.y*zoom+'px',width:crop.w*zoom+'px',height:crop.h*zoom+'px'})}
function cropSync(){const m={cx:'x',cy:'y',cw:'w',ch:'h'};document.querySelectorAll('#opts [data-o]').forEach(i=>{const k=m[i.dataset.o];if(k&&crop&&document.activeElement!==i)i.value=Math.round(crop[k])})}
function cropHit(p){if(!crop)return null;const t=12/zoom,{x,y,w,h}=crop;
  const nx=Math.abs(p.x-x)<t?'w':Math.abs(p.x-(x+w))<t?'e':'',ny=Math.abs(p.y-y)<t?'n':Math.abs(p.y-(y+h))<t?'s':'';
  if(!(p.x>x-t&&p.x<x+w+t&&p.y>y-t&&p.y<y+h+t))return null;
  if(nx||ny)return ny+nx;return 'move'}
function cropDown(p,e){let h=cropHit(p);if(h==='move'&&crop.w>=doc.w&&crop.h>=doc.h)h=null;
  if(h){drag={mode:'crop',h,o:{...crop},sx:p.x,sy:p.y}}
  else{drag={mode:'crop',h:'new',sx:clampv(p.x,0,doc.w),sy:clampv(p.y,0,doc.h)};crop={x:drag.sx,y:drag.sy,w:0,h:0}}
  board.setPointerCapture(e.pointerId)}
function cropMove(p){const D=drag,W=doc.w,H=doc.h;
  if(D.h==='move'){crop.x=clampv(D.o.x+p.x-D.sx,0,W-D.o.w);crop.y=clampv(D.o.y+p.y-D.sy,0,H-D.o.h)}
  else if(D.h==='new'){const x1=clampv(p.x,0,W),y1=clampv(p.y,0,H),sx=x1>=D.sx?1:-1,sy=y1>=D.sy?1:-1;let w=Math.abs(x1-D.sx),h=Math.abs(y1-D.sy);
    if(cropRatio){h=w/cropRatio;const mh=sy>0?H-D.sy:D.sy;if(h>mh){h=mh;w=h*cropRatio}}
    crop={x:sx>0?D.sx:D.sx-w,y:sy>0?D.sy:D.sy-h,w,h}}
  else{const o=D.o;let x0=o.x,y0=o.y,x1=o.x+o.w,y1=o.y+o.h;
    if(D.h.includes('w'))x0=clampv(p.x,0,x1-8);if(D.h.includes('e'))x1=clampv(p.x,x0+8,W);
    if(D.h.includes('n'))y0=clampv(p.y,0,y1-8);if(D.h.includes('s'))y1=clampv(p.y,y0+8,H);
    if(cropRatio){const w=x1-x0,h=w/cropRatio;if(D.h.includes('n'))y0=y1-h;else y1=y0+h;if(y0<0||y1>H)return}
    crop={x:x0,y:y0,w:x1-x0,h:y1-y0}}
  showCrop();cropSync()}
function cropUp(){if(!crop||crop.w<4||crop.h<4)crop={x:0,y:0,w:doc.w,h:doc.h};showCrop();buildOpts()}
function applyCrop(x,y,w,h,label){mskClear();x=Math.round(x);y=Math.round(y);w=Math.round(w);h=Math.round(h);if(w<1||h<1)return;
  layers.forEach(l=>{l.x-=x;l.y-=y});doc.w=w;doc.h=h;crop=null;syncDocUi();commit(true,label);fit()}
function cropApply(){if(!crop)return;const c=crop;setTool('select');applyCrop(c.x,c.y,c.w,c.h,'Cắt canvas')}
function setRatio(r){cropRatio=r;if(r&&crop){let w=crop.w,h=w/r;if(crop.y+h>doc.h){h=doc.h-crop.y;w=h*r}crop.w=w;crop.h=h;showCrop();cropSync()}buildOpts()}

/* gradient */
function gradDown(p,e){const l=mk('rect',{x:0,y:0,w:doc.w,h:doc.h,fill:brush.color,fill2:bgc,grad:true,gang:90,name:'Chuyển màu'});layers.push(l);sel=l.id;
  drag={mode:'grad',id:l.id,sx:p.x,sy:p.y,moved:true};board.setPointerCapture(e.pointerId);render();renderLayers()}
function gradMove(l,p,e){const dx=p.x-drag.sx,dy=p.y-drag.sy;if(Math.hypot(dx,dy)<3)return;let a=Math.atan2(dy,dx)*180/Math.PI;if(e.shiftKey)a=Math.round(a/15)*15;l.gang=Math.round(a);render()}

/* layers: new / merge / order / clipboard */
function newLayer(t){let l;
  if(t==='text')l=mk('text',{x:doc.w*.1,y:doc.h*.4,w:doc.w*.8,color:brush.color});
  else if(t==='draw'){l=mk('draw',{x:0,y:0,w:doc.w,h:doc.h,pw:doc.w,ph:doc.h,name:'Layer trống'});const c=document.createElement('canvas');c.width=doc.w;c.height=doc.h;const k=keyId();store.set(k,c.toDataURL('image/png'));l.src=k}
  else{const s=Math.min(doc.w,doc.h)*.35;l=mk(t,{x:(doc.w-s*1.4)/2,y:(doc.h-s)/2,w:s*1.4,h:s,fill:brush.color});if(t==='ellipse'){l.w=l.h=s;l.x=(doc.w-s)/2}}
  addLayer(l);if(t==='draw')setTool('brush');if(t==='text')setTimeout(()=>{const x=$('#txt');if(x){x.focus();x.select()}},0)}
function reorder(id,to){const i=layers.findIndex(l=>l.id===id);if(i<0)return;const j=to==='top'?layers.length-1:to==='bottom'?0:clampv(i+to,0,layers.length-1);if(i===j)return;const [m]=layers.splice(i,1);layers.splice(j,0,m);commit(false,'Đổi thứ tự')}
function selectRel(d){if(!layers.length)return;const i=layers.findIndex(l=>l.id===sel);const j=i<0?(d>0?0:layers.length-1):clampv(i+d,0,layers.length-1);sel=layers[j].id;refresh()}
function rasterize(list,plain,name){let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
  list.forEach(l=>{const b=bounds(l);x0=Math.min(x0,b.x0);y0=Math.min(y0,b.y0);x1=Math.max(x1,b.x1);y1=Math.max(y1,b.y1)});
  x0=Math.max(0,Math.floor(x0));y0=Math.max(0,Math.floor(y0));x1=Math.min(doc.w,Math.ceil(x1));y1=Math.min(doc.h,Math.ceil(y1));
  const w=x1-x0,h=y1-y0;if(w<1||h<1){toast('Layer nằm ngoài canvas, không có gì để gộp.');return null}
  const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.translate(-x0,-y0);list.forEach(l=>drawLayer(x,l,plain));
  const k=keyId();store.set(k,c.toDataURL('image/png'));return mk('draw',{x:x0,y:y0,w,h,pw:w,ph:h,src:k,name:name||'Gộp'})}
function mergeDown(){const i=layers.findIndex(l=>l.id===sel);if(i<1)return;const n=rasterize([layers[i-1],layers[i]],false,layers[i-1].name+' + '+layers[i].name);if(!n)return;layers.splice(i-1,2,n);sel=n.id;commit(true,'Gộp xuống dưới')}
function mergeVisible(){const v=layers.filter(l=>l.visible);if(v.length<2){toast('Cần ít nhất 2 layer đang hiện.');return}const n=rasterize(v,false,'Đã gộp');if(!n)return;
  const out=[];let placed=false;for(const l of layers){if(l.visible){if(!placed){out.push(n);placed=true}}else out.push(l)}layers=out;sel=n.id;commit(true,'Gộp layer hiển thị')}
function rasterOne(){const l=cur();if(!l||l.type==='draw'||l.type==='image'&&false)return;if(l.type==='image'&&!l.sh.on&&filterStr(l)==='none'&&!l.radius){toast('Layer ảnh đã là điểm ảnh.');return}
  const n=rasterize([l],true,l.name);if(!n)return;n.opacity=l.opacity;n.blend=l.blend;layers[layers.indexOf(l)]=n;sel=n.id;commit(true,'Chuyển thành điểm ảnh')}
function copyLayer(){const l=cur();if(!l)return;clip=JSON.stringify(l,(k,v)=>k[0]==='_'?undefined:v);toast('Đã sao chép layer')}
function pasteLayer(){if(!clip)return;const n=JSON.parse(clip);n.id=uid();n.name=n.name+' (dán)';n.x+=24;n.y+=24;
  if(n.type==='draw'&&!n.src){toast('Layer này chưa có dữ liệu để dán.');return}layers.push(n);sel=n.id;commit(true,'Dán layer')}
function alignLayer(a){const l=cur();if(!l||l.locked)return;
  if(a==='al-l')l.x=0;else if(a==='al-c')l.x=(doc.w-l.w)/2;else if(a==='al-r')l.x=doc.w-l.w;else if(a==='al-t')l.y=0;else if(a==='al-m')l.y=(doc.h-l.h)/2;else l.y=doc.h-l.h;commit(true,'Căn layer')}
const txt=()=>{const l=cur();return l&&l.type==='text'?l:null};
function setTxt(fn,label){const l=txt();if(!l)return;fn(l);commit(true,label)}

/* canvas ops */
function rotCanvas(d){mskClear();const W=doc.w,H=doc.h;layers.forEach(l=>{if(l.type==='text')layoutText(l);const cx=l.x+l.w/2,cy=l.y+l.h/2,nx=d>0?H-cy:cy,ny=d>0?cx:W-cx;l.x=nx-l.w/2;l.y=ny-l.h/2;l.rot=Math.round(normA(l.rot+90*d)*10)/10});
  doc.w=H;doc.h=W;syncDocUi();commit(true,'Xoay canvas');fit()}
function flipCanvas(ax){mskClear();const W=doc.w,H=doc.h;layers.forEach(l=>{if(l.type==='text')layoutText(l);const cx=l.x+l.w/2,cy=l.y+l.h/2;
  if(ax==='h'){l.x=W-cx-l.w/2;l.flipX=!l.flipX}else{l.y=H-cy-l.h/2;l.flipY=!l.flipY}l.rot=-l.rot});commit(true,'Lật canvas')}
function trimCanvas(){const v=layers.filter(l=>l.visible);if(!v.length){toast('Không có layer nào đang hiện.');return}
  let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;v.forEach(l=>{const b=bounds(l);x0=Math.min(x0,b.x0);y0=Math.min(y0,b.y0);x1=Math.max(x1,b.x1);y1=Math.max(y1,b.y1)});
  x0=Math.max(0,x0);y0=Math.max(0,y0);x1=Math.min(doc.w,x1);y1=Math.min(doc.h,y1);if(x1-x0<1||y1-y0<1){toast('Layer nằm ngoài canvas.');return}applyCrop(x0,y0,x1-x0,y1-y0,'Cắt theo nội dung')}
function canvasDialog(){const m=modal(`<h2>Kích thước canvas</h2><p>Đổi vùng làm việc. Layer giữ nguyên kích thước và vị trí theo điểm neo.</p>
  <div class="g2" style="margin-bottom:12px"><label class="fld"><span>W</span><input type="number" id="cdW" value="${doc.w}" min="16" max="8000"></label><label class="fld"><span>H</span><input type="number" id="cdH" value="${doc.h}" min="16" max="8000"></label></div>
  <label class="fld" style="margin-bottom:18px"><span style="width:auto">Điểm neo</span><select id="cdA"><option value="c">Giữa</option><option value="tl">Trên trái</option></select></label>
  <div class="row" style="justify-content:flex-end;margin:0"><button class="btn" id="cdX">Hủy</button><button class="btn pri" id="cdOk">Áp dụng</button></div>`);
  m.querySelector('#cdX').onclick=()=>m.remove();
  m.querySelector('#cdOk').onclick=()=>{const w=clampv(parseInt(m.querySelector('#cdW').value)||0,16,8000),h=clampv(parseInt(m.querySelector('#cdH').value)||0,16,8000),c=m.querySelector('#cdA').value==='c';
    const dx=c?(w-doc.w)/2:0,dy=c?(h-doc.h)/2:0;layers.forEach(l=>{l.x+=dx;l.y+=dy});doc.w=w;doc.h=h;m.remove();syncDocUi();commit(true,'Đổi kích thước canvas');fit()}}
function shortcutsDialog(){const R=[['Di chuyển','V'],['Cắt canvas','C'],['Lấy màu','I'],['Chữ','T'],['Hình chữ nhật','R'],['Hình tròn','O'],['Chuyển màu','G'],['Marquee / Lasso','M / L'],['Quick Selection / Magic Wand','W / Shift+W'],['Dao cắt layer','K'],['Chọn tất cả / Layer từ vùng chọn','Ctrl+A / Ctrl+J'],['Xóa / Tô vùng chọn','Delete / Alt+Backspace'],['Cọ vẽ','B'],['Tẩy','E'],['Bàn tay','H'],['Thu phóng','Z'],['Đổi màu trước/nền','X'],['Màu mặc định','D'],['Hoàn tác','Ctrl+Z'],['Làm lại','Ctrl+Shift+Z'],['Nhân đôi layer','Ctrl+D'],['Sao chép / Dán layer','Ctrl+C / V'],['Lưu vào thư viện','Ctrl+S'],['Phóng to / Thu nhỏ','Ctrl+= / -'],['Vừa khung / 100%','Ctrl+0 / 1'],['Kéo canvas','Space + kéo'],['Chọn layer kế','Alt+[ / ]'],['Ẩn bảng điều khiển','Tab'],['Áp dụng cắt / Hủy','Enter / Esc'],['Xóa layer','Delete'],['Nhích layer','Mũi tên (Shift ×10)']];
  const m=modal(`<h2>Phím tắt</h2><p>Các phím tắt chỉ hoạt động khi con trỏ không nằm trong ô nhập.</p><div class="kbd">${R.map(r=>`<div><span>${r[0]}</span><kbd>${r[1]}</kbd></div>`).join('')}</div><div class="row" style="justify-content:flex-end;margin:0"><button class="btn pri" id="kx">Đóng</button></div>`);m.querySelector('#kx').onclick=()=>m.remove()}
function aboutDialog(){const m=modal(`<h2>Antifact 1.1</h2><p>Chỉnh ảnh và thiết kế trên trình duyệt, từ Bravinall. Mỗi layer có thể xuất thành một track riêng trên timeline Bravin.</p><p>Hiện chưa có: layer mask, nhóm layer, chọn vùng, và nhiều tài liệu mở cùng lúc.</p><div class="row" style="justify-content:flex-end;margin:0"><button class="btn pri" id="ax">Đóng</button></div>`);m.querySelector('#ax').onclick=()=>m.remove()}

/* ---------- menus ---------- */
function closeMenu(){if(menuEl){menuEl.remove();menuEl=null}document.querySelectorAll('#menus button.on').forEach(b=>b.classList.remove('on'));menuBtn=null}
function buildMenuDom(items,cls){const box=document.createElement('div');box.className=cls;
  items.forEach(it=>{
    if(it==='-'){box.appendChild(document.createElement('hr'));return}
    if(it.lab){const d=document.createElement('div');d.className='lab';d.textContent=it.lab;box.appendChild(d);return}
    const w=document.createElement('div');w.className='mi';const b=document.createElement('button');b.type='button';
    const dis=typeof it.dis==='function'?it.dis():!!it.dis;if(dis)b.disabled=true;
    const on=typeof it.on==='function'?it.on():it.on;
    b.innerHTML=(it.on!==undefined?`<span class="ck">${on?'✓':''}</span>`:'')+`<span>${esc(it.t)}</span>`+(it.sub?'<span class="arr">▸</span>':(it.k?`<span class="k">${esc(it.k)}</span>`:''));
    w.appendChild(b);
    if(it.sub){const sub=buildMenuDom(typeof it.sub==='function'?it.sub():it.sub,'msub');w.appendChild(sub);w.addEventListener('mouseenter',()=>{const r=w.getBoundingClientRect();sub.classList.toggle('left',r.right+230>innerWidth)})}
    else b.addEventListener('click',()=>{closeMenu();it.f&&it.f()});
    box.appendChild(w)});return box}
function showMenu(items,x,y,up){closeMenu();menuEl=buildMenuDom(items,'mpop');menuEl.style.left=x+'px';menuEl.style.top=y+'px';document.body.appendChild(menuEl);
  const r=menuEl.getBoundingClientRect();if(r.right>innerWidth-8)menuEl.style.left=Math.max(8,innerWidth-r.width-8)+'px';
  if(up)menuEl.style.top=Math.max(8,y-r.height-6)+'px';else if(r.bottom>innerHeight-8)menuEl.style.top=Math.max(8,innerHeight-r.height-8)+'px'}
document.addEventListener('pointerdown',e=>{if(menuEl&&!menuEl.contains(e.target)&&!e.target.closest('#menus')&&!e.target.closest('[data-a=new],[data-a=fx]'))closeMenu()});
window.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});
window.addEventListener('blur',closeMenu);
const isTxt=()=>!!txt(),hasL=()=>!!cur();
const setPanel=t=>{$('#app').classList.remove('nodock');setPa(t)};
const MENUS=[
['Tệp',()=>[{t:'Mới…',f:async()=>{await saveNow();newDialog()}},{t:'Về trang chủ',f:goHome},{t:'Mở project…',f:()=>$('#fileProj').click()},'-',
  {t:'Đặt ảnh vào…',f:()=>$('#fileImg').click()},{t:'Nhập font…',f:()=>$('#fileFont').click()},'-',
  {t:'Lưu vào thư viện',k:'Ctrl+S',f:async()=>{await saveNow();toast('Đã lưu vào thư viện')}},{t:'Lưu file project (.json)',f:()=>saveFile(fname('.antifact.json'),projectJson())},'-',
  {t:'Xuất ảnh',sub:[{t:'PNG (trong suốt)',f:()=>exportImg('png')},{t:'JPG',f:()=>exportImg('jpg')},{t:'WebP',f:()=>exportImg('webp')}]},{t:'Gửi sang Bravin…',f:bravinDialog}]],
['Chỉnh sửa',()=>[{t:'Tô vùng chọn…',k:'Shift+F5',f:fillDialog},{t:'Content-aware fill',dis:!msk,f:contentAware},'-',{t:'Hoàn tác',k:'Ctrl+Z',dis:hi<=0,f:undo},{t:'Làm lại',k:'Ctrl+Shift+Z',dis:hi>=hist.length-1,f:redo},'-',
  {t:'Cắt layer',k:'Ctrl+X',dis:!hasL(),f:()=>{copyLayer();delLayer(sel)}},{t:'Sao chép layer',k:'Ctrl+C',dis:!hasL(),f:copyLayer},{t:'Dán layer',k:'Ctrl+V',dis:!clip,f:pasteLayer},'-',
  {t:'Nhân đôi layer',k:'Ctrl+D',dis:!hasL(),f:()=>dupLayer(sel)},{t:'Xóa layer',k:'Delete',dis:!hasL(),f:()=>delLayer(sel)},'-',{t:'Bỏ chọn',k:'Esc',f:()=>{sel=null;refresh()}}]],
['Ảnh',()=>[{t:'Kích thước canvas…',f:canvasDialog},{t:'Kích thước nhanh',sub:PRESETS.map((p,i)=>({t:p[0]+' · '+p[1]+'×'+p[2],f:()=>{doc.w=p[1];doc.h=p[2];syncDocUi();commit(true,'Đổi kích thước canvas');fit()}}))},'-',
  {t:'Cắt canvas',k:'C',f:()=>setTool('crop')},{t:'Cắt theo nội dung',f:trimCanvas},'-',
  {t:'Xoay canvas 90° phải',f:()=>rotCanvas(1)},{t:'Xoay canvas 90° trái',f:()=>rotCanvas(-1)},{t:'Lật canvas ngang',f:()=>flipCanvas('h')},{t:'Lật canvas dọc',f:()=>flipCanvas('v')}]],
['Layer',()=>[{t:'Layer mới',sub:[{t:'Chữ',f:()=>newLayer('text')},{t:'Hình chữ nhật',f:()=>newLayer('rect')},{t:'Hình tròn',f:()=>newLayer('ellipse')},{t:'Layer trống để vẽ',f:()=>newLayer('draw')},{t:'Ảnh…',f:()=>$('#fileImg').click()}]},
  {t:'Nhóm layer',k:'Ctrl+G',dis:!hasL(),f:groupSel},{t:'Bỏ nhóm',k:'Ctrl+Shift+G',dis:()=>!isGroup(cur()),f:ungroupSel},{t:'Clipping mask',k:'Ctrl+Alt+G',dis:!hasL(),on:()=>!!(cur()&&cur().clipTo),f:toggleClip},'-',
  {t:'Layer điều chỉnh',sub:Object.keys(ADJ).map(k=>({t:ADJ[k].n,f:()=>addAdjust(k)}))},
  {t:'Mặt nạ (Mask)',dis:!hasL(),sub:[{t:'Hiện hết',f:()=>addMaskCmd(cur(),'reveal')},{t:'Ẩn hết',f:()=>addMaskCmd(cur(),'hide')},{t:'Từ vùng chọn',dis:!msk,f:()=>addMaskCmd(cur(),'sel')},{t:'Ẩn vùng chọn',dis:!msk,f:()=>addMaskCmd(cur(),'hidesel')},'-',{t:'Vẽ trên mask / về layer',dis:()=>!(cur()&&cur().mask),f:()=>stageAct('maskpaint')},{t:'Bật / tắt mask',dis:()=>!(cur()&&cur().mask),f:()=>{const l=cur();l.mask.on=l.mask.on===false;commit(true,'Bật/tắt mask')}},{t:'Đảo mask',dis:()=>!(cur()&&cur().mask),f:()=>{const l=cur();l.mask.inv=!l.mask.inv;commit(true,'Đảo mask')}},{t:'Áp mask vào điểm ảnh',dis:()=>!(cur()&&cur().mask),f:()=>stageAct('maskapply')},{t:'Xóa mask',dis:()=>!(cur()&&cur().mask),f:()=>stageAct('maskdel')}]},
  {t:'Kiểu layer (fx)',dis:!hasL(),sub:()=>{const c=cur();if(!c)return[];ensureFx(c);return[{t:'Bóng đổ',on:c.sh.on,f:()=>{const l=cur();l.sh.on=!l.sh.on;commit(true,'Bóng đổ')}},...Object.keys(FXN).map(k=>({t:FXN[k],on:c.fx[k].on,f:()=>toggleFx(k)})),'-',{t:'Xóa mọi hiệu ứng',f:clearFx}]}},'-',
  {t:'Nhân đôi',k:'Ctrl+D',dis:!hasL(),f:()=>dupLayer(sel)},{t:'Xóa',k:'Delete',dis:!hasL(),f:()=>delLayer(sel)},'-',
  {t:'Sắp xếp',dis:!hasL(),sub:[{t:'Đưa lên trên cùng',f:()=>reorder(sel,'top')},{t:'Lên một lớp',f:()=>reorder(sel,1)},{t:'Xuống một lớp',f:()=>reorder(sel,-1)},{t:'Đưa xuống dưới cùng',f:()=>reorder(sel,'bottom')}]},
  {t:'Căn vào canvas',dis:!hasL(),sub:[['al-l','Căn trái'],['al-c','Giữa ngang'],['al-r','Căn phải'],['al-t','Căn trên'],['al-m','Giữa dọc'],['al-b','Căn dưới']].map(a=>({t:a[1],f:()=>alignLayer(a[0])}))},'-',
  {t:'Gộp xuống dưới',dis:()=>layers.findIndex(l=>l.id===sel)<1,f:mergeDown},{t:'Gộp layer đang hiện',f:mergeVisible},{t:'Chuyển thành điểm ảnh',dis:!hasL(),f:rasterOne},'-',
  {t:'Ẩn / hiện',dis:!hasL(),f:()=>{const l=cur();l.visible=!l.visible;commit(false,'Ẩn/hiện layer')}},{t:'Khóa / mở khóa',dis:!hasL(),f:()=>{const l=cur();l.locked=!l.locked;commit(false,'Khóa layer')}},
  {t:'Đổi tên',dis:!hasL(),f:()=>{const n=$('#llist .li.on .nm');n&&n.dispatchEvent(new MouseEvent('dblclick',{bubbles:true}))}}]],
['Slide',()=>[{t:deck?'Slide mới':'Chuyển thành slide…',k:'Ctrl+M',f:()=>deck?addSlide(false):slideDialog()},{t:'Nhân đôi slide',dis:!deck,f:()=>addSlide(true)},{t:'Xóa slide',dis:!deck,f:()=>delSlide(deck.cur)},'-',
  {t:'Slide trước',dis:!deck,f:()=>gotoSlide(deck.cur-1)},{t:'Slide sau',dis:!deck,f:()=>gotoSlide(deck.cur+1)},{t:'Bảng tổng quan',dis:!deck,f:overview},'-',
  {t:'Camera & timeline (2D / 2.5D / 3D)…',dis:!deck,f:()=>openCam()},{t:'Thuộc tính slide',dis:!deck,f:()=>{sel=null;msel=new Set();refresh();setTab('props')}},{t:'Tự chia độ sâu Z (2.5D / 3D)',dis:!deck,f:()=>{autoDepth(deck.slides[deck.cur]);commit(true,'Chia độ sâu')}},'-',
  {t:'Trình chiếu',k:'F5',dis:!deck,f:()=>present(deck.cur)},{t:'Xuất video MP4 / GIF…',dis:!deck,f:exportDlg},{t:'Xuất mọi slide thành PNG',dis:!deck,f:exportSlidesPng}]],
['Chữ',()=>[{t:'Layer chữ mới',k:'T',f:()=>newLayer('text')},'-',
  {t:'Font',dis:!isTxt(),sub:()=>[...[...fontRecent,...FONTS.filter(x=>!fontRecent.includes(x))].slice(0,14).map(f=>({t:f,on:isTxt()&&txt().font===f,f:()=>{setTxt(l=>l.font=f,'Đổi font');document.fonts.load(`700 40px "${f}"`).then(render)}})),'-',{t:'Thư viện Google Fonts…',f:fontPicker},{t:'Nhập font từ máy…',f:()=>$('#fileFont').click()}]},
  {t:'Căn trái',dis:!isTxt(),f:()=>setTxt(l=>l.align='left','Căn chữ')},{t:'Căn giữa',dis:!isTxt(),f:()=>setTxt(l=>l.align='center','Căn chữ')},{t:'Căn phải',dis:!isTxt(),f:()=>setTxt(l=>l.align='right','Căn chữ')},'-',
  {t:'In đậm',dis:!isTxt(),on:()=>isTxt()&&txt().weight>=700,f:()=>setTxt(l=>l.weight=l.weight>=700?400:700,'Độ đậm')},
  {t:'Nghiêng',dis:!isTxt(),on:()=>isTxt()&&!!txt().italic,f:()=>setTxt(l=>l.italic=!l.italic,'Nghiêng')},
  {t:'CHỮ HOA',dis:!isTxt(),on:()=>isTxt()&&!!txt().caps,f:()=>setTxt(l=>l.caps=!l.caps,'Chữ hoa')},
  {t:'Gạch chân',dis:!isTxt(),on:()=>isTxt()&&!!txt().under,f:()=>setTxt(l=>l.under=!l.under,'Gạch chân')},'-',
  {t:'Tăng cỡ chữ 10%',dis:!isTxt(),f:()=>setTxt(l=>l.size=Math.round(l.size*1.1),'Cỡ chữ')},{t:'Giảm cỡ chữ 10%',dis:!isTxt(),f:()=>setTxt(l=>l.size=Math.max(6,Math.round(l.size/1.1)),'Cỡ chữ')}]],
['Chọn',()=>[{t:'Tất cả',k:'Ctrl+A',f:selAll},{t:'Bỏ chọn vùng',k:'Esc',dis:!msk,f:selNone},{t:'Đảo ngược vùng chọn',f:selInvert},
  {t:'Mở rộng vùng chọn',dis:!msk,sub:[2,5,10,20].map(v=>({t:v+' px',f:()=>growMask(v,1)}))},{t:'Thu hẹp vùng chọn',dis:!msk,sub:[2,5,10,20].map(v=>({t:v+' px',f:()=>growMask(v,-1)}))},'-',
  {t:'Layer từ vùng chọn (sao chép)',k:'Ctrl+J',dis:!msk,f:()=>selLayer(false)},{t:'Cắt vùng chọn ra layer mới',dis:!msk,f:()=>selLayer(true)},{t:'Xóa vùng chọn',k:'Delete',dis:!msk,f:eraseSel},
  {t:'Tô vùng chọn…',k:'Shift+F5',f:fillDialog},{t:'Content-aware fill',dis:!msk,f:contentAware},{t:'Tô màu trước',k:'Alt+Backspace',dis:!msk,f:()=>fillSel(brush.color)},{t:'Tô màu nền',k:'Ctrl+Backspace',dis:!msk,f:()=>fillSel(bgc)},{t:'Cắt canvas theo vùng chọn',dis:!msk,f:cropToSel},'-',
  {t:'Bỏ chọn layer',f:()=>{sel=null;refresh()}},{t:'Layer kế trên',k:'Alt+]',f:()=>selectRel(1)},{t:'Layer kế dưới',k:'Alt+[',f:()=>selectRel(-1)},
  {t:'Layer trên cùng',f:()=>{if(layers.length){sel=layers[layers.length-1].id;refresh()}}},{t:'Layer dưới cùng',f:()=>{if(layers.length){sel=layers[0].id;refresh()}}}]],
['Bộ lọc',()=>[{lab:'Chuẩn màu cho layer'},...Object.keys(FILTER_PRESETS).map(n=>({t:n,dis:!hasL(),f:()=>{const l=cur();l.f={...F0,...FILTER_PRESETS[n]};commit(true,'Bộ lọc '+n)}})),'-',
  {t:'Làm mờ',dis:!hasL(),sub:[2,5,10,20,40].map(v=>({t:v+' px',f:()=>{const l=cur();l.f.blur=v;commit(true,'Làm mờ '+v+'px')}}))},
  {t:'Bộ lọc thông minh',dis:!hasL(),sub:Object.keys(SF).map(k=>({t:SF[k].n,f:()=>addSF(k)}))},
  {t:'Xóa mọi hiệu ứng',dis:!hasL(),f:clearFx}]],
['Xem',()=>[{t:'Phóng to',k:'Ctrl+=',f:()=>setZoom(zoom*1.2)},{t:'Thu nhỏ',k:'Ctrl+-',f:()=>setZoom(zoom/1.2)},{t:'Vừa khung',k:'Ctrl+0',f:fit},{t:'100%',k:'Ctrl+1',f:()=>setZoom(1)},{t:'200%',f:()=>setZoom(2)},'-',
  {t:'Lưới',on:gridOn,f:()=>{gridOn=!gridOn;updGrid()}},{t:'Cỡ ô lưới',sub:[10,20,50,100].map(v=>({t:v+' px',on:gridSize===v,f:()=>{gridSize=v;gridOn=true;updGrid()}}))},
  {t:'Gióng thông minh',on:snapOn,f:()=>{snapOn=!snapOn;toast(snapOn?'Đã bật gióng khi kéo layer':'Đã tắt gióng')}},'-',
  {t:'Ẩn / hiện bảng điều khiển',k:'Tab',f:()=>$('#app').classList.toggle('nodock')}]],
['Cửa sổ',()=>[{t:'Màu',f:()=>setPanel('sw')},{t:'Chữ',f:()=>setPanel('char')},{t:'Lịch sử',f:()=>setPanel('hist')},{t:'Điều hướng',f:()=>setPanel('nav')},'-',
  {t:'Thuộc tính',f:()=>{$('#app').classList.remove('nodock');setTab('props')}},{t:'Trợ lý AI',f:()=>{$('#app').classList.remove('nodock');setTab('ai')}}]],
['Trợ giúp',()=>[{t:'Phím tắt…',f:shortcutsDialog},{t:'Giới thiệu Antifact',f:aboutDialog}]]];
$('#menus').innerHTML=MENUS.map((m,i)=>`<button type="button" data-m="${i}">${m[0]}</button>`).join('');
function openMenuBtn(b){const r=b.getBoundingClientRect();showMenu(MENUS[+b.dataset.m][1](),r.left,r.bottom+2);b.classList.add('on');menuBtn=b}
$('#menus').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(menuBtn===b)closeMenu();else openMenuBtn(b)});
$('#menus').addEventListener('pointerover',e=>{const b=e.target.closest('button');if(b&&menuEl&&menuBtn!==b)openMenuBtn(b)});
function newLayerMenu(b){const r=b.getBoundingClientRect();showMenu([{t:'Chữ',f:()=>newLayer('text')},{t:'Hình chữ nhật',f:()=>newLayer('rect')},{t:'Hình tròn',f:()=>newLayer('ellipse')},{t:'Layer trống để vẽ',f:()=>newLayer('draw')},{t:'Ảnh…',f:()=>$('#fileImg').click()}],r.left,r.top,true)}
function fxMenu(b){const l=cur();if(!l)return;const r=b.getBoundingClientRect();showMenu([{t:'Bóng đổ',on:l.sh.on,f:()=>{l.sh.on=!l.sh.on;commit(true,'Bóng đổ')}},{t:'Làm mờ 10px',f:()=>{l.f.blur=10;commit(true,'Làm mờ')}},{t:'Trắng đen',f:()=>{l.f={...F0,gray:100};commit(true,'Trắng đen')}},'-',{t:'Xóa hiệu ứng',f:()=>{l.f={...F0};l.sh.on=false;commit(true,'Xóa hiệu ứng')}}],r.left,r.top,true)}

/* ---------- panel group A ---------- */
function setPa(t){paTab=t;document.querySelectorAll('#tabsA button').forEach(b=>b.classList.toggle('on',b.dataset.pa===t));document.querySelectorAll('.dgA .pnl').forEach(p=>p.hidden=p.dataset.pa!==t);renderPa()}
function renderPa(){if(paTab==='sw')renderSw();else if(paTab==='char')buildChar();else if(paTab==='hist')renderHist();else buildNav()}
$('#tabsA').addEventListener('click',e=>{const b=e.target.closest('button');if(b)setPa(b.dataset.pa)});
function renderSw(){if(!$('#cpHost')){$('#pSw').innerHTML='<div id="cpHost"></div><div id="swList"></div>';buildCpInline()}
  const sw=c=>`<button class="swc" data-c="${c}" style="background:${c}" title="${c}" aria-label="${c}"></button>`;
  $('#swList').innerHTML=`<div class="swlab">Gần đây</div><div class="swgrid">${recentCols.length?recentCols.map(sw).join(''):'<span class="swnote" style="padding:0">Chưa có màu nào.</span>'}</div><div class="swlab">Bảng màu Antifact</div><div class="swgrid">${BRAND.map(sw).join('')}</div><div class="swlab">Mẫu màu</div><div class="swgrid">${SW.map(sw).join('')}</div><div class="swlab">Của bạn</div><div class="swgrid">${mySw.map(sw).join('')}<button class="swc" data-add="1" title="Lưu màu trước vào đây" aria-label="Thêm màu" style="background:transparent;color:var(--mute);font-weight:700">+</button></div><div class="swnote">Nhấp: màu trước. Alt+nhấp: màu nền. Ctrl+nhấp: tô layer đang chọn.</div>`}
$('#pSw').addEventListener('click',e=>{const b=e.target.closest('.swc');if(!b)return;
  if(b.dataset.add){if(!mySw.includes(brush.color)){mySw.unshift(brush.color);mySw=mySw.slice(0,28);try{localStorage.setItem('af-sw',JSON.stringify(mySw))}catch(x){}renderSw()}return}
  const c=b.dataset.c;if(e.ctrlKey||e.metaKey){const l=cur(),k=l&&(l.type==='text'?'color':(l.type==='rect'||l.type==='ellipse')?'fill':null);if(k){l[k]=c;commit(true,'Tô màu')}else toast('Chọn layer chữ hoặc hình khối để tô màu.');return}
  if(e.altKey)setBg(c);else{setFg(c);applyFg(c,true)}});
function renderHist(){const el=$('#pHist');if(!el||paTab!=='hist')return;
  el.innerHTML='<div class="hl">'+hist.map((h,i)=>`<button data-i="${i}" class="${i===hi?'on':i>hi?'fut':''}"><span class="n">${i+1}</span>${esc(hnames[i]||'Chỉnh sửa')}</button>`).join('')+'</div>';
  const o=el.querySelector('.on');if(o)o.scrollIntoView({block:'nearest'})}
$('#pHist').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const i=+b.dataset.i;if(i===hi)return;hi=i;loadSnap(hist[hi]);updHistBtns()});
function buildChar(){const el=$('#pChar'),l=txt();if(!el)return;
  if(!l){el.innerHTML=`<div class="cp"><div class="empty">Chọn một layer chữ để chỉnh font, cỡ chữ, giãn dòng và giãn chữ.</div><div class="row"><button class="btn" data-o="tooltext">${ic('text')} Dùng công cụ Chữ</button><button class="btn" data-act="addfont">${ic('plus')} Nhập font</button></div></div>`;return}
  const tb=(a,t,tx,ex,v)=>`<button class="btn tbtn" data-act="${a}" title="${t}" style="${ex}${v?';border-color:var(--accent);color:var(--accent)':''}">${tx}</button>`;
  el.innerHTML=`<div class="cp"><div class="row">${fontBtn(l)}<button class="btn ic" data-act="addfont" title="Nhập font từ máy (.ttf .otf .woff .woff2)" aria-label="Nhập font">${ic('plus')}</button></div>
  <div class="row"><select data-k="weight" data-t="n" aria-label="Độ đậm" style="flex:1">${[300,400,500,600,700,800,900].map(w=>`<option value="${w}" ${w===l.weight?'selected':''}>${w}</option>`).join('')}</select>
  ${tb('italic','Nghiêng','I','font-style:italic',l.italic)}${tb('caps','CHỮ HOA','TT','',l.caps)}${tb('under','Gạch chân','U','text-decoration:underline',l.under)}</div>
  <div class="g3">${numF(l,'Aa','size',{min:6})}${numF(l,'↕','lh',{step:.05})}${numF(l,'↔','ls',{step:.5})}</div>
  <div class="row"><label class="fld" style="flex:none"><span>Màu</span><input type="color" data-k="color" value="${l.color}" aria-label="Màu chữ"></label><label class="fld" style="flex:none"><span>Viền</span><input type="color" data-k="stroke" value="${l.stroke}" aria-label="Màu viền chữ"></label><span class="sp"></span><span class="seg">${['left','center','right'].map(a=>btnA('ta-'+a,'ta-'+a,'Căn '+a,l.align===a)).join('')}</span></div>
  <div class="empty" style="font:500 11px var(--mono)">Aa ↕ giãn dòng · ↔ giãn chữ</div></div>`}
function buildNav(){const el=$('#pNav');if(!el)return;if(!el.firstChild){el.innerHTML=`<div class="navw"><div class="navbox" id="navbox"><canvas id="navc"></canvas><div class="vp" id="navvp"></div></div><div class="navz"><button class="btn ic" data-n="-" aria-label="Thu nhỏ">${ic('minus')}</button><input type="range" id="navzr" min="5" max="400" aria-label="Thu phóng"><button class="btn ic" data-n="+" aria-label="Phóng to">${ic('plus')}</button><output id="navzo"></output></div></div>`;
  const nb=$('#navbox');const go=e=>{const r=nb.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*doc.w,y=(e.clientY-r.top)/r.height*doc.h;stage.scrollLeft=board.offsetLeft+x*zoom-stage.clientWidth/2;stage.scrollTop=board.offsetTop+y*zoom-stage.clientHeight/2};
  nb.addEventListener('pointerdown',e=>{nb.setPointerCapture(e.pointerId);go(e)});nb.addEventListener('pointermove',e=>{if(e.buttons)go(e)});
  $('#navzr').addEventListener('input',e=>setZoom(+e.target.value/100));el.addEventListener('click',e=>{const b=e.target.closest('[data-n]');if(b)setZoom(zoom*(b.dataset.n==='+'?1.2:1/1.2))})}
  doNav()}
function doNav(){const nb=$('#navbox');if(!nb||paTab!=='nav')return;const W=$('#pNav').clientWidth-24;if(W<20)return;const s=Math.min(W/doc.w,150/doc.h),w=Math.round(doc.w*s),h=Math.round(doc.h*s);
  nb.style.width=w+'px';nb.style.height=h+'px';const c=$('#navc');if(c.width!==w||c.height!==h){c.width=w;c.height=h}const x=c.getContext('2d');x.clearRect(0,0,w,h);x.drawImage(ctx.canvas,0,0,w,h);
  const x0=clampv((stage.scrollLeft-board.offsetLeft)/zoom,0,doc.w),x1=clampv((stage.scrollLeft+stage.clientWidth-board.offsetLeft)/zoom,0,doc.w),y0=clampv((stage.scrollTop-board.offsetTop)/zoom,0,doc.h),y1=clampv((stage.scrollTop+stage.clientHeight-board.offsetTop)/zoom,0,doc.h);
  Object.assign($('#navvp').style,{left:x0*s+'px',top:y0*s+'px',width:Math.max(4,(x1-x0)*s)+'px',height:Math.max(4,(y1-y0)*s)+'px'});
  $('#navzr').value=Math.round(zoom*100);$('#navzo').textContent=Math.round(zoom*100)+'%'}
function updNav(){if(paTab!=='nav'||navT)return;navT=setTimeout(()=>{navT=0;doNav()},90)}
stage.addEventListener('scroll',updNav);

/* ---------- options bar ---------- */
const RATIOS=[['Tự do',null],['1:1',1],['16:9',16/9],['4:5',.8],['9:16',9/16],['3:2',1.5]];
function buildOpts(){const el=$('#opts');if(!el)return;const l=cur(),t=TOOLS.find(x=>x[0]===tool)||TOOLS[0];
  let h=`<span class="otool">${ic(t[1])}${t[2].replace(/ \(.\)$/,'')}</span><span class="vsep"></span>`;
  if(tool==='select'){
    if(l){const AL=[['al-l','Căn trái'],['al-c','Giữa ngang'],['al-r','Căn phải'],['al-t','Căn trên'],['al-m','Giữa dọc'],['al-b','Căn dưới']];
      h+=numF(l,'X','x')+numF(l,'Y','y')+numF(l,'W','w')+numF(l,'H','h',{ro:l.type==='text'})+numF(l,'∠','rot')+`<span class="vsep"></span><span class="seg">${AL.map(a=>btnA(a[0],a[0],a[1]+' canvas')).join('')}</span><span class="seg">${btnA('flipX','flipH','Lật ngang',l.flipX)}${btnA('flipY','flipV','Lật dọc',l.flipY)}</span>`}
    else h+='<span class="ohint">Nhấp layer để chọn, kéo để di chuyển. Giữ Alt để tắt gióng. Dùng Space hoặc chuột giữa để kéo canvas.</span>'}
  else if(tool==='text'){
    if(l&&l.type==='text')h+=`${fontBtn(l)}<button class="btn ic" data-act="addfont" title="Nhập font từ máy" aria-label="Nhập font">${ic('plus')}</button><select data-k="weight" data-t="n" aria-label="Độ đậm">${[300,400,500,600,700,800,900].map(w=>`<option value="${w}" ${w===l.weight?'selected':''}>${w}</option>`).join('')}</select>${numF(l,'Aa','size',{min:6})}${colF(l,'color','')}<span class="seg">${['left','center','right'].map(a=>btnA('ta-'+a,'ta-'+a,'Căn '+a,l.align===a)).join('')}</span>`;
    else h+=`<span class="ohint">Nhấp lên canvas để tạo chữ. Màu chữ lấy từ màu trước.</span><button class="btn ic" data-act="addfont" title="Nhập font từ máy" aria-label="Nhập font">${ic('plus')}</button>`}
  else if(tool==='rect'||tool==='ellipse'){
    if(l&&(l.type==='rect'||l.type==='ellipse'))h+=`${colF(l,'fill','Màu')}${colF(l,'stroke','Viền')}${rngF(l,'Viền','sw',0,60,1,1,'px')}${l.type==='rect'?rngF(l,'Bo góc','radius',0,Math.round(Math.min(l.w,l.h)/2)||1,1,1,'px'):''}`;
    else h+='<span class="ohint">Kéo trên canvas để vẽ hình. Màu nền lấy từ màu trước.</span>'}
  else if(PIXTOOLS.includes(tool))h+=paintOpts();
  else if(SELT.includes(tool)){
    h+=`<span class="seg">${[['new','Mới','Vùng chọn mới'],['add','＋','Thêm vào vùng chọn (Shift)'],['sub','－','Trừ khỏi vùng chọn (Alt)']].map(m=>`<button class="btn tbtn ${selMode===m[0]?'on':''}" data-o="smode" data-v="${m[0]}" title="${m[2]}">${m[1]}</button>`).join('')}</span>`;
    if(tool==='marq')h+=`<span class="chips"><button class="chip ${marqShape==='rect'?'on':''}" data-o="mshape" data-v="rect">Chữ nhật</button><button class="chip ${marqShape==='ell'?'on':''}" data-o="mshape" data-v="ell">Elip</button></span>`;
    if(tool==='qsel')h+=`<div class="rng"><span>Cỡ cọ</span><input type="range" data-o="qsz" min="10" max="300" value="${qsz}"><output>${qsz}px</output></div>`;
    if(tool==='qsel'||tool==='wand')h+=`<div class="rng"><span>Dung sai</span><input type="range" data-o="tol" min="0" max="120" value="${tolV}"><output>${tolV}</output></div>`;
    if(tool==='wand')h+=`<label class="row" style="gap:5px"><input type="checkbox" data-o="contig" ${contig?'checked':''}> Liền kề</label>`;
    h+=`<span class="vsep"></span><button class="btn" data-o="sall">Tất cả</button><button class="btn" data-o="sinv">Đảo ngược</button><button class="btn" data-o="sdesel" ${msk?'':'disabled'}>Bỏ chọn</button><button class="btn" data-o="slayer" ${msk?'':'disabled'} title="Ctrl+J">Layer từ vùng chọn</button><button class="btn pri" data-o="scaf" ${msk?'':'disabled'} title="Xóa vật thể và lấp bằng nền xung quanh">Content-aware fill</button>`}
  else if(tool==='razor')h+=`<label class="row" style="gap:5px"><input type="checkbox" data-o="rzall" ${razorAll?'checked':''}> Cắt mọi layer bị đường cắt đi qua</label><span class="ohint">Kéo một đường. Layer đang chọn tách thành 2 layer riêng, mỗi layer là một track khi gửi sang Bravin. Shift: khóa góc 15°. Alt: cắt mọi layer.</span>`;
  else if(tool==='crop'){
    h+=`<span class="chips">${RATIOS.map(r=>`<button class="chip ${cropRatio===r[1]?'on':''}" data-o="ratio" data-v="${r[1]||''}">${r[0]}</button>`).join('')}</span><span class="vsep"></span>`;
    if(crop)h+=['cx:X','cy:Y','cw:W','ch:H'].map(s=>{const[k,n]=s.split(':'),v={cx:'x',cy:'y',cw:'w',ch:'h'}[k];return `<label class="fld"><span>${n}</span><input type="number" data-o="${k}" value="${Math.round(crop[v])}"></label>`}).join('');
    h+=`<button class="btn pri" data-o="apply">Áp dụng</button><button class="btn" data-o="cancel">Đặt lại</button>`}
  else if(tool==='grad')h+=`<span class="gradbar" style="background:linear-gradient(90deg,${brush.color},${bgc})"></span><span class="ohint">Kéo trên canvas để tạo layer chuyển màu từ màu trước sang màu nền. Giữ Shift để khóa góc 15°.</span>`;
  else if(tool==='eyedrop')h+=`<span class="ohint">Nhấp để lấy màu vào màu trước. Alt+nhấp để lấy vào màu nền.</span>${lastPick?`<span class="sw" style="background:${lastPick}"></span><span class="mono">${lastPick}</span>`:''}`;
  else if(tool==='hand')h+='<span class="ohint">Kéo để di chuyển canvas.</span>';
  else if(tool==='zoom')h+=`<span class="ohint">Nhấp để phóng to, Alt+nhấp để thu nhỏ.</span><button class="btn" data-o="z1">100%</button><button class="btn" data-o="zf">Vừa khung</button>`;
  el.innerHTML=h}
function optIn(t){const o=t.dataset.o;if(slOpt(t))return;if(ptOpt(t))return;
  if(o==='bsize'){brush.size=+t.value;if(t.nextElementSibling)t.nextElementSibling.textContent=t.value+'px';const b=$('#bsize');if(b){b.value=t.value;$('#bout').textContent=t.value+'px'}return}
  if(o==='qsz'){qsz=+t.value;t.nextElementSibling.textContent=qsz+'px';return}
  if(o==='tol'){tolV=+t.value;t.nextElementSibling.textContent=tolV;return}
  if(o==='contig'){contig=t.checked;return}
  if(o==='rzall'){razorAll=t.checked;return}
  const m={cx:'x',cy:'y',cw:'w',ch:'h'}[o];if(m&&crop){let v=parseFloat(t.value);if(isNaN(v))return;
    if(m==='x')v=clampv(v,0,doc.w-crop.w);else if(m==='y')v=clampv(v,0,doc.h-crop.h);else if(m==='w')v=clampv(v,1,doc.w-crop.x);else v=clampv(v,1,doc.h-crop.y);crop[m]=v;showCrop()}}
function optCh(t){}
function optBtn(b){const o=b.dataset.o;if(slBtn(b))return;if(ptBtn(b))return;
  if(o==='ratio')setRatio(b.dataset.v?+b.dataset.v:null);
  else if(o==='smode'){selMode=b.dataset.v;buildOpts()}
  else if(o==='mshape'){marqShape=b.dataset.v;buildOpts()}
  else if(o==='sall')selAll();else if(o==='sinv')selInvert();else if(o==='sdesel')selNone();else if(o==='slayer')selLayer(false);else if(o==='scaf')contentAware()
  else if(o==='apply')cropApply();
  else if(o==='cancel'){crop={x:0,y:0,w:doc.w,h:doc.h};cropRatio=null;showCrop();buildOpts()}
  else if(o==='tooltext')setTool('text');
  else if(o==='z1')setZoom(1);else if(o==='zf')fit()}
function syncPanels(from){if(from!==$('#opts'))buildOpts();if(from!==$('#pChar'))buildChar();if(from!==$('#props'))buildProps0()}

/* ---------- layer panel extras ---------- */
$('#lblend').innerHTML=Object.keys(BLEND).map(b=>`<option value="${b}">${BLEND_VI[b]}</option>`).join('');
function syncLctl(){const l=cur(),b=$('#lblend'),o=$('#lop');if(!b)return;b.disabled=o.disabled=!l;if(l){b.value=l.blend;if(document.activeElement!==o)o.value=Math.round(l.opacity*100)}else o.value=''}
$('#lblend').addEventListener('change',e=>{const l=cur();if(!l)return;l.blend=e.target.value;commit(true,'Đổi hòa trộn')});
$('#lop').addEventListener('input',e=>{const l=cur();if(!l)return;const v=parseFloat(e.target.value);if(isNaN(v))return;l.opacity=clampv(v,0,100)/100;render();queueLayers()});
$('#lop').addEventListener('change',()=>commit(true,'Đổi độ mờ'));

/* ---------- shell wiring ---------- */
$('#tabClose').innerHTML=ic('x');$('#tabNew').innerHTML=ic('plus');
$('#tabClose').onclick=goHome;$('#tabNew').onclick=async()=>{await saveNow();newDialog()};
$('#zlabel').onclick=()=>setZoom(1);
$('#fgIn').addEventListener('change',()=>applyDone());
$('#fgIn').addEventListener('input',e=>{brush.color=e.target.value;applyFg(brush.color,false);const bc=$('#bcol');if(bc)bc.value=brush.color;if(tool==='grad'||tool==='brush')buildOpts()});
$('#bgIn').addEventListener('input',e=>{bgc=e.target.value;if(tool==='grad')buildOpts()});
$('#swapBtn').onclick=swapColors;$('#defBtn').onclick=defColors;
[props,$('#opts'),$('#pChar')].forEach(c=>{c.addEventListener('input',onPI);c.addEventListener('change',onPC);c.addEventListener('click',onPK)});
(()=>{const side=$('#side');let st=null;
  side.addEventListener('pointerdown',e=>{const sp=e.target.closest('.split');if(!sp)return;const t=sp.dataset.s==='a'?side.querySelector('.dgA'):side.querySelector('.layers');
    st={sp,t,y:e.clientY,h:t.getBoundingClientRect().height,k:sp.dataset.s};sp.classList.add('on');sp.setPointerCapture(e.pointerId)});
  side.addEventListener('pointermove',e=>{if(!st)return;const d=e.clientY-st.y,h=clampv(st.k==='a'?st.h+d:st.h-d,70,Math.max(120,side.clientHeight-260));st.t.style.flex='0 0 '+h+'px'});
  const end=()=>{if(st){st.sp.classList.remove('on');st=null}};side.addEventListener('pointerup',end);side.addEventListener('pointercancel',end)})();

/* ---------- selection tools & razor ---------- */
const SELT=['marq','lasso','qsel','wand'];
function mskClear(){msk=null;mskB=null;mskVer++;queueAnts()}
function mskCombine(base,m2,mode){const n=doc.w*doc.h;if(mode==='new'||!base)return mode==='sub'&&!base?new Uint8Array(n):m2;
  const o=base.slice();if(mode==='add'){for(let i=0;i<n;i++)if(m2[i])o[i]=255}else{for(let i=0;i<n;i++)if(m2[i])o[i]=0}return o}
function setMask(a){msk=a;mskVer++;mskB=null;if(msk){const W=doc.w,H=doc.h;let x0=W,y0=H,x1=-1,y1=-1;for(let y=0;y<H;y++){const r=y*W;for(let x=0;x<W;x++)if(msk[r+x]){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}}
  if(x1<0)msk=null;else mskB={x0,y0,x1,y1}}queueAnts()}
function queueAnts(){if(antRaf)return;antRaf=requestAnimationFrame(()=>{antRaf=0;drawAnts()})}
function drawAnts(){const c=$('#ants');if(!c)return;if(msk&&msk.length!==doc.w*doc.h){msk=null;mskB=null}
  const w=Math.max(1,Math.round(doc.w*zoom)),h=Math.max(1,Math.round(doc.h*zoom)),key=zoom+'|'+mskVer+'|'+doc.w+'|'+doc.h;if(key===antKey&&c.width===w)return;antKey=key;c.width=w;c.height=h;if(!msk)return;
  const x=c.getContext('2d'),img=x.createImageData(w,h),d=img.data,W=doc.w,H=doc.h,cx=new Int32Array(w),cy=new Int32Array(h);
  for(let i=0;i<w;i++)cx[i]=Math.min(W-1,Math.floor(i/zoom));for(let j=0;j<h;j++)cy[j]=Math.min(H-1,Math.floor(j/zoom))*W;
  for(let y=0;y<h;y++)for(let xx=0;xx<w;xx++){if(!msk[cy[y]+cx[xx]])continue;
    const l=xx>0&&msk[cy[y]+cx[xx-1]],r=xx<w-1&&msk[cy[y]+cx[xx+1]],u=y>0&&msk[cy[y-1]+cx[xx]],dn=y<h-1&&msk[cy[y+1]+cx[xx]];
    if(l&&r&&u&&dn)continue;const k=(y*w+xx)*4,v=((xx+y)>>2&1)?255:0;d[k]=d[k+1]=d[k+2]=v;d[k+3]=255}
  x.putImageData(img,0,0)}
function flood(d,sx,sy,tol,contig,circ){const W=doc.w,H=doc.h,out=new Uint8Array(W*H),i0=(sy*W+sx)*4,r0=d[i0],g0=d[i0+1],b0=d[i0+2],a0=d[i0+3];
  const ok=i=>{const j=i*4;return Math.abs(d[j]-r0)<=tol&&Math.abs(d[j+1]-g0)<=tol&&Math.abs(d[j+2]-b0)<=tol&&Math.abs(d[j+3]-a0)<=tol};
  const inC=circ?(x,y)=>{const dx=x-circ.x,dy=y-circ.y;return dx*dx+dy*dy<=circ.r*circ.r}:()=>true;
  if(!contig){for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=y*W+x;if(ok(i)&&inC(x,y))out[i]=255}return out}
  const st=[sy*W+sx];out[sy*W+sx]=255;
  while(st.length){const i=st.pop(),x=i%W,y=(i-x)/W;
    if(x>0){const k=i-1;if(!out[k]&&ok(k)&&inC(x-1,y)){out[k]=255;st.push(k)}}
    if(x<W-1){const k=i+1;if(!out[k]&&ok(k)&&inC(x+1,y)){out[k]=255;st.push(k)}}
    if(y>0){const k=i-W;if(!out[k]&&ok(k)&&inC(x,y-1)){out[k]=255;st.push(k)}}
    if(y<H-1){const k=i+W;if(!out[k]&&ok(k)&&inC(x,y+1)){out[k]=255;st.push(k)}}}
  return out}
function shapeMask(fn){const c=document.createElement('canvas');c.width=doc.w;c.height=doc.h;const x=c.getContext('2d');x.fillStyle='#fff';fn(x);
  const d=x.getImageData(0,0,c.width,c.height).data,m=new Uint8Array(doc.w*doc.h);for(let i=0;i<m.length;i++)m[i]=d[i*4+3]>127?255:0;return m}
const mAt=p=>{const x=Math.floor(p.x),y=Math.floor(p.y);return x>=0&&y>=0&&x<doc.w&&y<doc.h&&msk&&msk[y*doc.w+x]};
function shiftMask(b,dx,dy){const W=doc.w,H=doc.h,o=new Uint8Array(W*H);for(let y=0;y<H;y++){const sy=y-dy;if(sy<0||sy>=H)continue;for(let x=0;x<W;x++){const sx=x-dx;if(sx>=0&&sx<W&&b[sy*W+sx])o[y*W+x]=255}}return o}
function growMask(n,sign){if(!msk)return;const W=doc.w,H=doc.h;let m=msk;
  for(let it=0;it<n;it++){const t=m.slice();for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=y*W+x,v=m[i];
    const nb=[x>0?m[i-1]:0,x<W-1?m[i+1]:0,y>0?m[i-W]:0,y<H-1?m[i+W]:0];
    if(sign>0){if(!v&&(nb[0]||nb[1]||nb[2]||nb[3]))t[i]=255}else if(v&&(!nb[0]||!nb[1]||!nb[2]||!nb[3]||x===0||y===0||x===W-1||y===H-1))t[i]=0}m=t}
  setMask(m);buildOpts()}
function selAll(){setMask(new Uint8Array(doc.w*doc.h).fill(255));buildOpts()}
function selInvert(){if(!msk){selAll();return}const m=new Uint8Array(msk.length);for(let i=0;i<m.length;i++)m[i]=msk[i]?0:255;setMask(m);buildOpts()}
function selNone(){mskClear();buildOpts()}
/* preview svg */
function prev(kind,a){const s=$('#rzv');if(!s)return;s.setAttribute('class','rzv'+(kind==='line'?' razor':''));let h='';
  if(kind==='rect')h=`<rect x="${a.x*zoom}" y="${a.y*zoom}" width="${a.w*zoom}" height="${a.h*zoom}"/>`;
  else if(kind==='ell')h=`<ellipse cx="${(a.x+a.w/2)*zoom}" cy="${(a.y+a.h/2)*zoom}" rx="${a.w/2*zoom}" ry="${a.h/2*zoom}"/>`;
  else if(kind==='poly')h=`<polyline points="${a.pts.map(q=>q.x*zoom+','+q.y*zoom).join(' ')}"/>`;
  else if(kind==='line'){const dx=a.b.x-a.a.x,dy=a.b.y-a.a.y,L=Math.hypot(dx,dy)||1,K=(doc.w+doc.h)*3/L;
    h=`<line x1="${(a.a.x-dx*K)*zoom}" y1="${(a.a.y-dy*K)*zoom}" x2="${(a.a.x+dx*K)*zoom}" y2="${(a.a.y+dy*K)*zoom}"/><circle cx="${a.a.x*zoom}" cy="${a.a.y*zoom}" r="4"/><circle cx="${a.b.x*zoom}" cy="${a.b.y*zoom}" r="4"/>`}
  s.innerHTML=h}
/* selection tool pointer handling */
function selDown(p,e){const mode=e.shiftKey?'add':e.altKey?'sub':selMode;
  if(tool==='wand'){let d;try{d=ctx.getImageData(0,0,doc.w,doc.h).data}catch(x){return}
    const x=clampv(Math.floor(p.x),0,doc.w-1),y=clampv(Math.floor(p.y),0,doc.h-1);setMask(mskCombine(msk,flood(d,x,y,tolV,contig),mode));buildOpts();return}
  drag={mode:'sel',t:tool,m:mode,sx:p.x,sy:p.y,base:msk?msk.slice():null,pts:[p],last:p};
  if((tool==='marq'||tool==='lasso')&&mode==='new'&&mAt(p))drag.move=true;
  if(tool==='qsel'){try{drag.img=ctx.getImageData(0,0,doc.w,doc.h).data}catch(x){drag=null;return}drag.q=new Uint8Array(doc.w*doc.h);qDo(p)}
  board.setPointerCapture(e.pointerId)}
function qDo(p){const D=drag,r=Math.max(3,qsz/2/zoom),a=D.last,n=Math.max(1,Math.ceil(Math.hypot(p.x-a.x,p.y-a.y)/(r/2)));
  for(let i=1;i<=n;i++){const q={x:a.x+(p.x-a.x)*i/n,y:a.y+(p.y-a.y)*i/n},x=Math.floor(q.x),y=Math.floor(q.y);if(x<0||y<0||x>=doc.w||y>=doc.h)continue;
    const f=flood(D.img,x,y,tolV,true,{x:q.x,y:q.y,r});for(let k=0;k<f.length;k++)if(f[k])D.q[k]=255}
  D.last=p;setMask(mskCombine(D.base,D.q,D.m))}
function selMove(p,e){const D=drag;
  if(D.move){setMask(shiftMask(D.base,Math.round(p.x-D.sx),Math.round(p.y-D.sy)));return}
  if(D.t==='qsel'){qDo(p);return}
  if(D.t==='lasso'){D.pts.push(p);prev('poly',{pts:D.pts});return}
  let x=Math.min(D.sx,p.x),y=Math.min(D.sy,p.y),w=Math.abs(p.x-D.sx),h=Math.abs(p.y-D.sy);
  if(e.ctrlKey){const s=Math.max(w,h);w=h=s;x=p.x<D.sx?D.sx-s:D.sx;y=p.y<D.sy?D.sy-s:D.sy}
  D.box={x,y,w,h};prev(marqShape==='ell'?'ell':'rect',D.box)}
function selUp(D){prev(null);
  if(D.move){buildOpts();return}
  if(D.t==='qsel'){buildOpts();return}
  if(D.t==='lasso'){if(D.pts.length<3){selNone();return}
    setMask(mskCombine(D.base,shapeMask(x=>{x.beginPath();D.pts.forEach((q,i)=>i?x.lineTo(q.x,q.y):x.moveTo(q.x,q.y));x.closePath();x.fill()}),D.m));buildOpts();return}
  const b=D.box;if(!b||b.w<2||b.h<2){if(D.m==='new')selNone();return}
  setMask(mskCombine(D.base,shapeMask(x=>{x.beginPath();if(marqShape==='ell')x.ellipse(b.x+b.w/2,b.y+b.h/2,b.w/2,b.h/2,0,0,7);else x.rect(b.x,b.y,b.w,b.h);x.fill()}),D.m));buildOpts()}
/* actions on selection */
function rasterFull(l){const c=document.createElement('canvas');c.width=doc.w;c.height=doc.h;const x=c.getContext('2d');if(l)drawLayer(x,l,true);else layers.forEach(q=>q.visible&&drawLayer(x,q));return c}
function maskCanvas(c,invert){const x=c.getContext('2d'),img=x.getImageData(0,0,c.width,c.height),d=img.data;for(let i=0;i<msk.length;i++)if(invert?msk[i]:!msk[i])d[i*4+3]=0;x.putImageData(img,0,0)}
function cropTo(src,b){const w=b.x1-b.x0+1,h=b.y1-b.y0+1,c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(src,b.x0,b.y0,w,h,0,0,w,h);return c}
function newFromCanvas(c,b,name,l){const k=keyId();store.set(k,c.toDataURL('image/png'));const w=b.x1-b.x0+1,h=b.y1-b.y0+1;return mk('draw',{x:b.x0,y:b.y0,w,h,pw:w,ph:h,src:k,name,opacity:l?l.opacity:1,blend:l?l.blend:'normal'})}
function selLayer(cut){if(!msk){toast('Chưa có vùng chọn. Dùng Marquee, Lasso, Quick Selection hoặc Magic Wand.');return}
  const l=cur(),b=mskB,full=rasterFull(l);maskCanvas(full,false);const n=newFromCanvas(cropTo(full,b),b,(l?l.name:'Vùng chọn')+' (vùng chọn)',null);
  if(cut&&l){const f2=rasterFull(l);maskCanvas(f2,true);const k=keyId();store.set(k,f2.toDataURL('image/png'));const r=mk('draw',{x:0,y:0,w:doc.w,h:doc.h,pw:doc.w,ph:doc.h,src:k,name:l.name,opacity:l.opacity,blend:l.blend,visible:l.visible});
    const i=layers.indexOf(l);layers[i]=r;layers.splice(i+1,0,n)}
  else{const i=l?layers.indexOf(l)+1:layers.length;layers.splice(i,0,n)}
  sel=n.id;commit(true,cut?'Cắt vùng chọn ra layer':'Layer từ vùng chọn')}
function eraseSel(){if(!msk)return;const l=cur();if(!l){toast('Chọn layer cần xóa vùng.');return}if(l.locked){toast('Layer đang khóa.');return}
  const f=rasterFull(l);maskCanvas(f,true);const k=keyId();store.set(k,f.toDataURL('image/png'));const r=mk('draw',{x:0,y:0,w:doc.w,h:doc.h,pw:doc.w,ph:doc.h,src:k,name:l.name,opacity:l.opacity,blend:l.blend,visible:l.visible});
  layers[layers.indexOf(l)]=r;sel=r.id;commit(true,'Xóa vùng chọn')}
function fillSel(color){const W=doc.w,H=doc.h,c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d');x.fillStyle=color;x.fillRect(0,0,W,H);if(msk)maskCanvas(c,false);const bb=msk?mskB:{x0:0,y0:0,x1:W-1,y1:H-1};
  const n=newFromCanvas(cropTo(c,bb),bb,'Tô màu',null);const l=cur();layers.splice(l?layers.indexOf(l)+1:layers.length,0,n);sel=n.id;commit(true,'Tô màu vùng chọn')}
function cropToSel(){if(!msk){toast('Chưa có vùng chọn.');return}const b=mskB;applyCrop(b.x0,b.y0,b.x1-b.x0+1,b.y1-b.y0+1,'Cắt theo vùng chọn')}
/* razor */
function razorDown(p,e){drag={mode:'razor',a:p,b:p,all:razorAll||e.altKey};board.setPointerCapture(e.pointerId);prev('line',{a:p,b:p})}
function razorMove(p,e){const D=drag;let b=p;if(e.shiftKey){const dx=p.x-D.a.x,dy=p.y-D.a.y,L=Math.hypot(dx,dy),a=Math.round(Math.atan2(dy,dx)/(Math.PI/12))*(Math.PI/12);b={x:D.a.x+Math.cos(a)*L,y:D.a.y+Math.sin(a)*L}}
  D.b=b;prev('line',{a:D.a,b})}
function razorUp(D){prev(null);razorCut(D.a,D.b,D.all)}
function trimCv(c){const x=c.getContext('2d'),W=c.width,H=c.height,d=x.getImageData(0,0,W,H).data;let x0=W,y0=H,x1=-1,y1=-1;
  for(let y=0;y<H;y++)for(let xx=0;xx<W;xx++)if(d[(y*W+xx)*4+3]>2){if(xx<x0)x0=xx;if(xx>x1)x1=xx;if(y<y0)y0=y;if(y>y1)y1=y}
  if(x1<0)return null;const o=document.createElement('canvas');o.width=x1-x0+1;o.height=y1-y0+1;o.getContext('2d').drawImage(c,x0,y0,o.width,o.height,0,0,o.width,o.height);return{c:o,x:x0,y:y0}}
function splitLayer(l,a,b){const bd=bounds(l),bx=Math.max(0,Math.floor(bd.x0)),by=Math.max(0,Math.floor(bd.y0)),ex=Math.min(doc.w,Math.ceil(bd.x1)),ey=Math.min(doc.h,Math.ceil(bd.y1)),w=ex-bx,h=ey-by;if(w<1||h<1)return null;
  const src=document.createElement('canvas');src.width=w;src.height=h;const sx=src.getContext('2d');sx.translate(-bx,-by);drawLayer(sx,l,true);
  const dx=b.x-a.x,dy=b.y-a.y,L=Math.hypot(dx,dy),ux=dx/L,uy=dy/L,nx=-uy,ny=ux,K=(doc.w+doc.h)*3,out=[];
  for(const sd of [1,-1]){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.save();x.beginPath();
    const p1=[a.x-bx+ux*K,a.y-by+uy*K],p2=[a.x-bx-ux*K,a.y-by-uy*K];x.moveTo(p1[0],p1[1]);x.lineTo(p2[0],p2[1]);x.lineTo(p2[0]+nx*sd*K,p2[1]+ny*sd*K);x.lineTo(p1[0]+nx*sd*K,p1[1]+ny*sd*K);x.closePath();x.clip();x.drawImage(src,0,0);x.restore();
    const t=trimCv(c);if(!t)continue;const k=keyId();store.set(k,t.c.toDataURL('image/png'));
    out.push(mk('draw',{x:bx+t.x,y:by+t.y,w:t.c.width,h:t.c.height,pw:t.c.width,ph:t.c.height,src:k,name:l.name+(sd>0?' A':' B'),opacity:l.opacity,blend:l.blend,visible:l.visible,locked:l.locked}))}
  return out.length>=2?out:null}
function razorCut(a,b,all){const dx=b.x-a.x,dy=b.y-a.y;if(Math.hypot(dx,dy)<6){toast('Kéo một đường để cắt layer.');return}
  const side=q=>dx*(q.y-a.y)-dy*(q.x-a.x);
  const cross=l=>{const bd=bounds(l),s=[[bd.x0,bd.y0],[bd.x1,bd.y0],[bd.x1,bd.y1],[bd.x0,bd.y1]].map(q=>side({x:q[0],y:q[1]}));return Math.min(...s)<0&&Math.max(...s)>0};
  const targets=(all||!cur())?layers.filter(l=>l.visible&&!l.locked&&cross(l)):[cur()].filter(l=>l&&!l.locked&&cross(l));
  if(!targets.length){toast(all||!cur()?'Đường cắt không đi qua layer nào.':'Đường cắt không đi qua layer đang chọn. Giữ Alt để cắt mọi layer.');return}
  let n=0,first=null;for(const l of targets){const parts=splitLayer(l,a,b);if(!parts)continue;const i=layers.indexOf(l);layers.splice(i,1,...parts);n++;if(!first)first=parts[0].id}
  if(!n){toast('Không cắt được: đường cắt chỉ đi qua vùng trong suốt.');return}
  sel=first;commit(true,'Cắt bằng dao');toast('Đã cắt '+n+' layer thành '+n*2+' mảnh. Mỗi mảnh là một track riêng khi gửi sang Bravin.')}

/* ---------- fill & content-aware fill ---------- */
function dilArr(m,n,W,H){let a=m;for(let it=0;it<n;it++){const t=a.slice();for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=y*W+x;if(!a[i]&&((x>0&&a[i-1])||(x<W-1&&a[i+1])||(y>0&&a[i-W])||(y<H-1&&a[i+W])))t[i]=255}a=t}return a}
function caLevel(roiCv,holeCv,w,h,prev){
  const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.imageSmoothingQuality='high';x.drawImage(roiCv,0,0,w,h);const id=x.getImageData(0,0,w,h).data;
  x.clearRect(0,0,w,h);x.drawImage(holeCv,0,0,w,h);const hd=x.getImageData(0,0,w,h).data;
  const img=new Float32Array(w*h*3),hole=new Uint8Array(w*h),hp=[];
  for(let i=0;i<w*h;i++){img[i*3]=id[i*4];img[i*3+1]=id[i*4+1];img[i*3+2]=id[i*4+2];if(hd[i*4+3]>40){hole[i]=1;hp.push(i)}}
  if(!hp.length)return null;
  const bad=dilArr(hole,2,w,h),valid=(sx,sy)=>sx>=2&&sy>=2&&sx<w-2&&sy<h-2&&!bad[sy*w+sx],vl=[];
  for(let y=2;y<h-2;y++)for(let xx=2;xx<w-2;xx++)if(!bad[y*w+xx])vl.push(y*w+xx);
  if(vl.length<30)return null;
  const nnf=new Int32Array(w*h*2),rnd=()=>{const v=vl[Math.floor(Math.random()*vl.length)];return[v%w,Math.floor(v/w)]};
  if(!prev){ // onion-peel initial fill
    const done=new Uint8Array(w*h);for(let i=0;i<w*h;i++)done[i]=hole[i]?0:1;let left=hp.length,guard=0;
    while(left>0&&guard++<400){const upd=[];for(const i of hp){if(done[i])continue;const px=i%w,py=(i-px)/w;let r=0,g=0,b=0,n=0;
      for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=px+dx,ny=py+dy;if(nx<0||ny<0||nx>=w||ny>=h)continue;const j=ny*w+nx;if(done[j]){r+=img[j*3];g+=img[j*3+1];b+=img[j*3+2];n++}}
      if(n)upd.push([i,r/n,g/n,b/n])}
      if(!upd.length)break;for(const u of upd){img[u[0]*3]=u[1];img[u[0]*3+1]=u[2];img[u[0]*3+2]=u[3];done[u[0]]=1;left--}}
    for(const i of hp){const [sx,sy]=rnd();nnf[i*2]=sx;nnf[i*2+1]=sy}
  }else{
    for(const i of hp){const px=i%w,py=(i-px)/w,qx=Math.min(prev.w-1,Math.floor(px*prev.w/w)),qy=Math.min(prev.h-1,Math.floor(py*prev.h/h)),q=qy*prev.w+qx;
      img[i*3]=prev.img[q*3];img[i*3+1]=prev.img[q*3+1];img[i*3+2]=prev.img[q*3+2];
      let sx=Math.round(prev.nnf[q*2]*w/prev.w),sy=Math.round(prev.nnf[q*2+1]*h/prev.h);if(!prev.hole[q]||!valid(sx,sy)){[sx,sy]=rnd()}nnf[i*2]=sx;nnf[i*2+1]=sy}}
  return{w,h,img,hole,hp,nnf,valid,rnd}}
function caRun(L,emN,pmN){const {w,h,img,hp,nnf,valid,hole}=L;
  const dist=(tx,ty,sx,sy,best)=>{let s=0;for(let j=-2;j<=2;j++){const ty2=Math.min(h-1,Math.max(0,ty+j)),sy2=sy+j;for(let k=-2;k<=2;k++){const a=(ty2*w+Math.min(w-1,Math.max(0,tx+k)))*3,b=(sy2*w+sx+k)*3,r=img[a]-img[b],g=img[a+1]-img[b+1],q=img[a+2]-img[b+2];s+=r*r+g*g+q*q}if(s>=best)return s}return s};
  const cost=new Float32Array(w*h);
  for(let em=0;em<emN;em++){
    for(const i of hp){const x=i%w,y=(i-x)/w;cost[i]=dist(x,y,nnf[i*2],nnf[i*2+1],Infinity)}
    for(let it=0;it<pmN;it++){const rev=it%2===1,ord=rev?hp.slice().reverse():hp,d=rev?1:-1;
      for(const i of ord){const x=i%w,y=(i-x)/w;let bx=nnf[i*2],by=nnf[i*2+1],bc=cost[i];
        for(const [dx,dy] of [[d,0],[0,d]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=w||ny>=h)continue;const j=ny*w+nx;if(!hole[j])continue;const sx=nnf[j*2]-dx,sy=nnf[j*2+1]-dy;
          if(valid(sx,sy)){const c=dist(x,y,sx,sy,bc);if(c<bc){bc=c;bx=sx;by=sy}}}
        for(let rad=Math.min(64,Math.max(w,h));rad>=1;rad>>=1){const sx=bx+Math.round((Math.random()*2-1)*rad),sy=by+Math.round((Math.random()*2-1)*rad);
          if(valid(sx,sy)){const c=dist(x,y,sx,sy,bc);if(c<bc){bc=c;bx=sx;by=sy}}}
        nnf[i*2]=bx;nnf[i*2+1]=by;cost[i]=bc}}
    const acc=new Float32Array(w*h*3),cnt=new Float32Array(w*h);
    for(const i of hp){const x=i%w,y=(i-x)/w,sx=nnf[i*2],sy=nnf[i*2+1];
      for(let j=-2;j<=2;j++)for(let k=-2;k<=2;k++){const tx=x+k,ty=y+j;if(tx<0||ty<0||tx>=w||ty>=h)continue;const ti=ty*w+tx;if(!hole[ti])continue;const s=((sy+j)*w+sx+k)*3;acc[ti*3]+=img[s];acc[ti*3+1]+=img[s+1];acc[ti*3+2]+=img[s+2];cnt[ti]++}}
    for(const i of hp){if(cnt[i]){img[i*3]=acc[i*3]/cnt[i];img[i*3+1]=acc[i*3+1]/cnt[i];img[i*3+2]=acc[i*3+2]/cnt[i]}}}}
function contentAware(){if(!msk){toast('Chọn vùng cần xóa trước (Lasso, Marquee, Quick Selection...).');return}
  toast('Đang tính content-aware fill...');
  setTimeout(()=>{try{
    const W=doc.w,H=doc.h,hole=dilArr(msk,4,W,H),b={x0:W,y0:H,x1:-1,y1:-1};
    for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(hole[y*W+x]){if(x<b.x0)b.x0=x;if(x>b.x1)b.x1=x;if(y<b.y0)b.y0=y;if(y>b.y1)b.y1=y}
    const bw=b.x1-b.x0+1,bh=b.y1-b.y0+1,m=Math.max(60,Math.round(Math.max(bw,bh)*.75)),rx=Math.max(0,b.x0-m),ry=Math.max(0,b.y0-m),rw=Math.min(W,b.x1+m+1)-rx,rh=Math.min(H,b.y1+m+1)-ry;
    const full=flatten(true),roi=document.createElement('canvas');roi.width=rw;roi.height=rh;roi.getContext('2d').drawImage(full,rx,ry,rw,rh,0,0,rw,rh);
    const hc=document.createElement('canvas');hc.width=rw;hc.height=rh;const hx=hc.getContext('2d'),hi=hx.createImageData(rw,rh);
    for(let y=0;y<rh;y++)for(let x=0;x<rw;x++)if(hole[(ry+y)*W+rx+x]){const k=(y*rw+x)*4;hi.data[k]=hi.data[k+1]=hi.data[k+2]=255;hi.data[k+3]=255}
    hx.putImageData(hi,0,0);
    const s=Math.min(1,380/Math.max(rw,rh));let prev=null,fl=[s/8,s/4,s/2,s];
    for(const f of fl){const w=Math.max(24,Math.round(rw*f)),h=Math.max(24,Math.round(rh*f));if(prev&&w<=prev.w*1.2)continue;const L=caLevel(roi,hc,w,h,prev);if(!L){if(prev)break;toast('Không đủ vùng nền xung quanh để lấy mẫu. Hãy chọn vùng nhỏ hơn.');return}caRun(L,prev?5:14,4);prev=L}
    const L=prev,rd=roi.getContext('2d').getImageData(0,0,rw,rh).data,out=document.createElement('canvas');out.width=rw;out.height=rh;const ox=out.getContext('2d'),od=ox.createImageData(rw,rh);
    for(let Y=0;Y<rh;Y++)for(let X=0;X<rw;X++){if(!hole[(ry+Y)*W+rx+X])continue;
      const x=Math.min(L.w-1,Math.floor(X*L.w/rw)),y=Math.min(L.h-1,Math.floor(Y*L.h/rh)),q=y*L.w+x,k=(Y*rw+X)*4;let r=L.img[q*3],g=L.img[q*3+1],bl=L.img[q*3+2];
      if(L.hole[q]){const sx=Math.round(X+(L.nnf[q*2]-x)*rw/L.w),sy=Math.round(Y+(L.nnf[q*2+1]-y)*rh/L.h);
        if(sx>=0&&sy>=0&&sx<rw&&sy<rh&&!hole[(ry+sy)*W+rx+sx]){const j=(sy*rw+sx)*4;r=rd[j];g=rd[j+1];bl=rd[j+2]}}
      od.data[k]=r;od.data[k+1]=g;od.data[k+2]=bl;od.data[k+3]=255}
    ox.putImageData(od,0,0);
    const bb={x0:b.x0,y0:b.y0,x1:b.x1,y1:b.y1},cv=document.createElement('canvas');cv.width=bw;cv.height=bh;cv.getContext('2d').drawImage(out,b.x0-rx,b.y0-ry,bw,bh,0,0,bw,bh);
    const n=newFromCanvas(cv,bb,'Content-aware fill',null),l=cur();layers.splice(l?layers.indexOf(l)+1:layers.length,0,n);sel=n.id;commit(true,'Content-aware fill');toast('Đã tạo layer Content-aware fill. Có thể ẩn hoặc xóa layer này nếu chưa ưng.')
  }catch(err){toast('Content-aware fill lỗi: '+(err&&err.message||err))}},40)}
function fillDialog(){const hasM=!!msk;
  const m=modal(`<h2>Tô vùng chọn</h2><p>${hasM?'Kết quả nằm trên một layer mới, không ghi đè layer gốc.':'Chưa có vùng chọn, Tô màu sẽ phủ toàn bộ canvas. Content-aware cần vùng chọn.'}</p>
  <div class="chips" id="flC" style="margin-bottom:14px">${[['ca','Content-aware'],['fg','Màu trước'],['bg','Màu nền'],['k','Đen'],['w','Trắng'],['g','Xám 50%'],['c','Màu khác']].map((o,i)=>`<button class="chip ${o[0]===(hasM?'ca':'fg')?'on':''}" data-v="${o[0]}" ${o[0]==='ca'&&!hasM?'disabled':''}>${o[1]}</button>`).join('')}</div>
  <label class="fld" style="margin-bottom:18px"><span style="width:auto">Màu khác</span><input type="color" id="flCol" value="#ff4f99"></label>
  <div class="row" style="justify-content:flex-end;margin:0"><button class="btn" id="flX">Hủy</button><button class="btn pri" id="flOk">Tô</button></div>`);
  let v=hasM?'ca':'fg';m.querySelector('#flC').addEventListener('click',e=>{const b=e.target.closest('.chip');if(!b||b.disabled)return;v=b.dataset.v;m.querySelectorAll('.chip').forEach(c=>c.classList.toggle('on',c===b))});
  m.querySelector('#flX').onclick=()=>m.remove();
  m.querySelector('#flOk').onclick=()=>{const col=m.querySelector('#flCol').value;m.remove();
    if(v==='ca'){contentAware();return}fillSel({fg:brush.color,bg:bgc,k:'#000000',w:'#ffffff',g:'#808080',c:col}[v])}}

/* ---------- color picker (wheel, HEX / RGB / CMYK / HSB) ---------- */
var cpIn=null,cpTarget='fg',cpOpen=null,recentCols=[],cpApply=true,cpDirty=false;
function colorKey(l){return l&&(l.type==='text'?'color':(l.type==='rect'||l.type==='ellipse')?'fill':null)}
function applyFg(c,final){if(!cpApply)return false;const l=cur(),k=colorKey(l);if(!k||l.locked)return false;l[k]=c;cpDirty=true;render();queueLayers();if(final){commit(true,'Đổi màu');cpDirty=false}return true}
function applyDone(){if(cpDirty){cpDirty=false;commit(true,'Đổi màu')}}
try{const r=JSON.parse(localStorage.getItem('af-recent')||'[]');if(Array.isArray(r))recentCols=r.filter(c=>/^#[0-9a-f]{6}$/i.test(c)).slice(0,12)}catch(e){}
const hex2rgb=h=>{const n=parseInt(h.slice(1),16);return[n>>16&255,n>>8&255,n&255]};
const rgb2hex=(r,g,b)=>'#'+[r,g,b].map(v=>clampv(Math.round(v),0,255).toString(16).padStart(2,'0')).join('');
function rgb2hsv(r,g,b){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;if(d){if(mx===r)h=((g-b)/d)%6;else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h*=60;if(h<0)h+=360}return[h,mx?d/mx:0,mx]}
function hsv2rgb(h,s,v){const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let q;q=h<60?[c,x,0]:h<120?[x,c,0]:h<180?[0,c,x]:h<240?[0,x,c]:h<300?[x,0,c]:[c,0,x];return[(q[0]+m)*255,(q[1]+m)*255,(q[2]+m)*255]}
function rgb2cmyk(r,g,b){r/=255;g/=255;b/=255;const k=1-Math.max(r,g,b);if(k>=1)return[0,0,0,100];return[(1-r-k)/(1-k)*100,(1-g-k)/(1-k)*100,(1-b-k)/(1-k)*100,k*100]}
function cmyk2rgb(c,m,y,k){c/=100;m/=100;y/=100;k/=100;return[255*(1-c)*(1-k),255*(1-m)*(1-k),255*(1-y)*(1-k)]}
function makeCP(host,o){const st={h:0,s:0,v:1},S=o.size||190;let drawnV=-1;
  host.innerHTML=`<div class="cp2 ${o.compact?'cmp':''}"><div class="cpL"><div class="cpw" style="width:${S}px;height:${S}px"><canvas class="wh" width="${S*2}" height="${S*2}"></canvas><i class="mk"></i></div><input type="range" class="bri" min="0" max="100" aria-label="Độ sáng"></div>
  <div class="cpR"><div class="cpP"><i class="old" title="Màu cũ"></i><i class="nw" title="Màu mới"></i><span class="sp"></span>${window.EyeDropper?`<button type="button" class="btn ic eye" title="Lấy màu từ màn hình" aria-label="Lấy màu từ màn hình">${ic('dropper')}</button>`:''}</div>
  <div class="cpF"><div><span>HEX</span><input class="hex" maxlength="7" spellcheck="false" aria-label="Mã HEX"></div>
  <div><span>RGB</span>${['r','g','b'].map(k=>`<input type="number" data-f="${k}" min="0" max="255" aria-label="${k.toUpperCase()}">`).join('')}</div>
  <div><span>CMYK</span>${['c','m','y','k'].map(k=>`<input type="number" data-f="${k}" min="0" max="100" aria-label="${k.toUpperCase()}">`).join('')}</div>
  <div><span>HSB</span><input type="number" data-f="H" min="0" max="360" aria-label="Hue"><input type="number" data-f="S" min="0" max="100" aria-label="Saturation"><input type="number" data-f="B" min="0" max="100" aria-label="Brightness"></div></div></div></div>`;
  const q=s=>host.querySelector(s),cv=q('.wh'),mk=q('.mk'),bri=q('.bri'),hexI=q('.hex'),F={};host.querySelectorAll('[data-f]').forEach(i=>F[i.dataset.f]=i);
  const cx=cv.getContext('2d');
  const rgb=()=>hsv2rgb(st.h,st.s,st.v),hex=()=>{const r=rgb();return rgb2hex(r[0],r[1],r[2])};
  function wheel(){if(drawnV===st.v)return;drawnV=st.v;const N=S*2,img=cx.createImageData(N,N),d=img.data,R=N/2;
    for(let y=0;y<N;y++)for(let x=0;x<N;x++){const dx=x+.5-R,dy=y+.5-R,r=Math.hypot(dx,dy)/R,k=(y*N+x)*4;if(r>1.005)continue;
      let h=Math.atan2(dy,dx)*180/Math.PI;if(h<0)h+=360;const c=hsv2rgb(h,Math.min(1,r),st.v);d[k]=c[0];d[k+1]=c[1];d[k+2]=c[2];d[k+3]=r>.99?Math.max(0,(1.005-r)/.015)*255:255}
    cx.putImageData(img,0,0)}
  function paint(skip){wheel();const a=st.h*Math.PI/180,rr=st.s*S/2;mk.style.left=S/2+Math.cos(a)*rr+'px';mk.style.top=S/2+Math.sin(a)*rr+'px';
    const hx=hex(),r=rgb(),full=hsv2rgb(st.h,st.s,1);mk.style.background=hx;bri.value=Math.round(st.v*100);bri.style.setProperty('--c',rgb2hex(full[0],full[1],full[2]));q('.nw').style.background=hx;
    const set=(el,v)=>{if(el&&el!==skip&&document.activeElement!==el)el.value=v};set(hexI,hx);
    set(F.r,Math.round(r[0]));set(F.g,Math.round(r[1]));set(F.b,Math.round(r[2]));
    const c=rgb2cmyk(r[0],r[1],r[2]);set(F.c,Math.round(c[0]));set(F.m,Math.round(c[1]));set(F.y,Math.round(c[2]));set(F.k,Math.round(c[3]));
    set(F.H,Math.round(st.h));set(F.S,Math.round(st.s*100));set(F.B,Math.round(st.v*100))}
  const emit=skip=>{paint(skip);o.onInput&&o.onInput(hex())};
  function fromRGB(r,g,b,skip){const t=rgb2hsv(r,g,b);if(t[1]>0&&t[2]>0)st.h=t[0];st.s=t[1];st.v=t[2];emit(skip)}
  function setColor(h,quiet){if(!/^#[0-9a-f]{6}$/i.test(h))return;if(h.toLowerCase()===hex().toLowerCase()&&drawnV>=0){return}const c=hex2rgb(h),t=rgb2hsv(c[0],c[1],c[2]);if(t[1]>0&&t[2]>0)st.h=t[0];st.s=t[1];st.v=t[2];paint();if(!quiet&&o.onInput)o.onInput(hex())}
  let wd=false;const pos=e=>{const r=cv.getBoundingClientRect(),R=r.width/2,dx=e.clientX-r.left-R,dy=e.clientY-r.top-R;let h=Math.atan2(dy,dx)*180/Math.PI;if(h<0)h+=360;st.h=h;st.s=Math.min(1,Math.hypot(dx,dy)/R);emit()};
  cv.addEventListener('pointerdown',e=>{wd=true;cv.setPointerCapture(e.pointerId);pos(e)});cv.addEventListener('pointermove',e=>{if(wd)pos(e)});
  const endw=()=>{if(wd){wd=false;o.onCommit&&o.onCommit(hex())}};cv.addEventListener('pointerup',endw);cv.addEventListener('pointercancel',endw);
  bri.addEventListener('input',()=>{st.v=+bri.value/100;emit()});bri.addEventListener('change',()=>o.onCommit&&o.onCommit(hex()));
  hexI.addEventListener('input',()=>{const v=hexI.value.trim().replace(/^#?/,'#');if(/^#[0-9a-f]{6}$/i.test(v)){const c=hex2rgb(v);fromRGB(c[0],c[1],c[2],hexI)}else if(/^#[0-9a-f]{3}$/i.test(v)){const c=hex2rgb('#'+v[1]+v[1]+v[2]+v[2]+v[3]+v[3]);fromRGB(c[0],c[1],c[2],hexI)}});
  hexI.addEventListener('blur',()=>{paint();o.onCommit&&o.onCommit(hex())});
  const nv=k=>clampv(parseFloat(F[k].value)||0,0,k==='H'?360:['r','g','b'].includes(k)?255:100);
  ['r','g','b'].forEach(k=>F[k].addEventListener('input',()=>fromRGB(nv('r'),nv('g'),nv('b'),F[k])));
  ['c','m','y','k'].forEach(k=>F[k].addEventListener('input',()=>{const r=cmyk2rgb(nv('c'),nv('m'),nv('y'),nv('k'));fromRGB(r[0],r[1],r[2],F[k])}));
  ['H','S','B'].forEach(k=>F[k].addEventListener('input',()=>{st.h=nv('H');st.s=nv('S')/100;st.v=nv('B')/100;emit(F[k])}));
  host.querySelectorAll('.cpF input').forEach(i=>i.addEventListener('change',()=>{paint();o.onCommit&&o.onCommit(hex())}));
  const eye=q('.eye');if(eye)eye.onclick=async()=>{try{const r=await new EyeDropper().open(),c=hex2rgb(r.sRGBHex);fromRGB(c[0],c[1],c[2]);o.onCommit&&o.onCommit(hex())}catch(e){}};
  const init=o.color&&/^#[0-9a-f]{6}$/i.test(o.color)?o.color:'#ffffff';const c0=hex2rgb(init),t0=rgb2hsv(c0[0],c0[1],c0[2]);st.h=t0[0];st.s=t0[1];st.v=t0[2];q('.old').style.background=init;paint();
  return{setColor,hex,setOld:h=>{q('.old').style.background=h}}}
function addRecent(h){h=h.toLowerCase();recentCols=[h,...recentCols.filter(c=>c!==h)].slice(0,12);try{localStorage.setItem('af-recent',JSON.stringify(recentCols))}catch(e){}}
function closePicker(){if(!cpOpen)return;const c=cpOpen;cpOpen=null;c.pop.remove();if(c.changed){c.input.dispatchEvent(new Event('change',{bubbles:true}));addRecent(c.input.value)}}
function openPicker(input){if(cpOpen&&cpOpen.input===input){closePicker();return}closePicker();
  const pop=document.createElement('div');pop.className='cpk';pop.setAttribute('role','dialog');pop.setAttribute('aria-label','Chọn màu');document.body.appendChild(pop);
  const host=document.createElement('div');pop.appendChild(host);const sw=document.createElement('div');sw.className='cps';pop.appendChild(sw);
  const state={pop,input,changed:false};cpOpen=state;
  const cp=makeCP(host,{color:input.value,size:196,onInput:h=>{input.value=h;state.changed=true;input.dispatchEvent(new Event('input',{bubbles:true}))}});
  const list=[...recentCols,...BRAND.filter(c=>!recentCols.includes(c))].slice(0,18);
  sw.innerHTML=list.map(c=>`<button type="button" class="swc" data-c="${c}" style="background:${c}" title="${c}" aria-label="${c}"></button>`).join('');
  sw.addEventListener('click',e=>{const b=e.target.closest('.swc');if(b)cp.setColor(b.dataset.c)});
  const r=input.getBoundingClientRect(),w=pop.offsetWidth,h=pop.offsetHeight;let x=r.left,y=r.bottom+8;
  if(x+w>innerWidth-8)x=innerWidth-w-8;if(x<8)x=8;if(y+h>innerHeight-8)y=Math.max(8,r.top-h-8);if(y+h>innerHeight-8)y=Math.max(8,innerHeight-h-8);
  pop.style.left=x+'px';pop.style.top=y+'px'}
document.addEventListener('click',e=>{const t=e.target.closest&&e.target.closest('input[type=color]');if(t){e.preventDefault();openPicker(t)}},true);
document.addEventListener('pointerdown',e=>{if(cpOpen&&!cpOpen.pop.contains(e.target)&&!(e.target.closest&&e.target.closest('input[type=color]')))closePicker()});
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&cpOpen){e.stopPropagation();closePicker()}},true);
/* inline picker in the Màu panel */
function buildCpInline(){const h=$('#cpHost');if(!h||cpIn)return;
  h.innerHTML=`<div class="cptg"><button type="button" data-t="fg" class="on"><i id="tgFg"></i>Màu trước</button><button type="button" data-t="bg"><i id="tgBg"></i>Màu nền</button></div><label class="cpap"><input type="checkbox" id="cpApply" ${cpApply?'checked':''}> Áp màu trước cho layer chữ/hình đang chọn</label><div id="cpIn"></div>`;
  cpIn=makeCP($('#cpIn'),{compact:true,size:128,color:brush.color,onInput:c=>{if(cpTarget==='fg'){setFg(c);applyFg(c,false)}else setBg(c)},onCommit:c=>{addRecent(c);applyDone()}});
  $('#cpApply').addEventListener('change',e=>{cpApply=e.target.checked});
  h.querySelector('.cptg').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;cpTarget=b.dataset.t;h.querySelectorAll('.cptg button').forEach(x=>x.classList.toggle('on',x===b));cpIn.setColor(cpTarget==='fg'?brush.color:bgc,true);cpIn.setOld(cpTarget==='fg'?brush.color:bgc);syncSw()});
  syncSw()}

/* ================= Stage A: compositing engine ================= */
const byId=id=>layers.find(l=>l.id===id)||null;
function kids(pid){return pid==null?layers.filter(l=>!l.parent||!byId(l.parent)):layers.filter(l=>l.parent===pid)}
function effVis(l){let n=0;while(l&&n++<50){if(!l.visible)return false;l=l.parent?byId(l.parent):null}return true}
function descIds(id){const out=[];(function f(p){layers.forEach(l=>{if(l.parent===p&&!out.includes(l.id)){out.push(l.id);f(l.id)}})})(id);return out}
const isGroup=l=>l&&l.type==='group',isAdj=l=>l&&l.type==='adjust';
const hasStyle=l=>!!(l.fx&&Object.values(l.fx).some(v=>v&&v.on));
const maskOn=l=>!!(l.mask&&l.mask.on!==false);

/* ---- buffer pool ---- */
const bufPool=[];
function getBuf(){const c=bufPool.pop()||document.createElement('canvas');c.width=doc.w;c.height=doc.h;return c}
function relBuf(c){if(bufPool.length<24)bufPool.push(c)}

/* ---- masks ---- */
const maskCache=new Map();
function maskCv(l){const key=l.mask.key||'';let c=maskCache.get(l.id);
  if(c&&c.width===doc.w&&c.height===doc.h&&(c._dirty||(c._key===key&&!(c._pend&&getImg(key).ready))))return c;
  const n=document.createElement('canvas');n.width=doc.w;n.height=doc.h;const x=n.getContext('2d');n._key=key;
  if(key){const e=getImg(key);if(e.ready)x.drawImage(e.im,0,0,doc.w,doc.h);else{x.fillStyle='#fff';x.fillRect(0,0,doc.w,doc.h);n._pend=true}}
  else{x.fillStyle='#fff';x.fillRect(0,0,doc.w,doc.h)}
  maskCache.set(l.id,n);return n}
function applyMask(b,l){if(!maskOn(l))return;const x=b.getContext('2d');x.save();x.globalCompositeOperation=l.mask.inv?'destination-out':'destination-in';x.drawImage(maskCv(l),0,0);x.restore()}
function saveMask(l){const c=maskCache.get(l.id);if(!c)return;const k=keyId();store.set(k,c.toDataURL('image/png'));l.mask.key=k;c._key=k;c._dirty=false;c._pend=false}
function addMask(l,mode){const c=document.createElement('canvas');c.width=doc.w;c.height=doc.h;const x=c.getContext('2d');
  if(mode==='reveal'){x.fillStyle='#fff';x.fillRect(0,0,doc.w,doc.h)}
  if(mode==='sel'){if(!msk){toast('Chưa có vùng chọn.');return false}x.fillStyle='#fff';x.fillRect(0,0,doc.w,doc.h);maskCanvas(c,false)}
  if(mode==='hidesel'){if(!msk){toast('Chưa có vùng chọn.');return false}x.fillStyle='#fff';x.fillRect(0,0,doc.w,doc.h);maskCanvas(c,true)}
  c._key='';c._dirty=true;maskCache.set(l.id,c);l.mask={on:true,inv:false,key:''};saveMask(l);return true}
function bakeMask(l){
  if(!l.mask)return;if(l.type==='group'||l.type==='adjust'){toast('Mask của nhóm / điều chỉnh không thể áp vào điểm ảnh.');return}
  const c=getBuf();leafContent(c,l);applyMask(c,l);const bd=bounds(l);
  const x0=Math.max(0,Math.floor(bd.x0)),y0=Math.max(0,Math.floor(bd.y0)),x1=Math.min(doc.w,Math.ceil(bd.x1)),y1=Math.min(doc.h,Math.ceil(bd.y1)),w=x1-x0,h=y1-y0;
  if(w<1||h<1){relBuf(c);return}
  const o=document.createElement('canvas');o.width=w;o.height=h;o.getContext('2d').drawImage(c,x0,y0,w,h,0,0,w,h);relBuf(c);
  const k=keyId();store.set(k,o.toDataURL('image/png'));
  Object.assign(l,{type:'draw',x:x0,y:y0,w,h,pw:w,ph:h,src:k,rot:0,flipX:false,flipY:false,radius:0,f:{...F0},fx:newFx(),sf:[],mask:null});l.sh={...l.sh,on:false};paint.delete(l.id);maskCache.delete(l.id)}

/* ---- default layer data ---- */
function newFx(){return{stroke:{on:false,color:'#ffffff',w:6,pos:'out',a:1},ishadow:{on:false,color:'#000000',a:.6,blur:12,x:4,y:6,choke:0},oglow:{on:false,color:'#ffd43b',a:.8,blur:24,spread:2},iglow:{on:false,color:'#ffffff',a:.8,blur:16,choke:0},cover:{on:false,color:'#ff4f99',a:1,blend:'normal'},gover:{on:false,c1:'#ff4f99',c2:'#ffd43b',ang:90,a:1},bevel:{on:false,depth:100,size:6,ang:120,hc:'#ffffff',ha:.75,sc:'#000000',sa:.75}}}
function ensureFx(l){const d=newFx();if(!l.fx)l.fx={};for(const k in d){if(!l.fx[k])l.fx[k]=d[k];else for(const j in d[k])if(l.fx[k][j]===undefined)l.fx[k][j]=d[k][j]}if(!l.sf)l.sf=[];return l.fx}
function mk(type,p={}){cnt[type]=(cnt[type]||0)+1;
  return Object.assign({id:uid(),type,name:NAMES[type]+' '+cnt[type],x:0,y:0,w:200,h:200,rot:0,opacity:1,blend:'normal',visible:true,locked:false,flipX:false,flipY:false,f:{...F0},sh:{on:false,color:'#000000',a:.5,blur:20,x:0,y:10},parent:null,mask:null,clipTo:false,fx:newFx(),sf:[]},DEF[type],p)}

/* ---- geometry helpers ---- */
function layerBox(l){const b=bounds(l),x0=Math.max(0,Math.floor(b.x0)),y0=Math.max(0,Math.floor(b.y0));return{x:x0,y:y0,w:Math.max(1,Math.min(doc.w,Math.ceil(b.x1))-x0),h:Math.max(1,Math.min(doc.h,Math.ceil(b.y1))-y0)}}

/* ---- the compositor ---- */
var stopId=null,stopped=false;
function composeInto(dst,list,plain){
  for(let i=0;i<list.length;i++){
    if(stopped)return;
    const l=list[i];
    if(stopId&&l.id===stopId){stopped=true;return}
    if(l.clipTo&&i>0)continue;
    if(!l.visible)continue;
    const stack=[];for(let j=i+1;j<list.length&&list[j].clipTo;j++){if(list[j].visible)stack.push(list[j])}
    drawNode(dst,l,stack,plain)}}
function drawNode(dst,l,stack,plain){
  const dx=dst.getContext('2d');
  if(l.type==='adjust'){applyAdjustNode(dst,l);return}
  if(l.type==='group'){
    const ks=kids(l.id);
    if(l.blend==='pass'&&!stack.length&&!maskOn(l)&&l.opacity>=1){composeInto(dst,ks,false);return}
    const b=getBuf();composeInto(b,ks,false);finishNode(dx,b,l,stack,plain);relBuf(b);return}
  if(!stack.length&&!maskOn(l)&&!(l.sf&&l.sf.length)&&!hasStyle(l)){drawLayer(dx,l,plain);return}
  const b=getBuf();leafContent(b,l);finishNode(dx,b,l,stack,plain);relBuf(b)}
function finishNode(dx,b,l,stack,plain){
  const bx=b.getContext('2d');
  for(const s of stack){
    if(s.type==='adjust'){applyAdjustNode(b,s);continue}
    const t=getBuf();
    if(s.type==='group'){composeInto(t,kids(s.id),false)}else leafContent(t,s);
    applyMask(t,s);
    const tx=t.getContext('2d');tx.save();tx.globalCompositeOperation='destination-in';tx.drawImage(b,0,0);tx.restore();
    bx.save();bx.globalAlpha=s.opacity;bx.globalCompositeOperation=BLEND[s.blend]||'source-over';bx.drawImage(t,0,0);bx.restore();relBuf(t)}
  applyMask(b,l);
  dx.save();dx.globalAlpha=plain?1:l.opacity;dx.globalCompositeOperation=plain?'source-over':(BLEND[l.blend]||'source-over');dx.drawImage(b,0,0);dx.restore()}
function leafContent(b,l){const x=b.getContext('2d'),st=hasStyle(l),sf=l.sf&&l.sf.length;
  if(!st&&!sf){drawLayer(x,l,true);return}
  const c=getBuf();drawLayer(c.getContext('2d'),l,true,true);
  if(sf)applySF(c,l.sf,layerBox(l));
  if(st)applyStyles(x,c,l);
  else{x.save();if(l.sh.on){x.shadowColor=rgba(l.sh.color,l.sh.a);x.shadowBlur=l.sh.blur;x.shadowOffsetX=l.sh.x;x.shadowOffsetY=l.sh.y}x.drawImage(c,0,0);x.restore()}
  relBuf(c)}

function render(){const cv=ctx.canvas;if(cv.width!==doc.w||cv.height!==doc.h){cv.width=doc.w;cv.height=doc.h}
  ctx.clearRect(0,0,doc.w,doc.h);if(doc.bg){ctx.fillStyle=doc.bg;ctx.fillRect(0,0,doc.w,doc.h)}
  stopId=null;stopped=false;composeInto(cv,kids(null));
  applyZoom();updateOverlay();if(typeof histDirty==='function')histDirty()}
function flatten(opaque){const c=document.createElement('canvas');c.width=doc.w;c.height=doc.h;const x=c.getContext('2d');
  if(doc.bg||opaque){x.fillStyle=doc.bg||'#ffffff';x.fillRect(0,0,doc.w,doc.h)}
  stopId=null;stopped=false;composeInto(c,kids(null));return c}
function renderBelow(l){
  const c=document.createElement('canvas');c.width=doc.w;c.height=doc.h;const x=c.getContext('2d');
  if(doc.bg){x.fillStyle=doc.bg;x.fillRect(0,0,doc.w,doc.h)}
  stopId=l.id;stopped=false;composeInto(c,kids(null));stopId=null;stopped=false;return c}

/* ---- bounds with effects ---- */
function bounds(l){if(l.type==='group'||l.type==='adjust')return{x0:0,y0:0,x1:doc.w,y1:doc.h};
  if(l.type==='text')layoutText(l);const r=l.rot*Math.PI/180,c=Math.cos(r),s=Math.sin(r),cx=l.x+l.w/2,cy=l.y+l.h/2;
  const pts=[[-1,-1],[1,-1],[1,1],[-1,1]].map(([a,b])=>[cx+a*l.w/2*c-b*l.h/2*s,cy+a*l.w/2*s+b*l.h/2*c]);
  let m=(l.sh.on?l.sh.blur*2+Math.max(Math.abs(l.sh.x),Math.abs(l.sh.y)):0)+l.f.blur*3+(l.sw||0)+2;
  const f=l.fx;if(f){if(f.stroke&&f.stroke.on)m+=f.stroke.w+2;if(f.oglow&&f.oglow.on)m+=f.oglow.blur*2+f.oglow.spread+2}
  if(l.sf)for(const s2 of l.sf){if(s2.k==='gblur')m+=s2.r*3;if(s2.k==='motion')m+=s2.d;if(s2.k==='chroma')m+=s2.s+2}
  return{x0:Math.min(...pts.map(p=>p[0]))-m,y0:Math.min(...pts.map(p=>p[1]))-m,x1:Math.max(...pts.map(p=>p[0]))+m,y1:Math.max(...pts.map(p=>p[1]))+m}}
const hasFx=l=>l.sh.on||filterStr(l)!=='none'||hasStyle(l)||!!(l.sf&&l.sf.length);

/* ================= Layer styles ================= */
function dilate(src,r){const o=getBuf(),x=o.getContext('2d');x.drawImage(src,0,0);if(r<.4)return o;
  const rings=r>6?[r,r*.66,r*.33]:[r,r*.5];
  for(const rr of rings){const n=Math.min(40,Math.max(10,Math.ceil(rr*3)));for(let i=0;i<n;i++){const a=i/n*6.2832;x.drawImage(src,Math.cos(a)*rr,Math.sin(a)*rr)}}return o}
function solid(c,fill){const o=getBuf(),x=o.getContext('2d');x.fillStyle=fill;x.fillRect(0,0,o.width,o.height);x.globalCompositeOperation='destination-in';x.drawImage(c,0,0);return o}
function inverse(c){const o=getBuf(),x=o.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,o.width,o.height);x.globalCompositeOperation='destination-out';x.drawImage(c,0,0);return o}
function drawTo(x,cv,a,blend,filter){x.save();x.globalAlpha=a;if(blend)x.globalCompositeOperation=blend;if(filter)x.filter=filter;x.drawImage(cv,0,0);x.restore()}
function applyStyles(x,c,l){const f=l.fx;
  if(f.oglow.on){let s=solid(c,f.oglow.color);if(f.oglow.spread>0){const d=dilate(s,f.oglow.spread);relBuf(s);s=d}drawTo(x,s,Math.min(1,f.oglow.a),null,`blur(${f.oglow.blur/2}px)`);drawTo(x,s,Math.min(1,f.oglow.a*.6),null,`blur(${f.oglow.blur/2}px)`);relBuf(s)}
  x.save();if(l.sh.on){x.shadowColor=rgba(l.sh.color,l.sh.a);x.shadowBlur=l.sh.blur;x.shadowOffsetX=l.sh.x;x.shadowOffsetY=l.sh.y}x.drawImage(c,0,0);x.restore();
  if(f.cover.on){const s=solid(c,f.cover.color);drawTo(x,s,f.cover.a,BLEND[f.cover.blend]||'source-over');relBuf(s)}
  if(f.gover.on){const s=getBuf(),sx=s.getContext('2d'),a=f.gover.ang*Math.PI/180,bb=layerBox(l),cx=bb.x+bb.w/2,cy=bb.y+bb.h/2,hl=(Math.abs(bb.w*Math.cos(a))+Math.abs(bb.h*Math.sin(a)))/2;
    const g=sx.createLinearGradient(cx-Math.cos(a)*hl,cy-Math.sin(a)*hl,cx+Math.cos(a)*hl,cy+Math.sin(a)*hl);g.addColorStop(0,f.gover.c1);g.addColorStop(1,f.gover.c2);sx.fillStyle=g;sx.fillRect(0,0,s.width,s.height);sx.globalCompositeOperation='destination-in';sx.drawImage(c,0,0);drawTo(x,s,f.gover.a);relBuf(s)}
  if(f.ishadow.on){let inv=inverse(c);if(f.ishadow.choke>0){const d=dilate(inv,f.ishadow.choke);relBuf(inv);inv=d}
    const col=solid(inv,f.ishadow.color),t=getBuf(),tx=t.getContext('2d');tx.filter=`blur(${f.ishadow.blur/2}px)`;tx.drawImage(col,f.ishadow.x,f.ishadow.y);tx.filter='none';tx.globalCompositeOperation='destination-in';tx.drawImage(c,0,0);drawTo(x,t,f.ishadow.a);relBuf(inv);relBuf(col);relBuf(t)}
  if(f.iglow.on){let inv=inverse(c);if(f.iglow.choke>0){const d=dilate(inv,f.iglow.choke);relBuf(inv);inv=d}
    const col=solid(inv,f.iglow.color),t=getBuf(),tx=t.getContext('2d');tx.filter=`blur(${f.iglow.blur/2}px)`;tx.drawImage(col,0,0);tx.filter='none';tx.globalCompositeOperation='destination-in';tx.drawImage(c,0,0);drawTo(x,t,f.iglow.a);drawTo(x,t,f.iglow.a*.5);relBuf(inv);relBuf(col);relBuf(t)}
  if(f.bevel.on)bevel(x,c,f.bevel);
  if(f.stroke.on&&f.stroke.w>0){const w=f.stroke.w,pos=f.stroke.pos;let ring=null;
    if(pos==='out'||pos==='ctr'){const d=dilate(c,pos==='ctr'?w/2:w);if(pos==='out'){const dx=d.getContext('2d');dx.globalCompositeOperation='destination-out';dx.drawImage(c,0,0)}ring=d}
    if(pos==='in'||pos==='ctr'){const inv=inverse(c),d=dilate(inv,pos==='ctr'?w/2:w);const e=getBuf(),ex=e.getContext('2d');ex.drawImage(c,0,0);ex.globalCompositeOperation='destination-in';ex.drawImage(d,0,0);relBuf(inv);relBuf(d);
      if(ring){ring.getContext('2d').drawImage(e,0,0);relBuf(e)}else ring=e}
    const s=solid(ring,f.stroke.color);drawTo(x,s,f.stroke.a);relBuf(s);relBuf(ring)}}
function bevel(x,c,b){const W=c.width,H=c.height,t=getBuf(),tx=t.getContext('2d');tx.filter=`blur(${Math.max(.5,b.size)}px)`;tx.drawImage(c,0,0);tx.filter='none';
  const src=tx.getImageData(0,0,W,H).data,ca=c.getContext('2d').getImageData(0,0,W,H).data;relBuf(t);
  const o=new ImageData(W,H),od=o.data,a=b.ang*Math.PI/180,lx=Math.cos(a),ly=-Math.sin(a),k=b.depth/100*(2.4/Math.max(1,b.size/3));
  const hc=hex2rgb(b.hc),sc=hex2rgb(b.sc);
  for(let y=1;y<H-1;y++)for(let xx=1;xx<W-1;xx++){const i=(y*W+xx)*4;if(ca[i+3]<8)continue;
    const gx=(src[i+4+3]-src[i-4+3])/255,gy=(src[i+W*4+3]-src[i-W*4+3])/255;const d=-(gx*lx+gy*ly)*k*3;
    if(d>0){od[i]=hc[0];od[i+1]=hc[1];od[i+2]=hc[2];od[i+3]=Math.min(255,d*255*b.ha)*ca[i+3]/255}else{od[i]=sc[0];od[i+1]=sc[1];od[i+2]=sc[2];od[i+3]=Math.min(255,-d*255*b.sa)*ca[i+3]/255}}
  const e=getBuf();e.getContext('2d').putImageData(o,0,0);drawTo(x,e,1);relBuf(e)}

/* ================= Smart filters ================= */
const SF={
 gblur:{n:'Làm mờ Gaussian',d:{r:6},ui:[['r','Bán kính',0,60,1,'px']]},
 motion:{n:'Làm mờ chuyển động',d:{d:24,a:0},ui:[['d','Khoảng cách',1,120,1,'px'],['a','Góc',-180,180,1,'°']]},
 sharpen:{n:'Làm nét (Unsharp)',d:{amt:100,r:2},ui:[['amt','Lượng',0,400,1,'%'],['r','Bán kính',.5,10,.5,'px']]},
 noise:{n:'Thêm nhiễu hạt',d:{amt:20,mono:true},ui:[['amt','Lượng',0,100,1,'%']],chk:[['mono','Nhiễu đơn sắc']]},
 pixel:{n:'Pixel hóa',d:{s:12},ui:[['s','Cỡ ô',2,100,1,'px']]},
 emboss:{n:'Chạm nổi (Emboss)',d:{amt:100},ui:[['amt','Lượng',0,300,1,'%']]},
 edges:{n:'Dò cạnh',d:{amt:100},ui:[['amt','Lượng',0,300,1,'%']]},
 chroma:{n:'Lệch màu (Chromatic)',d:{s:6},ui:[['s','Độ lệch',0,40,1,'px']]},
 vig:{n:'Vignette',d:{amt:60},ui:[['amt','Lượng',0,100,1,'%']]}};
function applySF(c,list,bb){const x=c.getContext('2d');
  for(const f of list){if(f.off)continue;
    if(f.k==='gblur'||f.k==='motion'||f.k==='pixel'||f.k==='vig'){
      const t=getBuf(),tx=t.getContext('2d');
      if(f.k==='gblur'){tx.filter=`blur(${f.r}px)`;tx.drawImage(c,0,0)}
      else if(f.k==='motion'){const n=Math.max(2,Math.min(48,Math.round(f.d))),a=f.a*Math.PI/180;for(let i=0;i<n;i++){const o=(i/(n-1)-.5)*f.d;tx.globalAlpha=1/(i+1);tx.drawImage(c,Math.cos(a)*o,Math.sin(a)*o)}}
      else if(f.k==='pixel'){const s=Math.max(2,f.s),w=Math.max(1,Math.ceil(c.width/s)),h=Math.max(1,Math.ceil(c.height/s)),sm=document.createElement('canvas');sm.width=w;sm.height=h;sm.getContext('2d').drawImage(c,0,0,w,h);tx.imageSmoothingEnabled=false;tx.drawImage(sm,0,0,w*s,h*s)}
      else{tx.drawImage(c,0,0);const g=tx.createRadialGradient(bb.x+bb.w/2,bb.y+bb.h/2,Math.min(bb.w,bb.h)*.25,bb.x+bb.w/2,bb.y+bb.h/2,Math.hypot(bb.w,bb.h)/2);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,`rgba(0,0,0,${f.amt/100})`);tx.globalCompositeOperation='source-atop';tx.fillStyle=g;tx.fillRect(0,0,t.width,t.height)}
      x.clearRect(0,0,c.width,c.height);x.drawImage(t,0,0);relBuf(t);continue}
    const W=c.width,H=c.height,id=x.getImageData(0,0,W,H),d=id.data;
    if(f.k==='noise'){const A=f.amt*2.55;for(let i=0;i<d.length;i+=4){if(!d[i+3])continue;if(f.mono){const n=(Math.random()+Math.random()-1)*A;d[i]+=n;d[i+1]+=n;d[i+2]+=n}else{d[i]+=(Math.random()+Math.random()-1)*A;d[i+1]+=(Math.random()+Math.random()-1)*A;d[i+2]+=(Math.random()+Math.random()-1)*A}}}
    else if(f.k==='sharpen'){const t=getBuf(),tx=t.getContext('2d');tx.filter=`blur(${f.r}px)`;tx.drawImage(c,0,0);const bl=tx.getImageData(0,0,W,H).data;relBuf(t);const k=f.amt/100;
      for(let i=0;i<d.length;i+=4){if(!d[i+3])continue;for(let j=0;j<3;j++)d[i+j]=d[i+j]+k*(d[i+j]-bl[i+j])}}
    else if(f.k==='emboss'||f.k==='edges'){const s=d.slice(),k=f.amt/100;
      for(let y=1;y<H-1;y++)for(let xx=1;xx<W-1;xx++){const i=(y*W+xx)*4;if(!s[i+3])continue;
        for(let j=0;j<3;j++){const g=(p)=>s[p+j];
          if(f.k==='emboss'){const v=(g(i-W*4-4)*-2+g(i-W*4)*-1+g(i-4)*-1+g(i+4)*1+g(i+W*4)*1+g(i+W*4+4)*2);d[i+j]=128+v*k}
          else{const gx=-g(i-W*4-4)-2*g(i-4)-g(i+W*4-4)+g(i-W*4+4)+2*g(i+4)+g(i+W*4+4),gy=-g(i-W*4-4)-2*g(i-W*4)-g(i-W*4+4)+g(i+W*4-4)+2*g(i+W*4)+g(i+W*4+4);d[i+j]=Math.min(255,Math.hypot(gx,gy)*k)}}}}
    else if(f.k==='chroma'){const s=d.slice(),sh=Math.round(f.s);for(let y=0;y<H;y++)for(let xx=0;xx<W;xx++){const i=(y*W+xx)*4,xr=Math.max(0,xx-sh),xb=Math.min(W-1,xx+sh),ir=(y*W+xr)*4,ib=(y*W+xb)*4;d[i]=s[ir];d[i+2]=s[ib+2];d[i+3]=Math.max(s[i+3],s[ir+3]*.5,s[ib+3]*.5)}}
    x.putImageData(id,0,0)}}

/* ================= Adjustments ================= */
const clamp8=v=>v<0?0:v>255?255:v;
const ADJ={
 bc:{n:'Độ sáng / Tương phản',d:{b:0,c:0},ui:[['b','Độ sáng',-100,100,1,''],['c','Tương phản',-100,100,1,'']]},
 lv:{n:'Levels',d:{ch:'rgb',L:{rgb:[0,255,1,0,255],r:[0,255,1,0,255],g:[0,255,1,0,255],b:[0,255,1,0,255]}},custom:'lv'},
 cv:{n:'Curves',d:{ch:'rgb',P:{rgb:[[0,0],[255,255]],r:[[0,0],[255,255]],g:[[0,0],[255,255]],b:[[0,0],[255,255]]}},custom:'cv'},
 hs:{n:'Hue / Saturation',d:{h:0,s:0,l:0},ui:[['h','Sắc độ (Hue)',-180,180,1,'°'],['s','Bão hòa',-100,100,1,''],['l','Độ sáng',-100,100,1,'']]},
 vb:{n:'Vibrance',d:{v:0,s:0},ui:[['v','Vibrance',-100,100,1,''],['s','Bão hòa',-100,100,1,'']]},
 cb:{n:'Color Balance',d:{sh:[0,0,0],md:[0,0,0],hi:[0,0,0]},ui:[['sh.0','Bóng · Cyan–Đỏ',-100,100,1,''],['sh.1','Bóng · Magenta–Lục',-100,100,1,''],['sh.2','Bóng · Vàng–Lam',-100,100,1,''],['md.0','Trung gian · Cyan–Đỏ',-100,100,1,''],['md.1','Trung gian · Magenta–Lục',-100,100,1,''],['md.2','Trung gian · Vàng–Lam',-100,100,1,''],['hi.0','Sáng · Cyan–Đỏ',-100,100,1,''],['hi.1','Sáng · Magenta–Lục',-100,100,1,''],['hi.2','Sáng · Vàng–Lam',-100,100,1,'']]},
 bw:{n:'Trắng đen',d:{r:40,y:60,g:40,c:60,b:20,m:80},ui:[['r','Đỏ',-100,200,1,''],['y','Vàng',-100,200,1,''],['g','Lục',-100,200,1,''],['c','Cyan',-100,200,1,''],['b','Lam',-100,200,1,''],['m','Magenta',-100,200,1,'']]},
 ex:{n:'Exposure',d:{e:0,o:0,g:1},ui:[['e','Phơi sáng (EV)',-4,4,.05,''],['o','Offset',-.5,.5,.01,''],['g','Gamma',.2,3,.01,'']]},
 tp:{n:'Nhiệt độ màu',d:{t:0,ti:0},ui:[['t','Lạnh ↔ Ấm',-100,100,1,''],['ti','Xanh lục ↔ Hồng',-100,100,1,'']]},
 pf:{n:'Photo Filter',d:{color:'#ff9a2e',dens:25},ui:[['dens','Mật độ',0,100,1,'%']],cols:[['color','Màu lọc']]},
 gm:{n:'Gradient Map',d:{c1:'#1a0f3c',c2:'#ff4f99',c3:'#ffd43b'},ui:[],cols:[['c1','Bóng'],['c2','Trung gian'],['c3','Sáng']]},
 th:{n:'Threshold',d:{t:128},ui:[['t','Ngưỡng',1,255,1,'']]},
 po:{n:'Posterize',d:{n:4},ui:[['n','Số mức',2,16,1,'']]},
 inv:{n:'Invert (đảo màu)',d:{},ui:[]}};
function monoLUT(pts){
  const p=pts.slice().sort((a,b)=>a[0]-b[0]),n=p.length,lut=new Uint8Array(256);
  if(n<2){for(let i=0;i<256;i++)lut[i]=i;return lut}
  const dx=[],dy=[],m=[];for(let i=0;i<n-1;i++){dx[i]=p[i+1][0]-p[i][0]||1e-6;dy[i]=p[i+1][1]-p[i][1];m[i]=dy[i]/dx[i]}
  const t=[m[0]];for(let i=1;i<n-1;i++)t[i]=m[i-1]*m[i]<=0?0:(m[i-1]+m[i])/2;t[n-1]=m[n-2];
  for(let i=0;i<n-1;i++){if(m[i]===0){t[i]=t[i+1]=0}else{const a=t[i]/m[i],b=t[i+1]/m[i],s=a*a+b*b;if(s>9){const k=3/Math.sqrt(s);t[i]=k*a*m[i];t[i+1]=k*b*m[i]}}}
  for(let v=0;v<256;v++){let i=0;while(i<n-2&&v>p[i+1][0])i++;
    if(v<=p[0][0]){lut[v]=clamp8(p[0][1]);continue}if(v>=p[n-1][0]){lut[v]=clamp8(p[n-1][1]);continue}
    const h=dx[i],s=(v-p[i][0])/h,s2=s*s,s3=s2*s;
    lut[v]=clamp8(Math.round((2*s3-3*s2+1)*p[i][1]+(s3-2*s2+s)*h*t[i]+(-2*s3+3*s2)*p[i+1][1]+(s3-s2)*h*t[i+1]))}
  return lut}
function levelLUT(a){const[ib,iw,g,ob,ow]=a,lut=new Uint8Array(256);for(let v=0;v<256;v++){let t=(v-ib)/Math.max(1,iw-ib);t=t<0?0:t>1?1:t;t=Math.pow(t,1/Math.max(.05,g));lut[v]=clamp8(Math.round(ob+t*(ow-ob)))}return lut}
function rgb2hsl(r,g,b){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;const d=mx-mn;
  if(d>1e-6){s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h*=60}return[h,s,l]}
function hsl2rgb(h,s,l){h=((h%360)+360)%360/360;if(s<1e-6)return[l*255,l*255,l*255];const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q;
  const f=t=>{t=t<0?t+1:t>1?t-1:t;return t<1/6?p+(q-p)*6*t:t<.5?q:t<2/3?p+(q-p)*(2/3-t)*6:p};return[f(h+1/3)*255,f(h)*255,f(h-1/3)*255]}
function adjPix(d,a){const n=d.length;
  switch(a.kind){
   case 'bc':{const c=a.c>=0?1/(1-Math.min(.99,a.c/100)):(1+a.c/100),b=a.b*1.6;for(let i=0;i<n;i+=4){d[i]=clamp8((d[i]-127.5)*c+127.5+b);d[i+1]=clamp8((d[i+1]-127.5)*c+127.5+b);d[i+2]=clamp8((d[i+2]-127.5)*c+127.5+b)}break}
   case 'lv':{const m=levelLUT(a.L.rgb),R=levelLUT(a.L.r),G=levelLUT(a.L.g),B=levelLUT(a.L.b);for(let i=0;i<n;i+=4){d[i]=m[R[d[i]]];d[i+1]=m[G[d[i+1]]];d[i+2]=m[B[d[i+2]]]}break}
   case 'cv':{const m=monoLUT(a.P.rgb),R=monoLUT(a.P.r),G=monoLUT(a.P.g),B=monoLUT(a.P.b);for(let i=0;i<n;i+=4){d[i]=m[R[d[i]]];d[i+1]=m[G[d[i+1]]];d[i+2]=m[B[d[i+2]]]}break}
   case 'hs':{const sk=1+a.s/100;for(let i=0;i<n;i+=4){let[h,s,l]=rgb2hsl(d[i],d[i+1],d[i+2]);h+=a.h;s=Math.min(1,s*sk);l=a.l>=0?l+(1-l)*a.l/100:l*(1+a.l/100);const o=hsl2rgb(h,s,l);d[i]=o[0];d[i+1]=o[1];d[i+2]=o[2]}break}
   case 'vb':{const v=a.v/100,sa=1+a.s/100;for(let i=0;i<n;i+=4){const r=d[i],g=d[i+1],b=d[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b),s=mx?(mx-mn)/mx:0,k=1+v*(1-s),gr=.299*r+.587*g+.114*b,kk=k*sa;d[i]=clamp8(gr+(r-gr)*kk);d[i+1]=clamp8(gr+(g-gr)*kk);d[i+2]=clamp8(gr+(b-gr)*kk)}break}
   case 'cb':{const K=1.28;for(let i=0;i<n;i+=4){const r=d[i],g=d[i+1],b=d[i+2],L=(.299*r+.587*g+.114*b)/255,ws=Math.max(0,1-L*2),wh=Math.max(0,L*2-1),wm=1-ws-wh;
      const dr=(a.sh[0]*ws+a.md[0]*wm+a.hi[0]*wh)*K,dg=(a.sh[1]*ws+a.md[1]*wm+a.hi[1]*wh)*K,db=(a.sh[2]*ws+a.md[2]*wm+a.hi[2]*wh)*K;d[i]=clamp8(r+dr-(dg+db)*.15);d[i+1]=clamp8(g+dg-(dr+db)*.15);d[i+2]=clamp8(b+db-(dr+dg)*.15)}break}
   case 'bw':{const W=[a.r,a.y,a.g,a.c,a.b,a.m,a.r];for(let i=0;i<n;i+=4){const r=d[i],g=d[i+1],b=d[i+2],lu=.299*r+.587*g+.114*b,mx=Math.max(r,g,b),mn=Math.min(r,g,b),ch=(mx-mn);let w=50;
      if(ch>0){let h=mx===r?(g-b)/ch+(g<b?6:0):mx===g?(b-r)/ch+2:(r-g)/ch+4;const k=Math.floor(h)%6,f=h-Math.floor(h);w=W[k]*(1-f)+W[k+1]*f}
      const v=clamp8(lu+(w-50)/100*ch*1.4);d[i]=d[i+1]=d[i+2]=v}break}
   case 'ex':{const f=Math.pow(2,a.e),ig=1/Math.max(.05,a.g);for(let i=0;i<n;i+=4)for(let j=0;j<3;j++){let v=d[i+j]/255*f+a.o;v=v<0?0:v;d[i+j]=clamp8(Math.pow(v,ig)*255)}break}
   case 'tp':{const t=a.t*.6,ti=a.ti*.4;for(let i=0;i<n;i+=4){d[i]=clamp8(d[i]+t+ti*.5);d[i+1]=clamp8(d[i+1]-ti);d[i+2]=clamp8(d[i+2]-t+ti*.5)}break}
   case 'pf':{const c=hex2rgb(a.color),k=a.dens/100*.75;for(let i=0;i<n;i+=4){const lu=.299*d[i]+.587*d[i+1]+.114*d[i+2];let r=d[i]+(c[0]-d[i])*k,g=d[i+1]+(c[1]-d[i+1])*k,b=d[i+2]+(c[2]-d[i+2])*k;const l2=.299*r+.587*g+.114*b||1,s=lu/l2;d[i]=clamp8(r*s);d[i+1]=clamp8(g*s);d[i+2]=clamp8(b*s)}break}
   case 'gm':{const A=hex2rgb(a.c1),B=hex2rgb(a.c2),C=hex2rgb(a.c3);for(let i=0;i<n;i+=4){const t=(.299*d[i]+.587*d[i+1]+.114*d[i+2])/255;let P,Q,u;if(t<.5){P=A;Q=B;u=t*2}else{P=B;Q=C;u=(t-.5)*2}d[i]=P[0]+(Q[0]-P[0])*u;d[i+1]=P[1]+(Q[1]-P[1])*u;d[i+2]=P[2]+(Q[2]-P[2])*u}break}
   case 'th':{for(let i=0;i<n;i+=4){const v=(.299*d[i]+.587*d[i+1]+.114*d[i+2])>=a.t?255:0;d[i]=d[i+1]=d[i+2]=v}break}
   case 'po':{const q=Math.max(2,a.n)-1;for(let i=0;i<n;i+=4){d[i]=Math.round(d[i]/255*q)/q*255;d[i+1]=Math.round(d[i+1]/255*q)/q*255;d[i+2]=Math.round(d[i+2]/255*q)/q*255}break}
   case 'inv':{for(let i=0;i<n;i+=4){d[i]=255-d[i];d[i+1]=255-d[i+1];d[i+2]=255-d[i+2]}break}}}
function adjCanvas(c,a){const x=c.getContext('2d'),id=x.getImageData(0,0,c.width,c.height);adjPix(id.data,a);x.putImageData(id,0,0)}
function applyAdjustNode(dst,l){const a=l.adj;if(!a)return;
  if(!maskOn(l)&&l.opacity>=1){adjCanvas(dst,a);return}
  const t=getBuf(),tx=t.getContext('2d');tx.drawImage(dst,0,0);adjCanvas(t,a);
  const M=getBuf(),mx=M.getContext('2d');
  if(maskOn(l)){if(l.mask.inv){mx.fillStyle='#fff';mx.fillRect(0,0,M.width,M.height);mx.globalCompositeOperation='destination-out'}mx.drawImage(maskCv(l),0,0);mx.globalCompositeOperation='source-over'}else{mx.fillStyle='#fff';mx.fillRect(0,0,M.width,M.height)}
  if(l.opacity<1){mx.globalCompositeOperation='destination-in';mx.fillStyle=`rgba(0,0,0,${l.opacity})`;mx.fillRect(0,0,M.width,M.height)}
  tx.globalCompositeOperation='destination-in';tx.drawImage(M,0,0);
  const dx=dst.getContext('2d');dx.save();dx.globalCompositeOperation='destination-out';dx.drawImage(M,0,0);dx.globalCompositeOperation='lighter';dx.drawImage(t,0,0);dx.restore();relBuf(t);relBuf(M)}
function hist256(c){const x=c.getContext('2d'),d=x.getImageData(0,0,c.width,c.height).data,H={rgb:new Uint32Array(256),r:new Uint32Array(256),g:new Uint32Array(256),b:new Uint32Array(256)};
  for(let i=0;i<d.length;i+=16){if(d[i+3]<8)continue;H.r[d[i]]++;H.g[d[i+1]]++;H.b[d[i+2]]++;H.rgb[Math.round(.299*d[i]+.587*d[i+1]+.114*d[i+2])]++}return H}

/* ================= Stage A2: layer tree, groups, masks UI ================= */
var msel=new Set(),maskTarget=null,mLast=null;
const inMask=()=>{const l=cur();return !!(l&&l.mask&&maskTarget===l.id&&!l.locked)};
const ICO={
 mask:'<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="2" width="12" height="12" rx="2"/><circle cx="8" cy="8" r="3.2" fill="currentColor"/></svg>',
 adj:'<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="8" cy="8" r="5.5"/><path d="M8 2.5v11a5.5 5.5 0 0 0 0-11z" fill="currentColor"/></svg>',
 grp:'<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><path d="M1.8 4.2c0-.7.5-1.2 1.2-1.2h3l1.3 1.6H13c.7 0 1.2.5 1.2 1.2v6.2c0 .7-.5 1.2-1.2 1.2H3c-.7 0-1.2-.5-1.2-1.2z"/></svg>',
 car:'<svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor"><path d="M2 3l3 4 3-4z"/></svg>'};
function layerRows(pid,depth,out){const ks=kids(pid);for(let i=ks.length-1;i>=0;i--){const l=ks[i];out.push({l,depth});if(l.type==='group'&&l.open!==false)layerRows(l.id,depth+1,out)}return out}
function renderLayers(){syncLctl();const list=$('#llist');const act=document.activeElement;if(act&&list.contains(act)&&act.tagName==='INPUT')return;
  $('#lcount').textContent=`Layer · ${layers.length}`;
  list.innerHTML='';
  if(!layers.length){list.innerHTML='<div class="empty" style="padding:6px 8px">Chưa có layer. Thêm ảnh, chữ hoặc hình ở thanh công cụ.</div>';renderFoot();return}
  layerRows(null,0,[]).forEach(({l,depth})=>{
    const d=document.createElement('div');d.className='li'+(l.id===sel?' on':'')+(msel.has(l.id)&&l.id!==sel?' sel2':'')+(effVis(l)?'':' off')+(l.clipTo?' clip':'');d.draggable=true;d.dataset.id=l.id;
    d.style.paddingLeft=(6+depth*14)+'px';
    const isG=l.type==='group',isA=l.type==='adjust';
    d.innerHTML=`${isG?`<button data-a="car" class="carb" style="transform:rotate(${l.open===false?-90:0}deg)" aria-label="Mở/đóng nhóm">${ICO.car}</button>`:''}${l.clipTo?'<span class="clipm" title="Clipping mask">↳</span>':''}${isG?`<div class="ico">${ICO.grp}</div>`:isA?`<div class="ico">${ICO.adj}</div>`:'<canvas class="th" width="88" height="60"></canvas>'}${l.mask?`<canvas class="mt${maskTarget===l.id&&l.id===sel?' act':''}${l.mask.on===false?' offm':''}" data-a="mask" width="30" height="30" title="Mask — bấm để vẽ trên mask"></canvas>`:''}<div class="nm" title="${esc(l.name)}">${esc(l.name)}</div>${hasFx(l)?'<span class="fxb" title="Có hiệu ứng">fx</span>':''}<button data-a="vis" aria-label="Ẩn/hiện">${ic(l.visible?'eye':'eyeoff')}</button><button data-a="lock" aria-label="Khóa">${ic(l.locked?'lock':'unlock')}</button>`;
    const th=d.querySelector('canvas.th');if(th){const c=th.getContext('2d');c.scale(88/doc.w,60/doc.h);try{drawLayer(c,l,true)}catch(e){}}
    const mt=d.querySelector('canvas.mt');if(mt){const c=mt.getContext('2d');c.fillStyle='#000';c.fillRect(0,0,30,30);try{if(l.mask.inv){c.fillStyle='#fff';c.fillRect(0,0,30,30);c.globalCompositeOperation='destination-out'}c.drawImage(maskCv(l),0,0,30,30)}catch(e){}if(l.mask.inv){c.globalCompositeOperation='destination-over';c.fillStyle='#000';c.fillRect(0,0,30,30)}}
    list.appendChild(d)});
  renderFoot()}
function renderFoot(){const l=cur();$('#lfoot').innerHTML=`<button class="btn ic" data-a="new" title="Layer mới">${ic('plus')}</button><button class="btn ic" data-a="fx" title="Kiểu layer & bộ lọc (fx)" ${l?'':'disabled'} style="font:italic 700 12px var(--body)">fx</button><button class="btn ic" data-a="mkmask" title="Thêm mask" ${l&&!l.mask&&!isAdj(l)||l&&isAdj(l)&&!l.mask?'':'disabled'}>${ICO.mask}</button><button class="btn ic" data-a="mkadj" title="Layer điều chỉnh">${ICO.adj}</button><button class="btn ic" data-a="mkgrp" title="Nhóm layer (Ctrl+G)" ${l?'':'disabled'}>${ICO.grp}</button><span class="vsep" style="min-height:18px"></span><button class="btn ic" data-a="up" title="Đưa lên" ${l?'':'disabled'}>${ic('up')}</button><button class="btn ic" data-a="down" title="Đưa xuống" ${l?'':'disabled'}>${ic('down')}</button><button class="btn ic" data-a="dup" title="Nhân đôi (Ctrl+D)" ${l?'':'disabled'}>${ic('copy')}</button><span class="sp"></span><button class="btn ic" data-a="del" title="Xóa (Delete)" ${l?'':'disabled'}>${ic('trash')}</button>`}
$('#lfoot').addEventListener('click',e=>{const b=e.target.closest('button');if(!b||b.disabled)return;const a=b.dataset.a;
  if(a==='mkmask'){const l=cur();if(l)addMaskCmd(l,msk?'sel':'reveal')}
  else if(a==='mkadj'){const r=b.getBoundingClientRect();showMenu(Object.keys(ADJ).map(k=>({t:ADJ[k].n,f:()=>addAdjust(k)})),r.left,r.top,true)}
  else if(a==='mkgrp')groupSel()});
function addMaskCmd(l,mode){if(l.mask){toast('Layer đã có mask.');return}if(addMask(l,mode)){maskTarget=l.id;if(tool!=='brush'&&tool!=='eraser')setTool('brush');commit(true,'Thêm mask')}}

/* ---- remove old handlers' effect: new click/drag on the list ---- */
llist.addEventListener('click',e=>{const li=e.target.closest('.li');if(!li)return;const l=byId(li.dataset.id);if(!l)return;const b=e.target.closest('button,canvas.mt');
  if(b){const a=b.dataset.a;
    if(a==='vis'){l.visible=!l.visible;commit(false,'Ẩn/hiện layer');return}
    if(a==='lock'){l.locked=!l.locked;commit(false,'Khóa layer');return}
    if(a==='car'){l.open=l.open===false;renderLayers();return}
    if(a==='mask'){sel=l.id;msel=new Set([l.id]);maskTarget=maskTarget===l.id?null:l.id;if(maskTarget&&tool!=='brush'&&tool!=='eraser')setTool('brush');refresh();return}}
  if(e.ctrlKey||e.metaKey){msel.has(l.id)?msel.delete(l.id):msel.add(l.id);if(!msel.size)msel.add(l.id);sel=l.id}
  else if(e.shiftKey&&sel){const rows=layerRows(null,0,[]).map(r=>r.l.id),a=rows.indexOf(sel),z=rows.indexOf(l.id);if(a>=0&&z>=0){msel=new Set(rows.slice(Math.min(a,z),Math.max(a,z)+1))}}
  else{msel=new Set([l.id]);sel=l.id}
  maskTarget=null;if(tool==='brush'||tool==='eraser')setTool('select');refresh()});
var dragId2=null;
function dropZone(e,li){const r=li.getBoundingClientRect(),y=(e.clientY-r.top)/r.height,t=byId(li.dataset.id);return t&&t.type==='group'?(y<.25?'above':y>.75?'below':'into'):(y<.5?'above':'below')}
llist.addEventListener('dragstart',e=>{const li=e.target.closest('.li');if(li){dragId2=li.dataset.id;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',dragId2)}});
llist.addEventListener('dragover',e=>{const li=e.target.closest('.li');if(!li||!dragId2)return;e.preventDefault();llist.querySelectorAll('.li').forEach(x=>x.classList.remove('o-above','o-below','o-into'));li.classList.add('o-'+dropZone(e,li))});
llist.addEventListener('drop',e=>{const li=e.target.closest('.li');e.preventDefault();if(!li||!dragId2)return;const z=dropZone(e,li),id=dragId2;dragId2=null;moveNode(id,li.dataset.id,z)});
llist.addEventListener('dragend',()=>{dragId2=null;llist.querySelectorAll('.li').forEach(x=>x.classList.remove('o-above','o-below','o-into'))});
function moveNode(id,tid,zone){const m=byId(id),t=byId(tid);if(!m||!t||m===t)return;if(descIds(id).includes(tid))return;
  layers.splice(layers.indexOf(m),1);
  if(zone==='into'&&t.type==='group'){m.parent=t.id;const ks=kids(t.id),ref=ks.length?ks[ks.length-1]:t;layers.splice(layers.indexOf(ref)+1,0,m);t.open=true}
  else{m.parent=t.parent||null;layers.splice(layers.indexOf(t)+(zone==='above'?1:0),0,m)}
  commit(false,'Đổi thứ tự')}

/* ---- groups ---- */
function selNodes(){const ids=msel.size?[...msel]:(sel?[sel]:[]);let ns=ids.map(byId).filter(Boolean);const set=new Set(ns.map(n=>n.id));return ns.filter(n=>{let p=n.parent?byId(n.parent):null;while(p){if(set.has(p.id))return false;p=p.parent?byId(p.parent):null}return true})}
function groupSel(){const ns=selNodes();if(!ns.length){toast('Chọn layer cần gộp nhóm.');return}
  ns.sort((a,b)=>layers.indexOf(a)-layers.indexOf(b));const top=ns[ns.length-1];
  const g=mk('group',{blend:'pass',open:true,w:doc.w,h:doc.h});g.parent=top.parent||null;
  const topIdx=layers.indexOf(top);ns.forEach(n=>layers.splice(layers.indexOf(n),1));
  const at=topIdx-(ns.length-1);layers.splice(at,0,...ns,g);ns.forEach((n,i)=>{n.parent=g.id;if(i===0)n.clipTo=false});
  sel=g.id;msel=new Set([g.id]);commit(true,'Nhóm layer')}
function ungroupSel(){const g=cur();if(!isGroup(g)){toast('Chọn một nhóm để bỏ nhóm.');return}
  const ks=kids(g.id);ks.forEach(k=>layers.splice(layers.indexOf(k),1));const idx=layers.indexOf(g);layers.splice(idx,1,...ks);ks.forEach(k=>k.parent=g.parent||null);
  maskCache.delete(g.id);sel=ks.length?ks[ks.length-1].id:null;msel=new Set(sel?[sel]:[]);commit(true,'Bỏ nhóm')}
function toggleClip(){const l=cur();if(!l)return;const sib=kids(l.parent||null);if(sib.indexOf(l)<=0&&!l.clipTo){toast('Cần có layer bên dưới để cắt theo.');return}l.clipTo=!l.clipTo;commit(true,l.clipTo?'Tạo clipping mask':'Bỏ clipping mask')}

/* ---- delete / duplicate / reorder / raster / merge ---- */
function delLayer(id){const l=byId(id);if(!l)return;const ids=[id,...descIds(id)];layers=layers.filter(x=>!ids.includes(x.id));ids.forEach(i=>{paint.delete(i);maskCache.delete(i);msel.delete(i)});if(ids.includes(sel))sel=null;commit(true,'Xóa layer')}
function cloneNode(s,parent){const n=JSON.parse(JSON.stringify(s,(k,v)=>k[0]==='_'?undefined:v));n.id=uid();n.parent=parent;
  if(s.type==='draw'&&paint.has(s.id)){const c=document.createElement('canvas'),o=paint.get(s.id);c.width=o.width;c.height=o.height;c.getContext('2d').drawImage(o,0,0);paint.set(n.id,c)}return n}
function dupLayer(id){const s=byId(id);if(!s)return;const out=[];
  const rec=(src,par,top)=>{const n=cloneNode(src,par);if(top)n.name=src.name+' (bản sao)';out.push(n);if(src.type==='group')kids(src.id).forEach(k=>rec(k,n.id,false));return n};
  const top=rec(s,s.parent||null,true);if(!isGroup(s)&&!isAdj(s)){top.x+=24;top.y+=24}
  layers.splice(layers.indexOf(s)+1,0,...out);sel=top.id;msel=new Set([top.id]);commit(true,'Nhân đôi layer')}
function reorder(id,to){const l=byId(id);if(!l)return;const ks=kids(l.parent||null),i=ks.indexOf(l);if(i<0)return;const j=to==='top'?ks.length-1:to==='bottom'?0:clampv(i+to,0,ks.length-1);if(i===j)return;
  const tgt=ks[j];layers.splice(layers.indexOf(l),1);layers.splice(layers.indexOf(tgt)+(j>i?1:0),0,l);commit(false,'Đổi thứ tự')}
function moveLayer(id,d){reorder(id,d)}
function rasterize(list,plain,name){let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
  list.forEach(l=>{const b=bounds(l);x0=Math.min(x0,b.x0);y0=Math.min(y0,b.y0);x1=Math.max(x1,b.x1);y1=Math.max(y1,b.y1)});
  x0=Math.max(0,Math.floor(x0));y0=Math.max(0,Math.floor(y0));x1=Math.min(doc.w,Math.ceil(x1));y1=Math.min(doc.h,Math.ceil(y1));
  const w=x1-x0,h=y1-y0;if(w<1||h<1){toast('Layer nằm ngoài canvas, không có gì để gộp.');return null}
  const full=document.createElement('canvas');full.width=doc.w;full.height=doc.h;stopId=null;stopped=false;
  const vis=list.map(l=>l.visible);list.forEach(l=>l.visible=true);composeInto(full,list,plain);list.forEach((l,i)=>l.visible=vis[i]);
  const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(full,x0,y0,w,h,0,0,w,h);
  const k=keyId();store.set(k,c.toDataURL('image/png'));return mk('draw',{x:x0,y:y0,w,h,pw:w,ph:h,src:k,name:name||'Gộp'})}
function replaceNodes(old,n){ // thay các node (và con cháu) bằng n tại vị trí node trên cùng
  const ids=new Set();old.forEach(o=>{ids.add(o.id);descIds(o.id).forEach(i=>ids.add(i))});const top=old.reduce((a,b)=>layers.indexOf(a)>layers.indexOf(b)?a:b);
  n.parent=top.parent||null;const at=layers.indexOf(top);layers.splice(at,0,n);layers=layers.filter(x=>x===n||!ids.has(x.id));ids.forEach(i=>{paint.delete(i);maskCache.delete(i)});sel=n.id;msel=new Set([n.id])}
function mergeDown(){const l=cur();if(!l)return;const ks=kids(l.parent||null),i=ks.indexOf(l);if(i<1){toast('Không có layer bên dưới để gộp.');return}
  const b=ks[i-1];const n=rasterize([b,l],false,b.name+' + '+l.name);if(!n)return;replaceNodes([b,l],n);commit(true,'Gộp xuống dưới')}
function mergeVisible(){const v=kids(null).filter(l=>l.visible);if(v.length<2){toast('Cần ít nhất 2 layer đang hiện.');return}const n=rasterize(v,false,'Đã gộp');if(!n)return;replaceNodes(v,n);commit(true,'Gộp layer hiển thị')}
function rasterOne(){const l=cur();if(!l)return;
  if(l.type==='adjust'){toast('Layer điều chỉnh không có điểm ảnh. Dùng "Gộp xuống dưới" để áp vào layer bên dưới.');return}
  if(l.type==='draw'&&!hasFx(l)&&!maskOn(l)&&!l.radius){toast('Layer đã là điểm ảnh.');return}
  if(l.type==='image'&&!hasFx(l)&&!maskOn(l)&&!l.radius){toast('Layer ảnh đã là điểm ảnh.');return}
  const n=rasterize([l],true,l.name);if(!n)return;if(!isGroup(l)){n.opacity=l.opacity;n.blend=l.blend}else{n.opacity=l.opacity}replaceNodes([l],n);commit(true,'Chuyển thành điểm ảnh')}

/* ---- adjustments / filters / styles commands ---- */
function addAdjust(kind){const l=cur(),a=mk('adjust',{name:ADJ[kind].n,w:doc.w,h:doc.h,adj:Object.assign({kind},JSON.parse(JSON.stringify(ADJ[kind].d)))});
  a.parent=l?(l.parent||null):null;layers.splice(l?layers.indexOf(l)+1:layers.length,0,a);sel=a.id;msel=new Set([a.id]);maskTarget=null;
  if(tool==='brush'||tool==='eraser')setTool('select');commit(true,'Thêm '+a.name);setTab('props')}
function addSF(k){const l=cur();if(!l||isGroup(l)||isAdj(l)){toast('Chọn một layer ảnh / chữ / hình để thêm bộ lọc thông minh.');return}ensureFx(l);l.sf.push(Object.assign({k},JSON.parse(JSON.stringify(SF[k].d))));commit(true,SF[k].n);setTab('props')}
const FXN={stroke:'Viền (Stroke)',ishadow:'Bóng trong',oglow:'Phát sáng ngoài',iglow:'Phát sáng trong',cover:'Phủ màu',gover:'Phủ chuyển màu',bevel:'Bevel & Emboss'};
function toggleFx(k){const l=cur();if(!l||isGroup(l)||isAdj(l))return;ensureFx(l);l.fx[k].on=!l.fx[k].on;commit(true,FXN[k]);setTab('props')}
function clearFx(){const l=cur();if(!l)return;l.f={...F0};l.sh.on=false;l.fx=newFx();l.sf=[];commit(true,'Xóa hiệu ứng')}
function fxMenu(b){const l=cur();if(!l)return;const r=b.getBoundingClientRect();ensureFx(l);const leaf=!isGroup(l)&&!isAdj(l);
  showMenu([{t:'Bóng đổ',dis:!leaf,on:l.sh.on,f:()=>{l.sh.on=!l.sh.on;commit(true,'Bóng đổ')}},...Object.keys(FXN).map(k=>({t:FXN[k],dis:!leaf,on:l.fx[k].on,f:()=>toggleFx(k)})),'-',
   {t:'Bộ lọc thông minh',dis:!leaf,sub:Object.keys(SF).map(k=>({t:SF[k].n,f:()=>addSF(k)}))},'-',{t:'Xóa mọi hiệu ứng',f:clearFx}],r.left,r.top,true)}

/* ---- mask painting ---- */
function dab(x,cx,cy,r,hard,color,a,erase){x.save();x.globalCompositeOperation=erase?'destination-out':'source-over';
  if(hard>=.98){x.globalAlpha=a;x.fillStyle=color;x.beginPath();x.arc(cx,cy,r,0,7);x.fill()}
  else{const g=x.createRadialGradient(cx,cy,r*hard,cx,cy,r);g.addColorStop(0,rgba(color,a));g.addColorStop(1,rgba(color,0));x.fillStyle=g;x.beginPath();x.arc(cx,cy,r,0,7);x.fill()}x.restore()}
function maskStroke(x,p0,p1,o){const dx=p1.x-p0.x,dy=p1.y-p0.y,len=Math.hypot(dx,dy),step=Math.max(1,o.size*(o.spacing||.1)),n=Math.max(1,Math.ceil(len/step));
  for(let i=p0.first?0:1;i<=n;i++){const t=i/n;dab(x,p0.x+dx*t,p0.y+dy*t,o.size/2,o.hard,o.color,o.a,o.erase)}}
function maskPaintStart(p,e){const l=cur(),c=maskCv(l);c._dirty=true;drag={mode:'paint',mask:true,id:l.id,moved:true};mLast=null;board.setPointerCapture(e.pointerId);maskPaintTo(p)}
function maskPaintTo(p){const l=cur();if(!l||!l.mask)return;const c=maskCv(l),x=c.getContext('2d');
  const lum=hex2rgb(brush.color);const white=(.299*lum[0]+.587*lum[1]+.114*lum[2])>=128;const erase=(tool==='eraser')?white:!white;
  const q={x:p.x,y:p.y,first:!mLast};maskStroke(x,mLast||q,q,{size:brush.size,hard:brush.hard==null?.8:brush.hard,color:'#ffffff',a:(brush.flow==null?1:brush.flow)*(brush.opacity==null?1:brush.opacity),erase});mLast={x:p.x,y:p.y};render()}
function maskPaintEnd(d){const l=byId(d.id);if(!l)return;saveMask(l);commit(false,'Vẽ mask')}

/* ---- mask commands ---- */
function stageAct(a,b){const l=cur();
  if(a==='fontpick'){fontPicker();return true}
  if(a.startsWith('maskadd:')){if(l)addMaskCmd(l,a.slice(8));return true}
  if(a==='maskdel'){if(l&&l.mask){maskCache.delete(l.id);l.mask=null;maskTarget=null;commit(true,'Xóa mask')}return true}
  if(a==='maskapply'){if(l&&l.mask){bakeMask(l);maskTarget=null;commit(true,'Áp mask')}return true}
  if(a==='maskpaint'){if(l&&l.mask){maskTarget=maskTarget===l.id?null:l.id;if(maskTarget&&tool!=='brush'&&tool!=='eraser')setTool('brush');refresh()}return true}
  if(a==='maskfromsel'){if(l&&l.mask&&msk){const c=maskCv(l),x=c.getContext('2d');x.save();x.globalCompositeOperation='destination-out';const t=document.createElement('canvas');t.width=doc.w;t.height=doc.h;const tx=t.getContext('2d');tx.fillStyle='#fff';tx.fillRect(0,0,doc.w,doc.h);maskCanvas(t,true);x.drawImage(t,0,0);x.restore();c._dirty=true;saveMask(l);commit(false,'Ẩn vùng chọn trên mask')}else toast('Cần mask và vùng chọn.');return true}
  if(a.startsWith('sfadd:')){addSF(a.slice(6));return true}
  if(a.startsWith('sfdel:')){if(l&&l.sf){l.sf.splice(+a.slice(6),1);commit(true,'Xóa bộ lọc')}return true}
  if(a.startsWith('sftog:')){if(l&&l.sf){const f=l.sf[+a.slice(6)];f.off=!f.off;commit(true,'Bật/tắt bộ lọc')}return true}
  if(a.startsWith('adjch:')){if(l&&l.adj){l.adj.ch=a.slice(6);buildProps()}return true}
  if(a==='curvereset'){if(l&&l.adj&&l.adj.P){l.adj.P[l.adj.ch]=[[0,0],[255,255]];commit(true,'Reset Curves')}return true}
  if(a==='lvreset'){if(l&&l.adj&&l.adj.L){l.adj.L[l.adj.ch]=[0,255,1,0,255];commit(true,'Reset Levels')}return true}
  if(a==='lvauto'){if(l&&l.adj&&l.adj.L){const H=hist256(renderBelow(l)),h=H[l.adj.ch==='rgb'?'rgb':l.adj.ch];let tot=0;h.forEach(v=>tot+=v);let acc=0,lo=0,hi=255;for(let i=0;i<256;i++){acc+=h[i];if(acc>tot*.005){lo=i;break}}acc=0;for(let i=255;i>=0;i--){acc+=h[i];if(acc>tot*.005){hi=i;break}}l.adj.L[l.adj.ch]=[lo,Math.max(lo+2,hi),1,0,255];commit(true,'Auto Levels')}return true}
  if(a==='fxreset'){clearFx();return true}
  if(a==='adjreset'){if(l&&l.adj){const k=l.adj.kind;l.adj=Object.assign({kind:k},JSON.parse(JSON.stringify(ADJ[k].d)));commit(true,'Reset điều chỉnh')}return true}
  if(a==='ungroup'){ungroupSel();return true}
  return false}

/* ================= Stage A3: properties UI for masks / styles / filters / adjustments ================= */
const FXU={
 stroke:{n:'Viền (Stroke)',cols:[['color','Màu']],rng:[['w','Độ dày',0,80,1,1,'px'],['a','Độ đậm',0,100,1,100,'%']],sel:['pos','Vị trí',[['out','Bên ngoài'],['in','Bên trong'],['ctr','Ở giữa']]]},
 ishadow:{n:'Bóng trong (Inner Shadow)',cols:[['color','Màu']],rng:[['a','Độ đậm',0,100,1,100,'%'],['blur','Độ nhòe',0,80,1,1,'px'],['x','Lệch X',-60,60,1,1,'px'],['y','Lệch Y',-60,60,1,1,'px'],['choke','Choke',0,30,1,1,'px']]},
 oglow:{n:'Phát sáng ngoài (Outer Glow)',cols:[['color','Màu']],rng:[['a','Độ đậm',0,100,1,100,'%'],['blur','Độ nhòe',0,120,1,1,'px'],['spread','Lan rộng',0,40,1,1,'px']]},
 iglow:{n:'Phát sáng trong (Inner Glow)',cols:[['color','Màu']],rng:[['a','Độ đậm',0,100,1,100,'%'],['blur','Độ nhòe',0,80,1,1,'px'],['choke','Choke',0,30,1,1,'px']]},
 cover:{n:'Phủ màu (Color Overlay)',cols:[['color','Màu']],rng:[['a','Độ đậm',0,100,1,100,'%']],sel:['blend','Hòa trộn','BLEND']},
 gover:{n:'Phủ chuyển màu (Gradient Overlay)',cols:[['c1','Màu 1'],['c2','Màu 2']],rng:[['ang','Góc',-180,180,1,1,'°'],['a','Độ đậm',0,100,1,100,'%']]},
 bevel:{n:'Bevel & Emboss',cols:[['hc','Sáng'],['sc','Tối']],rng:[['depth','Độ sâu',0,300,1,1,'%'],['size','Cỡ',1,30,1,1,'px'],['ang','Hướng sáng',-180,180,1,1,'°'],['ha','Độ sáng',0,100,1,100,'%'],['sa','Độ tối',0,100,1,100,'%']]}};
const chipB=(a,t,on)=>`<button class="chip${on?' on':''}" data-act="${a}">${t}</button>`;
function maskSec(l){let h='';
  if(!l.mask){h+=`<div class="sec"><h4>Mặt nạ (Mask)</h4><div class="chips">${chipB('maskadd:reveal','+ Hiện hết')}${chipB('maskadd:hide','+ Ẩn hết')}${chipB('maskadd:sel','Từ vùng chọn')}${chipB('maskadd:hidesel','Ẩn vùng chọn')}</div></div>`}
  else{const ed=maskTarget===l.id;h+=`<div class="sec"><h4>Mặt nạ (Mask)</h4><div class="row" style="margin-top:0"><label><input type="checkbox" data-k="mask.on" data-rb="1" ${l.mask.on!==false?'checked':''}> Bật</label><label><input type="checkbox" data-k="mask.inv" data-rb="1" ${l.mask.inv?'checked':''}> Đảo</label></div>
    <div class="chips" style="margin-top:7px">${chipB('maskpaint',ed?'Đang vẽ trên mask — bấm để về layer':'Vẽ trên mask',ed)}${chipB('maskfromsel','Ẩn vùng chọn')}${isAdj(l)||isGroup(l)?'':chipB('maskapply','Áp mask')}${chipB('maskdel','Xóa mask')}</div>
    <div class="empty" style="margin-top:6px">Cọ trắng (màu trước sáng) = hiện, cọ đen = ẩn. Tẩy làm ngược lại.</div></div>`}
  return h}
function clipSec(l){const sib=kids(l.parent||null);return `<div class="row" style="margin:6px 0 0"><label><input type="checkbox" data-k="clipTo" data-rb="1" ${l.clipTo?'checked':''} ${sib.indexOf(l)>0||l.clipTo?'':'disabled'}> Clipping mask (cắt theo layer bên dưới)</label></div>`}
function styleSec(l){ensureFx(l);let h='<div class="sec"><h4>Kiểu layer (Layer Style)</h4>';
  for(const k in FXU){const u=FXU[k],f=l.fx[k];
    h+=`<div class="fxitem"><label class="fxh"><input type="checkbox" data-k="fx.${k}.on" data-rb="1" ${f.on?'checked':''}> ${u.n}</label>`;
    if(f.on){h+=`<div class="row" style="margin:5px 0 0">${u.cols.map(c=>colF(l,`fx.${k}.${c[0]}`,c[1])).join('')}`;
      if(u.sel){const opts=u.sel[2]==='BLEND'?Object.keys(BLEND).filter(b=>b!=='pass').map(b=>[b,BLEND_VI[b]]):u.sel[2];h+=`<select data-k="fx.${k}.${u.sel[0]}" data-t="s" aria-label="${u.sel[1]}" style="flex:1">${opts.map(o=>`<option value="${o[0]}" ${f[u.sel[0]]===o[0]?'selected':''}>${o[1]}</option>`).join('')}</select>`}
      h+='</div>'+u.rng.map(r=>rngF(l,r[1],`fx.${k}.${r[0]}`,r[2],r[3],r[4],r[5],r[6])).join('')}
    h+='</div>'}
  return h+'</div>'}
function sfSec(l){if(!l.sf)l.sf=[];let h='<div class="sec"><h4>Bộ lọc thông minh</h4>';
  l.sf.forEach((f,i)=>{const d=SF[f.k];if(!d)return;h+=`<div class="fxitem"><div class="row" style="margin:0;justify-content:space-between"><b style="font-size:12px;${f.off?'opacity:.45':''}">${d.n}</b><span class="seg"><button class="btn ic" data-act="sftog:${i}" title="Bật/tắt">${ic(f.off?'eyeoff':'eye')}</button><button class="btn ic" data-act="sfdel:${i}" title="Xóa bộ lọc">${ic('trash')}</button></span></div>`
    d.ui.forEach(u=>{h+=rngF(l,u[1],`sf.${i}.${u[0]}`,u[2],u[3],u[4],1,u[5])});(d.chk||[]).forEach(c=>{h+=`<div class="row" style="margin:6px 0 0"><label><input type="checkbox" data-k="sf.${i}.${c[0]}" data-rb="1" ${f[c[0]]?'checked':''}> ${c[1]}</label></div>`});h+='</div>'});
  h+=`<div class="chips" style="margin-top:6px">${Object.keys(SF).map(k=>chipB('sfadd:'+k,'+ '+SF[k].n.replace(/ \(.*\)/,''))).join('')}</div><div class="empty" style="margin-top:6px">Bộ lọc không phá hủy: chỉnh hoặc xóa bất cứ lúc nào.</div></div>`;return h}
function extraSecs(l){if(isGroup(l)||isAdj(l))return '';return depthSec(l)+maskSec(l)+clipSec(l).replace(/^/,'<div class="sec" style="border:0;padding-top:0">')+'</div>'+styleSec(l)+sfSec(l)}
function nodeProps(l){let h='';
  if(isGroup(l)){h+=`<div class="sec"><h4>${esc(l.name)} · Nhóm</h4>${rngF(l,'Độ mờ','opacity',0,100,1,100,'%')}<div class="row"><select data-k="blend" data-t="s" aria-label="Chế độ hòa trộn" style="width:100%">${Object.keys(BLEND).map(b=>`<option value="${b}" ${b===l.blend?'selected':''}>${BLEND_VI[b]}</option>`).join('')}</select></div>
     <div class="row"><button class="btn" data-act="ungroup">Bỏ nhóm</button></div><div class="empty" style="margin-top:8px">"Xuyên qua" cho các layer con hòa trộn trực tiếp với nền. Chọn chế độ khác để nhóm hoạt động như một ảnh riêng.</div></div>`+maskSec(l)+clipSec(l);return h}
  const d=ADJ[l.adj.kind]||{n:l.name,ui:[]};
  h+=`<div class="sec"><h4>${esc(l.name)} · ${d.n}</h4>`;
  if(d.custom==='lv'){const a=l.adj;h+=`<div class="chips" style="margin-bottom:6px">${[['rgb','RGB'],['r','Đỏ'],['g','Lục'],['b','Lam']].map(c=>chipB('adjch:'+c[0],c[1],a.ch===c[0])).join('')}${chipB('lvauto','Tự động')}${chipB('lvreset','Reset')}</div><canvas class="hist" id="adjHist" width="520" height="130"></canvas>
    ${rngF(l,'Đen vào',`adj.L.${a.ch}.0`,0,253,1,1,'')}${rngF(l,'Gamma',`adj.L.${a.ch}.2`,.1,5,.01,1,'')}${rngF(l,'Trắng vào',`adj.L.${a.ch}.1`,2,255,1,1,'')}${rngF(l,'Đen ra',`adj.L.${a.ch}.3`,0,255,1,1,'')}${rngF(l,'Trắng ra',`adj.L.${a.ch}.4`,0,255,1,1,'')}`}
  else if(d.custom==='cv'){const a=l.adj;h+=`<div class="chips" style="margin-bottom:6px">${[['rgb','RGB'],['r','Đỏ'],['g','Lục'],['b','Lam']].map(c=>chipB('adjch:'+c[0],c[1],a.ch===c[0])).join('')}${chipB('curvereset','Reset')}</div><canvas class="curve" id="adjCurve" width="520" height="520"></canvas><div class="empty" style="margin-top:6px">Bấm để thêm điểm, kéo để uốn đường cong, nhấp đúp để xóa điểm.</div>`}
  else{(d.cols||[]).forEach(c=>{h+=`<div class="row">${colF(l,'adj.'+c[0],c[1])}<span style="font-size:12px;color:var(--mute)">${c[1]}</span></div>`});(d.ui||[]).forEach(u=>{h+=rngF(l,u[1],'adj.'+u[0],u[2],u[3],u[4],1,u[5])});if(!d.ui.length&&!(d.cols||[]).length)h+='<div class="empty">Layer này không có tham số.</div>'}
  h+=`<div class="chips" style="margin-top:8px">${chipB('adjreset','Reset')}</div>`;
  h+=`</div><div class="sec"><h4>Hiển thị</h4>${rngF(l,'Độ mờ','opacity',0,100,1,100,'%')}${clipSec(l)}<div class="empty" style="margin-top:6px">Điều chỉnh áp lên mọi layer nằm dưới nó (hoặc chỉ layer ngay dưới nếu bật clipping mask). Dùng mask để chỉ áp một phần.</div></div>`+maskSec(l);return h}
function afterProps(l){if(!l||!isAdj(l)||!l.adj)return;const d=ADJ[l.adj.kind];if(!d||!d.custom)return;
  let H=null;try{H=hist256(renderBelow(l))}catch(e){}
  const drawHist=(cv,ch,yb)=>{const x=cv.getContext('2d'),W=cv.width,Hh=cv.height;x.clearRect(0,0,W,Hh);if(!H)return;const h=H[ch==='rgb'?'rgb':ch];let mx=1;h.forEach(v=>{if(v>mx)mx=v});x.fillStyle=ch==='r'?'#ff5a5a66':ch==='g'?'#4be07a66':ch==='b'?'#4d8dff66':'#9aa0b466';
    for(let i=0;i<256;i++){const bh=Math.sqrt(h[i]/mx)*(Hh-4);x.fillRect(i/256*W,Hh-bh,W/256+1,bh)}};
  if(d.custom==='lv'){const cv=$('#adjHist');if(cv){drawHist(cv,l.adj.ch);const x=cv.getContext('2d'),a=l.adj.L[l.adj.ch];x.fillStyle='#fff';x.fillRect(a[0]/255*cv.width-1,cv.height-14,3,14);x.fillStyle='#bbb';x.fillRect(a[1]/255*cv.width-1,cv.height-14,3,14)}}
  if(d.custom==='cv'){const cv=$('#adjCurve');if(!cv)return;const W=cv.width,Hh=cv.height,pad=10,a=l.adj;
    const tx=v=>pad+v/255*(W-2*pad),ty=v=>Hh-pad-v/255*(Hh-2*pad),ux=x=>Math.round(Math.max(0,Math.min(255,(x-pad)/(W-2*pad)*255))),uy=y=>Math.round(Math.max(0,Math.min(255,(Hh-pad-y)/(Hh-2*pad)*255)));
    const col={rgb:'#e8eaf2',r:'#ff6b6b',g:'#5be38a',b:'#6aa2ff'};
    const draw=()=>{const x=cv.getContext('2d');x.clearRect(0,0,W,Hh);x.strokeStyle='#ffffff18';x.lineWidth=1;for(let i=0;i<=4;i++){x.beginPath();x.moveTo(tx(i*63.75),ty(0));x.lineTo(tx(i*63.75),ty(255));x.moveTo(tx(0),ty(i*63.75));x.lineTo(tx(255),ty(i*63.75));x.stroke()}
      if(H){const h=H[a.ch==='rgb'?'rgb':a.ch];let mx=1;h.forEach(v=>{if(v>mx)mx=v});x.fillStyle='#9aa0b422';for(let i=0;i<256;i++){const bh=Math.sqrt(h[i]/mx)*(Hh-2*pad);x.fillRect(tx(i),ty(0)-bh,(W-2*pad)/256+1,bh)}}
      x.strokeStyle='#ffffff30';x.beginPath();x.moveTo(tx(0),ty(0));x.lineTo(tx(255),ty(255));x.stroke();
      const lut=monoLUT(a.P[a.ch]);x.strokeStyle=col[a.ch];x.lineWidth=3;x.beginPath();for(let i=0;i<256;i++){i?x.lineTo(tx(i),ty(lut[i])):x.moveTo(tx(i),ty(lut[i]))}x.stroke();
      a.P[a.ch].forEach(p=>{x.fillStyle='#14151c';x.strokeStyle=col[a.ch];x.lineWidth=3;x.beginPath();x.arc(tx(p[0]),ty(p[1]),8,0,7);x.fill();x.stroke()})};
    draw();let di=-1;
    const pt=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left)*W/r.width,(e.clientY-r.top)*Hh/r.height]};
    cv.onpointerdown=e=>{const[x,y]=pt(e),P=a.P[a.ch];let bi=-1,bd=1e9;P.forEach((p,i)=>{const dd=Math.hypot(tx(p[0])-x,ty(p[1])-y);if(dd<bd){bd=dd;bi=i}});
      if(bd>16){const np=[ux(x),uy(y)];P.push(np);P.sort((u,v)=>u[0]-v[0]);bi=P.indexOf(np)}di=bi;cv.setPointerCapture(e.pointerId);draw();render()};
    cv.onpointermove=e=>{if(di<0)return;const[x,y]=pt(e),P=a.P[a.ch];let nx=ux(x);const end=(di===0||di===P.length-1);
      if(end)nx=P[di][0];else nx=Math.max(P[di-1][0]+1,Math.min(P[di+1][0]-1,nx));P[di]=[nx,uy(y)];draw();render()};
    cv.onpointerup=cv.onpointercancel=()=>{if(di>=0){di=-1;commit(false,'Chỉnh Curves')}};
    cv.ondblclick=e=>{const[x,y]=pt(e),P=a.P[a.ch];let bi=-1,bd=1e9;P.forEach((p,i)=>{const dd=Math.hypot(tx(p[0])-x,ty(p[1])-y);if(dd<bd){bd=dd;bi=i}});if(bd<16&&bi>0&&bi<P.length-1){P.splice(bi,1);draw();commit(true,'Xóa điểm Curves')}}}}

/* ================= Stage A4: export to Bravin (tree-aware) ================= */
function exportOrder(){const out=[];(function walk(pid){kids(pid).forEach(l=>{if(l.type==='group')walk(l.id);else if(l.type!=='adjust')out.push(l)})})(null);return out}
function adjustsFor(l){const out=[];let n=l;while(n){const sib=kids(n.parent||null),i=sib.indexOf(n);for(let j=i+1;j<sib.length;j++){if(sib[j].type==='adjust'&&sib[j].visible&&!sib[j].clipTo)out.push(sib[j])}n=n.parent?byId(n.parent):null}return out}
function ancestors(l){const a=[];let n=l.parent?byId(l.parent):null;while(n){a.push(n);n=n.parent?byId(n.parent):null}return a}
async function buildBravin(o){const tracks=[];let i=0;
  for(const l of exportOrder()){
    if(l.clipTo)continue; // đã gộp vào layer gốc
    const vis=effVis(l);if(!vis&&!o.hidden)continue;
    const sib=kids(l.parent||null),idx=sib.indexOf(l),stack=[];for(let j=idx+1;j<sib.length&&sib[j].clipTo;j++)if(sib[j].visible)stack.push(sib[j]);
    const anc=ancestors(l),adj=o.bake===false?[]:adjustsFor(l),needFull=stack.length||adj.length||anc.some(maskOn);
    let x0,y0,x1,y1;
    if(needFull){x0=0;y0=0;x1=doc.w;y1=doc.h}else{const b=bounds(l);x0=Math.max(0,Math.floor(b.x0));y0=Math.max(0,Math.floor(b.y0));x1=Math.min(doc.w,Math.ceil(b.x1));y1=Math.min(doc.h,Math.ceil(b.y1))}
    const bw=x1-x0,bh=y1-y0;if(bw<1||bh<1)continue;
    const full=document.createElement('canvas');full.width=doc.w;full.height=doc.h;
    const was=l.visible;l.visible=true;stopId=null;stopped=false;composeInto(full,[l,...stack],true);l.visible=was;
    anc.forEach(a=>{if(maskOn(a))applyMask(full,a)});adj.forEach(a=>applyAdjustNode(full,a));
    const c=document.createElement('canvas');c.width=bw;c.height=bh;c.getContext('2d').drawImage(full,x0,y0,bw,bh,0,0,bw,bh);
    const op=anc.reduce((p,a)=>p*(a.opacity==null?1:a.opacity),l.opacity);
    tracks.push({id:'track-'+(++i),name:(anc.length?anc.map(a=>a.name).reverse().join(' / ')+' / ':'')+l.name,index:i-1,enabled:vis,locked:l.locked,clips:[{id:'clip-'+i,name:l.name,start:0,duration:o.duration,opacity:op,blendMode:l.blend,
      position:{x:x0,y:y0,width:bw,height:bh},media:{type:'image',mime:'image/png',encoding:'data-url',data:c.toDataURL('image/png')}}]});
    await new Promise(r=>setTimeout(r,0))}
  return JSON.stringify({format:'bravin-project',schema:1,generator:'Antifact 1.1',createdAt:new Date().toISOString(),
    canvas:{width:doc.w,height:doc.h,background:doc.bg||null},timeline:{fps:o.fps,duration:o.duration,trackOrder:'bottom-to-top'},tracks})}

/* ================= Stage B: brush engine + retouch tools ================= */
Object.assign(P,{
 clone:'<circle cx="12" cy="6.5" r="2.7"/><path d="M12 9.2V13M6.5 13h11v3.2h-11zM5 20h14"/>',
 heal:'<rect x="3" y="8.5" width="18" height="7" rx="3.5" transform="rotate(-45 12 12)"/><path d="M10.6 10.6h.01M13.4 13.4h.01M13.4 10.6h.01M10.6 13.4h.01"/>',
 spot:'<circle cx="12" cy="12" r="3.2"/><path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3"/>',
 dodge:'<circle cx="12" cy="9" r="5"/><path d="M12 14.5V21M9 21h6"/>',
 burn:'<path d="M12 3c1 4 5 5.5 5 10.2a5 5 0 0 1-10 0c0-2 1-3.2 2.2-4.4 0 2 .9 2.4 .9 2.4C10.2 8 11 6 12 3z"/>',
 sponge:'<rect x="4" y="9" width="16" height="9" rx="3.5"/><path d="M8 13.2h.01M12 12h.01M16 14h.01M10.5 16h.01"/>',
 blur:'<path d="M12 3c4 5 6 8 6 11a6 6 0 0 1-12 0c0-3 2-6 6-11z"/>',
 sharpen:'<path d="M12 4l8 15H4z"/><path d="M12 10v4"/>',
 smudge:'<path d="M5 17c4 1.5 6-1.5 8-4.5s4-4 6.5-3M6 21c3.5 0 6.5-1 9.5-4"/>',
 liquify:'<path d="M3 9c3-4 6 4 9 0s6 4 9 0M3 16c3-4 6 4 9 0s6 4 9 0"/>'});
Object.assign(brush,{hard:.8,opacity:1,flow:1,spacing:.1,smooth:0,tip:'round',press:true,str:50,range:'mid',spmode:'desat',lqmode:'push',sample:'cur',ang:45});
try{Object.assign(brush,JSON.parse(localStorage.getItem('af-brush')||'{}'),{color:brush.color})}catch(e){}
const saveBrush=()=>{try{const{color,...r}=brush;localStorage.setItem('af-brush',JSON.stringify(r))}catch(e){}};
const PIXTOOLS=['brush','eraser','clone','heal','spot','dodge','burn','sponge','blur','sharpen','smudge','liquify'];
TOOLS.push(['clone','clone','Clone Stamp (S)','S'],['heal','heal','Healing Brush (J)','J'],['spot','spot','Spot Healing (⇧J)','⇧J'],['dodge','dodge','Dodge – làm sáng (⇧O)','⇧O'],['burn','burn','Burn – làm tối (⇧B)','⇧B'],['sponge','sponge','Sponge – bão hòa (⇧S)','⇧S'],['blur','blur','Blur – làm mờ (⇧R)','⇧R'],['sharpen','sharpen','Sharpen – làm nét (⇧U)','⇧U'],['smudge','smudge','Smudge – vuốt (⇧M)','⇧M'],['liquify','liquify','Liquify – bóp méo (⇧L)','⇧L']);
const TOOLKEYS={s:'clone',j:'heal','S+j':'spot','S+o':'dodge','S+b':'burn','S+s':'sponge','S+r':'blur','S+u':'sharpen','S+m':'smudge','S+l':'liquify'};
const BRUSH_PRESETS=[
 {n:'Cọ mềm',size:48,hard:.2,opacity:1,flow:1,spacing:.08,tip:'round',smooth:15},{n:'Cọ cứng',size:28,hard:1,opacity:1,flow:1,spacing:.06,tip:'round',smooth:10},
 {n:'Airbrush',size:90,hard:0,opacity:1,flow:.12,spacing:.05,tip:'round',smooth:10},{n:'Mực',size:10,hard:1,opacity:1,flow:1,spacing:.04,tip:'round',smooth:55},
 {n:'Marker',size:34,hard:1,opacity:.85,flow:1,spacing:.05,tip:'calli',smooth:20},{n:'Phấn',size:46,hard:.6,opacity:1,flow:.8,spacing:.1,tip:'chalk',smooth:0},
 {n:'Tán xạ',size:70,hard:.7,opacity:1,flow:1,spacing:.35,tip:'scatter',smooth:0},{n:'Vuông',size:36,hard:1,opacity:1,flow:1,spacing:.08,tip:'square',smooth:0}];
var userBrushes=[];try{userBrushes=JSON.parse(localStorage.getItem('af-brushes')||'[]')}catch(e){}
var cloneSrc=null,cloneOff=null,ST=null,lqTimer=0;
const TIPS=[['round','Tròn'],['square','Vuông'],['calli','Bút lá'],['chalk','Phấn'],['scatter','Tán xạ']];

/* ---- helpers ---- */
const noiseTile=(()=>{const c=document.createElement('canvas');c.width=c.height=96;const x=c.getContext('2d'),d=x.createImageData(96,96);for(let i=0;i<d.data.length;i+=4){d.data[i]=d.data[i+1]=d.data[i+2]=255;d.data[i+3]=Math.random()<.55?255:Math.random()*120}x.putImageData(d,0,0);return c})();
const tmpPool=[];function tmpC(w,h){const c=tmpPool.pop()||document.createElement('canvas');c.width=Math.max(1,Math.ceil(w));c.height=Math.max(1,Math.ceil(h));return c}function relTmp(c){if(tmpPool.length<8)tmpPool.push(c)}
function toPx(l,p,c){const q=toLocal(l,p),k=c.width/l.w;return{x:(q.x+l.w/2)*k,y:(q.y+l.h/2)*k,k}}
function radialMask(x,r,hard){const g=x.createRadialGradient(r,r,r*Math.min(.99,hard),r,r,r);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(1,'rgba(255,255,255,0)');return g}
function tipDab(x,cx,cy,r,a,color){const t=brush.tip,hd=brush.hard;
  if(t==='round'){dab(x,cx,cy,r,hd,color,a,false);return}
  if(t==='square'){x.save();x.globalAlpha=a;x.fillStyle=color;x.translate(cx,cy);x.rotate(brush.ang*Math.PI/180);if(hd<1){x.shadowColor=color;x.shadowBlur=r*(1-hd)*.9}x.fillRect(-r*.85,-r*.85,r*1.7,r*1.7);x.restore();return}
  if(t==='calli'){x.save();x.globalAlpha=a;x.fillStyle=color;x.translate(cx,cy);x.rotate(brush.ang*Math.PI/180);x.beginPath();x.ellipse(0,0,r,r*.26,0,0,7);x.fill();x.restore();return}
  if(t==='chalk'){const d=Math.ceil(r*2)+2,t2=tmpC(d,d),tx=t2.getContext('2d');dab(tx,d/2,d/2,r,Math.min(hd,.7),color,a,false);tx.globalCompositeOperation='destination-in';const pat=tx.createPattern(noiseTile,'repeat');tx.fillStyle=pat;tx.save();tx.translate(-(cx%96),-(cy%96));tx.fillRect(0,0,d+96,d+96);tx.restore();x.drawImage(t2,cx-d/2,cy-d/2);relTmp(t2);return}
  if(t==='scatter'){const n=Math.max(4,Math.round(r/5));for(let i=0;i<n;i++){const an=Math.random()*6.283,rr=Math.sqrt(Math.random())*r*1.3;dab(x,cx+Math.cos(an)*rr,cy+Math.sin(an)*rr,Math.max(1.2,r*(.1+Math.random()*.22)),hd,color,a,false)}}}
function ensurePixel(l){ // chuyển layer ảnh/hình/chữ thành điểm ảnh để chỉnh sửa
  if(l.type==='draw')return l;
  const n=rasterize([l],true,l.name);if(!n)return null;n.opacity=l.opacity;n.blend=l.blend;replaceNodes([l],n);maskTarget=null;toast('Đã chuyển "'+n.name+'" thành điểm ảnh để chỉnh sửa.');return n}
function pixTarget(){let l=cur();
  if(tool==='brush'||tool==='eraser'){if(!l||l.type!=='draw'||l.locked||!l.visible){l=mk('draw',{x:0,y:0,w:doc.w,h:doc.h,pw:doc.w,ph:doc.h});const c=document.createElement('canvas');c.width=doc.w;c.height=doc.h;paint.set(l.id,c);l.src='';layers.push(l);sel=l.id;l._fresh=true}return l}
  if(!l||l.locked||!l.visible||isGroup(l)||isAdj(l)){toast('Chọn một layer ảnh để dùng công cụ này.');return null}
  if(tool==='clone'||tool==='heal'){if(l.type!=='draw'&&brush.sample==='cur'){return ensurePixel(l)}if(l.type!=='draw'){return ensurePixel(l)}return l}
  return ensurePixel(l)}
function srcCanvasFor(l,c){ // ảnh nguồn lấy mẫu, theo tọa độ layer
  if(brush.sample==='all'){const full=flatten(false),o=document.createElement('canvas');o.width=c.width;o.height=c.height;const x=o.getContext('2d'),k=c.width/l.w;x.translate(c.width/2,c.height/2);x.scale(k,k);x.rotate(-l.rot*Math.PI/180);x.scale(l.flipX?-1:1,l.flipY?-1:1);x.translate(-(l.x+l.w/2),-(l.y+l.h/2));x.drawImage(full,0,0);return o}
  const o=document.createElement('canvas');o.width=c.width;o.height=c.height;o.getContext('2d').drawImage(c,0,0);return o}
const pressK=e=>(brush.press&&e&&e.pointerType==='pen')?Math.max(.1,e.pressure||.5)*1.6:1;

/* ---- stroke lifecycle ---- */
function ptDown(p,e){
  if(inMask()&&(tool==='brush'||tool==='eraser')){maskPaintStart(p,e);return}
  if((tool==='clone'||tool==='heal')&&e.altKey){cloneSrc={x:p.x,y:p.y};cloneOff=null;toast('Đã đặt điểm nguồn. Giờ bấm kéo để vẽ.');updCur(e);return}
  if((tool==='clone'||tool==='heal')&&!cloneSrc){toast('Giữ Alt và bấm để chọn điểm nguồn trước.');return}
  const l=pixTarget();if(!l)return;const c=getPaint(l);
  const S={tool,id:l.id,c,x:c.getContext('2d'),k:c.width/l.w,last:null,pend:0,sp:null,bb:{x0:1e9,y0:1e9,x1:-1e9,y1:-1e9},press:pressK(e),dist:0};
  if(tool==='brush'||tool==='eraser'||tool==='clone'||tool==='heal'){S.base=document.createElement('canvas');S.base.width=c.width;S.base.height=c.height;S.base.getContext('2d').drawImage(c,0,0);S.sb=document.createElement('canvas');S.sb.width=c.width;S.sb.height=c.height;S.sx=S.sb.getContext('2d')}
  if(tool==='clone'||tool==='heal'){S.src=srcCanvasFor(l,c);if(!cloneOff)cloneOff={x:cloneSrc.x-p.x,y:cloneSrc.y-p.y};S.off=cloneOff}
  if(tool==='spot'){S.doc=document.createElement('canvas');S.doc.width=doc.w;S.doc.height=doc.h;S.dx=S.doc.getContext('2d')}
  if(tool==='smudge'){S.carry=null}
  if(tool==='liquify'){S.img=S.x.getImageData(0,0,c.width,c.height);S.hold=null}
  ST=S;drag={mode:'paint',pix:true,id:l.id,moved:true};board.setPointerCapture(e.pointerId);
  const pp=toPx(l,p,c);S.sp=p;ptMove(p,e,true)}
function ptMove(p,e,first){const S=ST;if(!S)return;const l=byId(S.id);if(!l)return;
  if(brush.smooth>0&&!first){const f=1-Math.min(.92,brush.smooth/100*.95);S.sp={x:S.sp.x+(p.x-S.sp.x)*f,y:S.sp.y+(p.y-S.sp.y)*f};p=S.sp}else S.sp=p;
  S.press=pressK(e);const q=toPx(l,p,S.c);
  const r=Math.max(.8,brush.size/2*q.k*S.press);
  if(!S.last){S.last={x:q.x,y:q.y};ptDab(S,q.x,q.y,r,0,0,p);ptRefresh(S);return}
  const dx=q.x-S.last.x,dy=q.y-S.last.y,len=Math.hypot(dx,dy);if(len<.01)return;
  const step=Math.max(1,r*2*(S.tool==='liquify'?.12:Math.max(.02,brush.spacing)));let t=S.pend;
  while(t<=len){const f=t/len;ptDab(S,S.last.x+dx*f,S.last.y+dy*f,r,dx/len,dy/len,p);t+=step}
  S.pend=t-len;S.last={x:q.x,y:q.y};ptRefresh(S)}
function ptRefresh(S){const l=byId(S.id);if(!l)return;
  if(S.sb){const x=S.x,c=S.c;x.save();x.setTransform(1,0,0,1,0,0);x.globalCompositeOperation='copy';x.drawImage(S.base,0,0);x.restore();
    x.save();x.globalAlpha=(S.tool==='eraser'?1:1)*brush.opacity;x.globalCompositeOperation=S.tool==='eraser'?'destination-out':'source-over';x.drawImage(S.sb,0,0);x.restore()}
  render()}
function bbAdd(S,x,y,r){S.bb.x0=Math.min(S.bb.x0,x-r);S.bb.y0=Math.min(S.bb.y0,y-r);S.bb.x1=Math.max(S.bb.x1,x+r);S.bb.y1=Math.max(S.bb.y1,y+r)}
function ptDab(S,cx,cy,r,dx,dy,p){const x=S.x,t=S.tool,c=S.c,W=c.width,H=c.height;bbAdd(S,cx,cy,r);
  if(t==='brush'){tipDab(S.sx,cx,cy,r,brush.flow*(S.tool==='brush'&&brush.press&&S.press!==1?Math.min(1,S.press):1),brush.color);return}
  if(t==='eraser'){tipDab(S.sx,cx,cy,r,brush.flow,'#000000');return}
  if(t==='clone'||t==='heal'){const l=byId(S.id),sp=toPx(l,{x:p.x+S.off.x,y:p.y+S.off.y},c),d=Math.ceil(r*2)+2,tm=tmpC(d,d),tx=tm.getContext('2d');
    // dùng toạ độ nguồn đã làm mượt theo cùng nhịp
    const ox=sp.x-(cx-(S.last?S.last.x:cx))*0;tx.drawImage(S.src,sp.x-d/2+(cx-toPx(l,p,c).x),sp.y-d/2+(cy-toPx(l,p,c).y),d,d,0,0,d,d);
    tx.globalCompositeOperation='destination-in';const g=tx.createRadialGradient(d/2,d/2,r*Math.min(.98,brush.hard),d/2,d/2,r);g.addColorStop(0,'rgba(0,0,0,1)');g.addColorStop(1,'rgba(0,0,0,0)');tx.fillStyle=g;tx.fillRect(0,0,d,d);
    S.sx.save();S.sx.globalAlpha=Math.min(1,brush.flow);S.sx.drawImage(tm,cx-d/2,cy-d/2);S.sx.restore();relTmp(tm);return}
  if(t==='spot'){const l=byId(S.id),q=toLocal(l,p);S.dx.fillStyle='#fff';S.dx.beginPath();S.dx.arc(p.x,p.y,brush.size/2*S.press,0,7);S.dx.fill();return}
  const rr=Math.ceil(r),x0=Math.max(0,Math.floor(cx-rr)),y0=Math.max(0,Math.floor(cy-rr)),x1=Math.min(W,Math.ceil(cx+rr)),y1=Math.min(H,Math.ceil(cy+rr)),w=x1-x0,h=y1-y0;if(w<2||h<2)return;
  const fall=(d)=>{const u=d/r;if(u>=1)return 0;const hd=brush.hard;return u<=hd?1:(1-(u-hd)/(1-hd+1e-6))};
  if(t==='dodge'||t==='burn'||t==='sponge'){const id=x.getImageData(x0,y0,w,h),d=id.data,amt=brush.str/100*.2;
    for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++){const i=(yy*w+xx)*4;if(!d[i+3])continue;const wt=fall(Math.hypot(x0+xx-cx,y0+yy-cy));if(wt<=0)continue;
      if(t==='sponge'){const[hh,s,l]=rgb2hsl(d[i],d[i+1],d[i+2]);const ns=brush.spmode==='sat'?Math.min(1,s+(1-s)*amt*wt*1.6):Math.max(0,s-s*amt*wt*1.6);const o=hsl2rgb(hh,ns,l);d[i]=o[0];d[i+1]=o[1];d[i+2]=o[2];continue}
      const lu=(.299*d[i]+.587*d[i+1]+.114*d[i+2])/255,rw=brush.range==='sh'?Math.pow(1-lu,2):brush.range==='hi'?lu*lu:4*lu*(1-lu)+.15,e=amt*wt*rw*brush.flow;
      for(let j=0;j<3;j++)d[i+j]=t==='dodge'?d[i+j]+(255-d[i+j])*e:d[i+j]*(1-e)}
    x.putImageData(id,x0,y0);return}
  if(t==='blur'||t==='sharpen'){const reg=tmpC(w,h),rx=reg.getContext('2d');rx.drawImage(c,x0,y0,w,h,0,0,w,h);
    const bl=tmpC(w,h),bx=bl.getContext('2d');bx.filter=`blur(${Math.max(1,r*.18)}px)`;bx.drawImage(reg,0,0);bx.filter='none';
    const a=rx.getImageData(0,0,w,h),b=bx.getImageData(0,0,w,h),ad=a.data,bd=b.data,s=brush.str/100*.5*brush.flow;
    for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++){const i=(yy*w+xx)*4,wt=fall(Math.hypot(x0+xx-cx,y0+yy-cy))*s;if(wt<=0)continue;
      if(t==='blur'){for(let j=0;j<4;j++)ad[i+j]=ad[i+j]+(bd[i+j]-ad[i+j])*wt}else if(ad[i+3]){for(let j=0;j<3;j++)ad[i+j]=Math.max(0,Math.min(255,ad[i+j]+(ad[i+j]-bd[i+j])*wt*5))}}
    x.putImageData(a,x0,y0);relTmp(reg);relTmp(bl);return}
  if(t==='smudge'){const d=Math.ceil(r*2)+2;
    if(!S.carry){S.carry=tmpC(d,d);S.carry.getContext('2d').drawImage(c,cx-d/2,cy-d/2,d,d,0,0,d,d);S.cd=d;return}
    const cv=S.carry,tm=tmpC(S.cd,S.cd),tx=tm.getContext('2d');tx.drawImage(cv,0,0);tx.globalCompositeOperation='destination-in';const g=tx.createRadialGradient(S.cd/2,S.cd/2,r*Math.min(.98,brush.hard),S.cd/2,S.cd/2,r);g.addColorStop(0,'rgba(0,0,0,1)');g.addColorStop(1,'rgba(0,0,0,0)');tx.fillStyle=g;tx.fillRect(0,0,S.cd,S.cd);
    x.save();x.globalAlpha=Math.min(1,brush.str/100*.9+.05);x.drawImage(tm,cx-S.cd/2,cy-S.cd/2);x.restore();relTmp(tm);
    const nw=tmpC(S.cd,S.cd),nx=nw.getContext('2d');nx.drawImage(c,cx-S.cd/2,cy-S.cd/2,S.cd,S.cd,0,0,S.cd,S.cd);nx.globalAlpha=Math.min(.95,brush.str/100);nx.drawImage(cv,0,0);const old=S.carry;S.carry=nw;relTmp(old);return}
  if(t==='liquify'){lqDab(S,cx,cy,r,dx,dy,x0,y0,w,h);return}}
function lqDab(S,cx,cy,r,dx,dy,x0,y0,w,h,mode){mode=mode||brush.lqmode;const x=S.x,src=x.getImageData(x0,y0,w,h),out=x.createImageData(w,h),sd=src.data,od=out.data,str=brush.str/100;
  const samp=(fx,fy,o)=>{fx=Math.max(0,Math.min(w-1.001,fx));fy=Math.max(0,Math.min(h-1.001,fy));const ix=fx|0,iy=fy|0,ax=fx-ix,ay=fy-iy,i00=(iy*w+ix)*4,i10=i00+4,i01=i00+w*4,i11=i01+4;for(let j=0;j<4;j++)od[o+j]=(sd[i00+j]*(1-ax)+sd[i10+j]*ax)*(1-ay)+(sd[i01+j]*(1-ax)+sd[i11+j]*ax)*ay};
  for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++){const px=x0+xx,py=y0+yy,ddx=px-cx,ddy=py-cy,d=Math.hypot(ddx,ddy),o=(yy*w+xx)*4;
    if(d>=r){od[o]=sd[o];od[o+1]=sd[o+1];od[o+2]=sd[o+2];od[o+3]=sd[o+3];continue}
    const u=d/r,wt=Math.pow(1-u*u,2)*str;let sx=xx,sy=yy;
    if(mode==='push'){sx=xx-dx*wt*r*.5;sy=yy-dy*wt*r*.5}
    else if(mode==='bloat'){sx=xx-ddx*wt*.18;sy=yy-ddy*wt*.18}
    else if(mode==='pucker'){sx=xx+ddx*wt*.18;sy=yy+ddy*wt*.18}
    else if(mode==='twirl'){const a=wt*.22,ca=Math.cos(a),sa=Math.sin(a);sx=cx-x0+ddx*ca-ddy*sa;sy=cy-y0+ddx*sa+ddy*ca}
    samp(sx,sy,o)}
  x.putImageData(out,x0,y0)}
function ptUp(d){const S=ST;ST=null;clearInterval(lqTimer);if(!S)return;const l=byId(S.id);if(!l)return;
  const t=S.tool,c=S.c;
  if(t==='heal'&&S.bb.x1>S.bb.x0){healFinish(S,l)}
  if(t==='spot'){spotFinish(S,l);return}
  l.pw=c.width;l.ph=c.height;const key=keyId();store.set(key,c.toDataURL('image/png'));l.src=key;delete l._fresh;
  commit(true,({brush:'Nét cọ',eraser:'Tẩy',clone:'Clone Stamp',heal:'Healing Brush',dodge:'Dodge',burn:'Burn',sponge:'Sponge',blur:'Blur',sharpen:'Sharpen',smudge:'Smudge',liquify:'Liquify'})[t]||'Nét vẽ')}
function healFinish(S,l){ // giữ kết cấu từ nguồn, lấy màu/sáng từ vùng đích
  const c=S.c,W=c.width,H=c.height,r=Math.max(2,brush.size/2*S.k),pad=Math.ceil(r*.8+6);
  const x0=Math.max(0,Math.floor(S.bb.x0-pad)),y0=Math.max(0,Math.floor(S.bb.y0-pad)),x1=Math.min(W,Math.ceil(S.bb.x1+pad)),y1=Math.min(H,Math.ceil(S.bb.y1+pad)),w=x1-x0,h=y1-y0;if(w<2||h<2)return;
  const sbd=S.sx.getImageData(x0,y0,w,h),bsd=S.base.getContext('2d').getImageData(x0,y0,w,h);
  const blurOf=(cv)=>{const t=tmpC(w,h),tx=t.getContext('2d');tx.filter=`blur(${Math.max(2,r*.5)}px)`;tx.drawImage(cv,0,0);tx.filter='none';const d=tx.getImageData(0,0,w,h);relTmp(t);return d};
  // T = nguồn tịnh tiến
  const tc=tmpC(w,h),tx=tc.getContext('2d');const l0=toPx(l,{x:0,y:0},c),l1=toPx(l,{x:cloneOff.x,y:cloneOff.y},c);const ox=l1.x-l0.x,oy=l1.y-l0.y;tx.drawImage(S.src,x0+ox,y0+oy,w,h,0,0,w,h);
  const Td=tx.getImageData(0,0,w,h),Ls=blurOf(tc);relTmp(tc);
  const bc=tmpC(w,h);bc.getContext('2d').putImageData(bsd,0,0);const Ld=blurOf(bc);relTmp(bc);
  const out=S.base.getContext('2d').getImageData(0,0,W,H),od=out.data;
  for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++){const i=(yy*w+xx)*4,m=sbd.data[i+3]/255*brush.opacity;if(m<=0)continue;const o=((y0+yy)*W+x0+xx)*4;
    for(let j=0;j<3;j++){const v=Td.data[i+j]+(Ld.data[i+j]-Ls.data[i+j]);const nv=Math.max(0,Math.min(255,v));od[o+j]=od[o+j]+(nv-od[o+j])*m}
    od[o+3]=Math.max(od[o+3],Td.data[i+3]*m)}
  const x=S.x;x.save();x.setTransform(1,0,0,1,0,0);x.globalCompositeOperation='copy';x.putImageData(out,0,0);x.restore();S.healed=true}
function spotFinish(S,l){const W=doc.w,H=doc.h,id=S.dx.getImageData(0,0,W,H).data,m=new Uint8Array(W*H);let any=false;for(let i=0;i<W*H;i++)if(id[i*4+3]>100){m[i]=255;any=true}
  if(!any){refresh();return}
  const keep=msk;setMask(m);contentAware();setTimeout(()=>{keep?setMask(keep):mskClear();refresh(false)},400)}

/* ---- cursor ring + clone source marker ---- */
const bcur=document.createElement('div');bcur.id='bcur';bcur.hidden=true;board.appendChild(bcur);
const bsrc=document.createElement('div');bsrc.id='bsrc';bsrc.hidden=true;board.appendChild(bsrc);
function updCur(e){if(!PIXTOOLS.includes(tool)||!e){bcur.hidden=bsrc.hidden=true;return}
  const p=docPt(e),s=brush.size*zoom;bcur.hidden=false;bcur.style.cssText=`left:${p.x*zoom}px;top:${p.y*zoom}px;width:${s}px;height:${s}px;${brush.hard<.98?'border-style:dashed':''}`;
  if((tool==='clone'||tool==='heal')&&cloneSrc){bsrc.hidden=false;const o=cloneOff||{x:cloneSrc.x-p.x,y:cloneSrc.y-p.y};const sx=cloneOff?p.x+cloneOff.x:cloneSrc.x,sy=cloneOff?p.y+cloneOff.y:cloneSrc.y;bsrc.style.left=sx*zoom+'px';bsrc.style.top=sy*zoom+'px'}else bsrc.hidden=true}
board.addEventListener('pointermove',updCur);board.addEventListener('pointerleave',()=>{bcur.hidden=bsrc.hidden=true});

/* ---- options UI ---- */
const PTSPEC={
 brush:['size','hard','opacity','flow','spacing','smooth','tip','press'],eraser:['size','hard','opacity','flow','spacing'],
 clone:['size','hard','opacity','flow','sample'],heal:['size','hard','opacity','sample'],spot:['size'],
 dodge:['size','hard','str','range'],burn:['size','hard','str','range'],sponge:['size','hard','str','spmode'],
 blur:['size','hard','str'],sharpen:['size','hard','str'],smudge:['size','hard','str'],liquify:['size','str','lqmode']};
const PTSL={size:['Kích thước','size',2,400,1,1,'px'],hard:['Độ cứng','hard',0,100,1,100,'%'],opacity:['Opacity','opacity',1,100,1,100,'%'],flow:['Flow','flow',1,100,1,100,'%'],spacing:['Spacing','spacing',1,100,1,100,'%'],smooth:['Làm mượt','smooth',0,100,1,1,'%'],str:['Cường độ','str',1,100,1,1,'%']};
const PTCH={range:['range',[['sh','Bóng'],['mid','Trung gian'],['hi','Sáng']]],spmode:['spmode',[['desat','Giảm bão hòa'],['sat','Tăng bão hòa']]],lqmode:['lqmode',[['push','Đẩy'],['bloat','Phồng'],['pucker','Co'],['twirl','Xoáy']]],sample:['sample',[['cur','Layer này'],['all','Mọi layer']]]};
function ptCtl(k,compact){
  if(PTSL[k]){const s=PTSL[k],v=Math.round(brush[s[1]]*s[5]);return `<div class="rng"><span>${s[0]}</span><input type="range" data-o="pt" data-p="${s[1]}" data-sc="${s[5]}" min="${s[2]}" max="${s[3]}" step="${s[4]}" value="${v}"><output>${v}${s[6]}</output></div>`}
  if(PTCH[k]){const[key,opts]=PTCH[k];return `<span class="chips">${opts.map(o=>`<button class="chip ${brush[key]===o[0]?'on':''}" data-o="ptch" data-p="${key}" data-v="${o[0]}">${o[1]}</button>`).join('')}</span>`}
  if(k==='tip')return `<select data-o="pttip" aria-label="Đầu cọ">${TIPS.map(t=>`<option value="${t[0]}" ${brush.tip===t[0]?'selected':''}>${t[1]}</option>`).join('')}</select>`;
  if(k==='press')return `<label class="row" style="gap:5px;margin:0"><input type="checkbox" data-o="ptpress" ${brush.press?'checked':''}> Cảm biến lực bút</label>`;
  return ''}
function paintOpts(){const sp=PTSPEC[tool]||[];const compact=['size','hard','opacity','flow','str','range','spmode','lqmode','sample'].filter(k=>sp.includes(k));
  let h=compact.map(k=>ptCtl(k,true)).join('');
  if(tool==='brush'||tool==='eraser')h+=(tool==='brush'?`<span class="sw" style="background:${brush.color}" title="Màu cọ = màu trước"></span>`:'');
  if(tool==='clone'||tool==='heal')h+=`<span class="ohint">${cloneSrc?'Alt+bấm để đổi điểm nguồn.':'Alt+bấm để chọn điểm nguồn.'}</span>`;
  if(tool==='spot')h+='<span class="ohint">Tô lên vết, bụi, vật thể nhỏ. Antifact tự lấp bằng nền xung quanh (đặt trên layer mới).</span>';
  if(tool==='liquify')h+='<span class="ohint">Kéo để đẩy / giữ chuột để phồng, co, xoáy.</span>';
  return h}
function paintProps(){const sp=PTSPEC[tool]||[];const t=TOOLS.find(x=>x[0]===tool);
  let h=`<div class="sec"><h4>${t?t[2].replace(/ \(.*\)$/,''):'Cọ'}</h4>`;
  if(tool==='brush'||tool==='eraser'){h+=`<div class="chips" style="margin-bottom:6px">${[...BRUSH_PRESETS,...userBrushes].map((b,i)=>`<button class="chip" data-o="ptpre" data-i="${i}">${esc(b.n)}</button>`).join('')}</div>`}
  h+=sp.map(k=>ptCtl(k)).join('');
  if(tool==='brush'){h+=`<div class="row" style="margin-top:8px"><label>Màu cọ <input type="color" id="bcol" value="${brush.color}"></label><button class="btn" data-o="ptsave" style="margin-left:auto">Lưu preset</button></div>`}
  const hints={clone:'Giữ Alt và bấm để lấy điểm nguồn, rồi tô lên chỗ cần chép. Chế độ "Mọi layer" cho phép vẽ lên layer trống mà vẫn lấy mẫu từ ảnh.',heal:'Giống Clone Stamp nhưng tự khớp màu và độ sáng với vùng đích, nên mép vá hòa vào ảnh.',spot:'Tô lên vết, bụi, dây điện... Kết quả nằm trên layer mới, xóa được nếu chưa ưng.',dodge:'Làm sáng vùng bạn tô. Chọn dải Bóng / Trung gian / Sáng để tác động đúng chỗ.',burn:'Làm tối vùng bạn tô.',sponge:'Tăng hoặc giảm độ bão hòa cục bộ.',blur:'Làm mờ cục bộ.',sharpen:'Làm nét cục bộ.',smudge:'Vuốt màu như quệt sơn ướt.',liquify:'Đẩy / phồng / co / xoáy điểm ảnh. Giữ chuột đứng yên để phồng, co, xoáy liên tục.',brush:'Phím [ ] đổi cỡ cọ, Shift+[ ] đổi độ cứng. Khi đang chọn mask, cọ trắng = hiện, cọ đen = ẩn.',eraser:'Tẩy theo đầu cọ hiện tại. Khi đang chọn mask, tẩy làm ngược lại cọ.'};
  h+=`<div class="empty" style="margin-top:8px">${hints[tool]||''}</div></div>`;return h}
function ptOpt(t){const o=t.dataset.o;
  if(o==='pt'){const k=t.dataset.p,sc=+t.dataset.sc||1;brush[k]=parseFloat(t.value)/sc;if(t.nextElementSibling)t.nextElementSibling.textContent=t.value+(PTSL[k]?PTSL[k][6]:'');document.querySelectorAll(`[data-o="pt"][data-p="${k}"]`).forEach(i=>{if(i!==t){i.value=t.value;if(i.nextElementSibling)i.nextElementSibling.textContent=t.value+(PTSL[k]?PTSL[k][6]:'')}});saveBrush();return true}
  if(o==='pttip'){brush.tip=t.value;saveBrush();return true}
  if(o==='ptpress'){brush.press=t.checked;saveBrush();return true}
  return false}
function ptBtn(b){const o=b.dataset.o;
  if(o==='ptch'){brush[b.dataset.p]=b.dataset.v;saveBrush();buildProps();return true}
  if(o==='ptpre'){const a=[...BRUSH_PRESETS,...userBrushes][+b.dataset.i];if(a){const{n,...r}=a;Object.assign(brush,r);saveBrush();buildProps()}return true}
  if(o==='ptsave'){const n=prompt?null:null;const m=modal(`<h2>Lưu preset cọ</h2><label class="fld" style="margin-bottom:14px"><span style="width:auto">Tên</span><input type="text" id="pbn" value="Cọ của tôi"></label><div class="row" style="justify-content:flex-end;margin:0"><button class="btn" id="pbx">Hủy</button><button class="btn pri" id="pbo">Lưu</button></div>`);
    m.querySelector('#pbx').onclick=()=>m.remove();m.querySelector('#pbo').onclick=()=>{const{color,...r}=brush;userBrushes.push({n:m.querySelector('#pbn').value||'Cọ',size:r.size,hard:r.hard,opacity:r.opacity,flow:r.flow,spacing:r.spacing,tip:r.tip,smooth:r.smooth});try{localStorage.setItem('af-brushes',JSON.stringify(userBrushes))}catch(e){}m.remove();buildProps();toast('Đã lưu preset')};return true}
  return false}

/* ---- tool rail with flyout groups ---- */
const TGROUPS=[['select'],['marq','lasso','qsel','wand'],['crop','razor'],['eyedrop'],['spot','heal','clone'],['brush','eraser'],['dodge','burn','sponge'],['blur','sharpen','smudge'],['liquify'],['rect','ellipse'],['text'],['grad'],['hand'],['zoom']];
var gcur=TGROUPS.map(g=>g[0]);
const toolDef=id=>TOOLS.find(t=>t[0]===id);
function railBtn(gi){const g=TGROUPS[gi],t=toolDef(gcur[gi]);return `<button class="tool${g.length>1?' grp':''}" data-tool="${t[0]}" data-g="${gi}" title="${t[2]}${g.length>1?' · giữ chuột hoặc chuột phải để chọn công cụ cùng nhóm':''}" aria-label="${t[2]}">${ic(t[1])}</button>`}
function renderRail(){const r=$('#rail');r.querySelectorAll('.tool[data-tool]').forEach(b=>b.remove());const hr=r.querySelector('hr');
  hr.insertAdjacentHTML('beforebegin',TGROUPS.map((g,i)=>railBtn(i)).join(''));}
function railSync(t){const gi=TGROUPS.findIndex(g=>g.includes(t));if(gi<0)return;if(gcur[gi]!==t){gcur[gi]=t;const b=$('#rail .tool[data-g="'+gi+'"]');if(b){const td=toolDef(t);b.dataset.tool=t;b.title=td[2];b.innerHTML=ic(td[1])}}}
function closeFly(){const f=$('#flyout');if(f)f.remove()}
function openFly(b){closeFly();const gi=+b.dataset.g,g=TGROUPS[gi];if(g.length<2)return;const r=b.getBoundingClientRect(),f=document.createElement('div');f.id='flyout';f.className='mpop';f.style.cssText=`left:${r.right+4}px;top:${r.top}px;position:fixed`;
  f.innerHTML=g.map(id=>{const t=toolDef(id);return `<button class="mi" data-t="${id}">${ic(t[1])}<span>${t[2].replace(/ \(.*\)$/,'')}</span><kbd>${t[3]||''}</kbd></button>`}).join('');
  f.addEventListener('click',e=>{const x=e.target.closest('.mi');if(x){setTool(x.dataset.t);closeFly()}});document.body.appendChild(f);
  setTimeout(()=>document.addEventListener('pointerdown',function h(e){if(!f.contains(e.target)){closeFly();document.removeEventListener('pointerdown',h)}}),0)}
var flyT=0;
$('#rail').addEventListener('contextmenu',e=>{const b=e.target.closest('.tool.grp');if(b){e.preventDefault();openFly(b)}});
$('#rail').addEventListener('pointerdown',e=>{const b=e.target.closest('.tool.grp');if(!b||e.button!==0)return;flyT=setTimeout(()=>{flyT=0;b._held=true;openFly(b)},420)});
$('#rail').addEventListener('pointerup',()=>{clearTimeout(flyT)});
$('#rail').addEventListener('click',e=>{const b=e.target.closest('.tool.grp');if(b&&b._held){b._held=false;e.stopImmediatePropagation()}},true);
renderRail();

/* ================= Google Fonts library ================= */
const GF={
 sans:'Roboto|Open Sans|Montserrat|Inter|Poppins|Lato|Nunito|Nunito Sans|Raleway|Work Sans|DM Sans|Manrope|Be Vietnam Pro|Lexend|Rubik|Barlow|Barlow Condensed|Mulish|Quicksand|Karla|Josefin Sans|Fira Sans|Source Sans 3|Noto Sans|PT Sans|Ubuntu|Cabin|Heebo|Archivo|Public Sans|Outfit|Plus Jakarta Sans|Sora|Urbanist|Figtree|Albert Sans|Red Hat Display|Space Grotesk|Bricolage Grotesque|IBM Plex Sans|Oxygen|Titillium Web|Hind|Assistant|Kanit|Prompt|Sarabun|Mukta|Exo 2|Signika|Maven Pro|Varela Round|Comfortaa|Asap|Catamaran|Overpass|Questrial|Jost|Syne|Epilogue|Onest|Instrument Sans|Schibsted Grotesk|Hanken Grotesk|Golos Text|Readex Pro|Roboto Condensed|Open Sans Condensed|Saira|Chivo|Lexend Deca|Red Hat Text|Rethink Sans|Gabarito|Afacad|Geologica|Inclusive Sans|Noto Sans Display',
 serif:'Playfair Display|Merriweather|Lora|PT Serif|Noto Serif|Source Serif 4|Libre Baskerville|Cormorant Garamond|Cormorant|EB Garamond|Crimson Text|Bitter|Roboto Slab|Zilla Slab|Arvo|Domine|Spectral|Cardo|Frank Ruhl Libre|DM Serif Display|DM Serif Text|Abril Fatface|Fraunces|Newsreader|Gelasio|Vollkorn|Alegreya|Libre Caslon Text|Old Standard TT|Bodoni Moda|Rufina|Prata|Yeseva One|Cinzel|Marcellus|Young Serif|Instrument Serif|Playfair Display SC|Noto Serif Display|Literata|Besley|Brygada 1918|Lustria|Gloock|Rozha One|Rokkitt',
 display:'Anton|Bebas Neue|Oswald|Lobster|Righteous|Bangers|Fredoka|Baloo 2|Archivo Black|Black Ops One|Russo One|Staatliches|Alfa Slab One|Chango|Passion One|Luckiest Guy|Permanent Marker|Press Start 2P|Orbitron|Audiowide|Monoton|Shrikhand|Paytone One|Titan One|Bowlby One|Rubik Mono One|Big Shoulders Display|League Gothic|Fjalla One|Teko|Rammetto One|Unbounded|Bungee|Faster One|Creepster|Special Elite|Limelight|Poiret One|Josefin Slab|Dela Gothic One|Modak|Bigshot One|Caprasimo|Climate Crisis|Rubik Glitch|Squada One|Michroma|Syncopate|Tilt Warp|Sigmar One|Lilita One|Concert One|Chelsea Market|Fascinate|Gasoek One|Bagel Fat One|Rubik Bubbles',
 hand:'Pacifico|Dancing Script|Caveat|Satisfy|Great Vibes|Sacramento|Kaushan Script|Indie Flower|Shadows Into Light|Amatic SC|Patrick Hand|Gloria Hallelujah|Courgette|Cookie|Yellowtail|Allura|Alex Brush|Parisienne|Marck Script|Nanum Pen Script|Reenie Beanie|Covered By Your Grace|Rock Salt|Homemade Apple|Handlee|Architects Daughter|Kalam|Mansalva|Gochi Hand|Neucha|Bad Script|Lobster Two|Oleo Script|Playwrite VN|Charm|Charmonman|Itim|Pangolin|Caveat Brush|Merienda|Sriracha|Mali|Gaegu|Hi Melody|Over the Rainbow|Just Another Hand|Vibur|Zeyada',
 mono:'JetBrains Mono|Fira Code|Source Code Pro|Roboto Mono|IBM Plex Mono|Space Mono|Inconsolata|Ubuntu Mono|DM Mono|Courier Prime|Cutive Mono|VT323|Share Tech Mono|Anonymous Pro|Overpass Mono|Red Hat Mono|Azeret Mono|Martian Mono|Geist Mono|Noto Sans Mono'};
const GFV=new Set('Roboto|Roboto Condensed|Roboto Slab|Roboto Mono|Open Sans|Montserrat|Inter|Nunito|Nunito Sans|Be Vietnam Pro|Lexend|Lexend Deca|Barlow|Barlow Condensed|Quicksand|Josefin Sans|Source Sans 3|Source Serif 4|Noto Sans|Noto Serif|Archivo|Oswald|Raleway|Comfortaa|Playfair Display|Merriweather|Lora|Bricolage Grotesque|Dancing Script|Pacifico|Lobster|Anton|Fira Sans|JetBrains Mono|Cormorant Garamond|Cormorant|EB Garamond|Bitter|Spectral|Alegreya|Fraunces|Mulish|DM Sans|Work Sans|Plus Jakarta Sans|Baloo 2|Kanit|Prompt|Sarabun|Signika|Maven Pro|Varela Round|Be Vietnam|Playwrite VN|Charmonman|Itim|Mali|Sriracha|Pangolin|Literata|Newsreader|Gelasio|Vollkorn|Libre Caslon Text|Merienda|Saira|Chivo|Readex Pro|Lobster Two|Bad Script|Be Vietnam Pro'.split('|'));
const GFC=[];Object.entries(GF).forEach(([c,s])=>s.split('|').forEach(n=>GFC.push({n,c,v:GFV.has(n)})));
const GFNAMES=new Set(GFC.map(f=>f.n));
const BASEF=new Set(['Bricolage Grotesque','Outfit','Be Vietnam Pro','Anton','Playfair Display','Pacifico','Lobster','JetBrains Mono']);
const gfSet=new Set();
const gfUrl=(n,full)=>'https://fonts.googleapis.com/css2?family='+encodeURIComponent(n).replace(/%20/g,'+')+(full?':wght@400;700':'')+'&display=swap';
function gfLoad(n,full,cb){const id=n+(full?'|f':'');if(gfSet.has(id))return;gfSet.add(id);
  const l=document.createElement('link');l.rel='stylesheet';l.href=gfUrl(n,full);
  l.onload=()=>{if(cb)cb()};l.onerror=()=>{if(full){const m=document.createElement('link');m.rel='stylesheet';m.href=gfUrl(n,false);m.onload=()=>{if(cb)cb()};document.head.appendChild(m)}};
  document.head.appendChild(l)}
function gfEnsure(n){if(!n||BASEF.has(n)||customFonts[n]||!GFNAMES.has(n)||gfSet.has(n+'|f'))return;
  gfLoad(n,true,()=>{document.fonts.load('700 20px "'+n+'"').then(()=>{document.fonts.load('400 20px "'+n+'"').then(()=>{render();renderLayers()})})})}
var fontRecent=[];try{fontRecent=JSON.parse(localStorage.getItem('af-fontrecent')||'[]')}catch(e){}
function useFont(n){const l=cur();gfEnsure(n);if(!FONTS.includes(n))FONTS.push(n);fontRecent=[n,...fontRecent.filter(x=>x!==n)].slice(0,8);try{localStorage.setItem('af-fontrecent',JSON.stringify(fontRecent))}catch(e){}
  if(l&&l.type==='text'){l.font=n;document.fonts.load(`${l.weight} 40px "${n}"`).then(render);commit(true,'Đổi font')}else{toast('Chọn một layer chữ rồi chọn lại font.')}}
const fontBtn=l=>`<button class="btn fontbtn" data-act="fontpick" title="Chọn font (thư viện Google Fonts miễn phí)" style="font-family:'${esc(l.font)}',sans-serif">${esc(l.font)}</button>`;
function fontPicker(){const l=cur();if(!l||l.type!=='text'){toast('Chọn một layer chữ để đổi font.');return}
  let q='',cat='all';const cats=[['all','Tất cả'],['recent','Gần đây'],['sans','Không chân'],['serif','Có chân'],['display','Tiêu đề'],['hand','Viết tay'],['mono','Đơn cách'],['vi','Tiếng Việt'],['mine','Đã nhập']];
  const m=modal(`<h2>Chọn font</h2><p style="margin-bottom:10px">Hơn ${GFC.length} font miễn phí từ Google Fonts, tải khi cần. Cần có mạng. Tiếng Việt: các font đánh dấu <b>VI</b> hiển thị đủ dấu.</p>
   <input type="search" id="fq" placeholder="Tìm font…" style="width:100%;margin-bottom:8px"><div class="chips" id="fc" style="margin-bottom:8px">${cats.map(c=>`<button class="chip ${c[0]==='all'?'on':''}" data-c="${c[0]}">${c[1]}</button>`).join('')}</div>
   <input type="text" id="fs" value="Thiết kế đẹp · Antifact 2026" style="width:100%;margin-bottom:8px" aria-label="Chữ xem trước"><div id="fl" class="flist"></div>
   <div class="row" style="justify-content:space-between;margin:12px 0 0"><button class="btn" id="fimp">${ic('plus')} Nhập font từ máy</button><button class="btn" id="fx">Đóng</button></div>`);
  m.querySelector('.card').style.cssText+=';width:min(560px,94vw)';
  const list=m.querySelector('#fl'),sample=()=>m.querySelector('#fs').value||'Aa';
  const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){const n=e.target.dataset.f;io.unobserve(e.target);if(GFNAMES.has(n)&&!BASEF.has(n)&&!customFonts[n])gfLoad(n,false,()=>{})}}),{root:list,rootMargin:'200px'});
  function draw(){list.innerHTML='';let items;
    if(cat==='recent')items=fontRecent.map(n=>({n,c:'',v:GFV.has(n)}));else if(cat==='mine')items=Object.keys(customFonts).map(n=>({n,c:'',v:false}));
    else items=GFC.filter(f=>(cat==='all'||cat==='vi'?true:f.c===cat)&&(cat!=='vi'||f.v));
    if(cat==='all'){const sys=[...BASEF,...Object.keys(customFonts)].filter(n=>!GFNAMES.has(n)||BASEF.has(n)||customFonts[n]);}
    if(q)items=items.filter(f=>f.n.toLowerCase().includes(q));
    if(!items.length){list.innerHTML='<div class="empty" style="padding:14px">Không có font phù hợp.</div>';return}
    items.slice(0,400).forEach(f=>{const d=document.createElement('button');d.className='fr'+(f.n===l.font?' on':'');d.dataset.f=f.n;d.innerHTML=`<span class="fn">${esc(f.n)}${f.v?'<i>VI</i>':''}</span><span class="fp" style="font-family:'${esc(f.n)}',sans-serif">${esc(sample())}</span>`;list.appendChild(d);io.observe(d)})}
  draw();
  m.querySelector('#fq').addEventListener('input',e=>{q=e.target.value.trim().toLowerCase();draw()});
  m.querySelector('#fs').addEventListener('input',()=>list.querySelectorAll('.fp').forEach(p=>p.textContent=sample()));
  m.querySelector('#fc').addEventListener('click',e=>{const b=e.target.closest('.chip');if(!b)return;cat=b.dataset.c;m.querySelectorAll('#fc .chip').forEach(c=>c.classList.toggle('on',c===b));draw()});
  list.addEventListener('click',e=>{const b=e.target.closest('.fr');if(!b)return;useFont(b.dataset.f);m.remove()});
  m.querySelector('#fimp').onclick=()=>{m.remove();$('#fileFont').click()};m.querySelector('#fx').onclick=()=>m.remove();
  setTimeout(()=>m.querySelector('#fq').focus(),30)}

/* ================= Slides mode + 2D / 2.5D / 3D camera ================= */
var deck=null,camKf='start',camOpen=false,camScene=null,slThT=0;
const CAMD={x:0,y:0,z:0,yaw:0,pitch:0,roll:0,zoom:1,persp:1400};
const CAMR={x:[-1200,1200,1,'px'],y:[-800,800,1,'px'],z:[-2500,1000,5,'px'],yaw:[-180,180,1,'°'],pitch:[-90,90,1,'°'],roll:[-180,180,1,'°'],zoom:[.3,3,.01,'×'],persp:[400,4000,10,'px']};
const CAML={x:'Dịch ngang',y:'Dịch dọc',z:'Tiến / lùi (dolly)',yaw:'Xoay ngang (yaw)',pitch:'Xoay dọc (pitch)',roll:'Nghiêng (roll)',zoom:'Thu phóng',persp:'Phối cảnh'};
const CAMK={'2d':['x','y','zoom'],'2.5d':['x','y','zoom','yaw','pitch','persp'],'3d':['x','y','z','zoom','yaw','pitch','roll','persp']};
const CAMLIM={'2.5d':{yaw:[-15,15],pitch:[-15,15]}};
const CAMP={'2d':[['Ken Burns vào',{zoom:1},{zoom:1.12}],['Ken Burns ra',{zoom:1.15},{zoom:1}],['Lia trái → phải',{x:-60,zoom:1.1},{x:60,zoom:1.1}]],
 '2.5d':[['Parallax →',{x:-80,yaw:-5},{x:80,yaw:5}],['Parallax ←',{x:80,yaw:5},{x:-80,yaw:-5}],['Đẩy vào',{zoom:1},{zoom:1.18,yaw:2}],['Kéo ra',{zoom:1.2},{zoom:1}],['Nghiêng xuống',{pitch:-7},{pitch:7}],['Trôi nhẹ',{x:-30,y:-20,yaw:-2,pitch:2},{x:30,y:20,yaw:2,pitch:-2}]],
 '3d':[['Orbit',{yaw:-38,pitch:8},{yaw:38,pitch:-4}],['Lật vào',{yaw:90,zoom:.8},{yaw:0,zoom:1}],['Bay xuyên',{z:-500,yaw:-15},{z:250,yaw:10}],['Nhìn từ trên',{pitch:55,zoom:.9},{pitch:0,zoom:1}],['Xoắn',{roll:-12,yaw:-20,zoom:.85},{roll:0,yaw:10,zoom:1}],['Lia ngang',{x:-300,yaw:-30},{x:300,yaw:30}]]};
const TRANS=[['none','Cắt thẳng'],['fade','Mờ dần'],['slide','Trượt'],['zoom','Phóng'],['flip','Lật 3D']];
const EASES=[['inout','Mượt'],['lin','Đều'],['in','Chậm → nhanh'],['out','Nhanh → chậm']];
const ease=(k,t)=>k==='lin'?t:k==='in'?t*t:k==='out'?1-(1-t)*(1-t):t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;
const lerpCam=(a,b,t)=>{const o={};for(const k in CAMD)o[k]=(a[k]??CAMD[k])+((b[k]??CAMD[k])-(a[k]??CAMD[k]))*t;return o};
const allLayers=()=>deck?deck.slides.flatMap(s=>s.layers):layers;
function newSlide(lay,bg,n){return{id:uid(),name:'Slide '+n,layers:lay,bg,dur:5,cam:{mode:'2d',ease:'inout',start:{...CAMD},end:{...CAMD}},trans:{type:'fade',dur:.6},notes:''}}
function deckInit(){deck={cur:0,slides:[newSlide(layers,doc.bg,1)]}}
function syncCur(){if(!deck)return;const s=deck.slides[deck.cur];s.layers=layers;s.bg=doc.bg}
function withSlide(s,fn){const L=layers,B=doc.bg;layers=s.layers;doc.bg=s.bg;try{return fn()}finally{layers=L;doc.bg=B}}
function gotoSlide(i,noHist){if(!deck||i<0||i>=deck.slides.length)return;syncCur();deck.cur=i;const s=deck.slides[i];layers=s.layers;doc.bg=s.bg;sel=null;msel=new Set();maskTarget=null;mskClear();
  if(!noHist)pushHist('Chuyển slide');refresh();stripSync(true)}
function addSlide(dup){if(!deck){convertToDeck();return}syncCur();let lay=[],bg=doc.bg;
  if(dup){const src=deck.slides[deck.cur],idm={};lay=src.layers.map(l=>{const n=cloneNode(l,l.parent);idm[l.id]=n.id;return n});lay.forEach(n=>{if(n.parent)n.parent=idm[n.parent]||null});bg=src.bg}
  const s=newSlide(lay,bg,deck.slides.length+1);if(dup){const c=deck.slides[deck.cur];s.cam=JSON.parse(JSON.stringify(c.cam));s.trans={...c.trans};s.dur=c.dur;s.name=c.name+' (bản sao)'}
  deck.slides.splice(deck.cur+1,0,s);gotoSlide(deck.cur+1)}
function delSlide(i){if(!deck)return;if(deck.slides.length<2){toast('Cần giữ ít nhất 1 slide.');return}syncCur();deck.slides.splice(i,1);deck.cur=Math.min(deck.cur>i?deck.cur-1:deck.cur,deck.slides.length-1);const s=deck.slides[deck.cur];layers=s.layers;doc.bg=s.bg;sel=null;pushHist('Xóa slide');refresh();stripSync(true)}
function moveSlide(a,b){if(!deck||a===b)return;syncCur();const cur=deck.slides[deck.cur];const[m]=deck.slides.splice(a,1);deck.slides.splice(b,0,m);deck.cur=deck.slides.indexOf(cur);pushHist('Đổi thứ tự slide');stripSync(true)}
function convertToDeck(){if(deck)return;deckInit();pushHist('Chuyển sang bản trình bày');stripSync(true);refresh();toast('Đã chuyển sang chế độ Slide. Dùng dải slide bên dưới để thêm slide.')}
function exitDeck(){if(!deck)return;if(deck.slides.length>1&&!window.__exd){toast('Còn '+deck.slides.length+' slide. Xóa bớt hoặc gộp trước khi thoát (dùng Xuất ảnh từng slide).');return}deck=null;pushHist('Thoát chế độ Slide');stripSync(true)}

/* ---- history / save hooks live in patched snap/loadSnap/projectJson ---- */

/* ---- thumbnails + strip ---- */
function slideThumb(s){const c=document.createElement('canvas');c.width=192;c.height=Math.max(60,Math.round(192*doc.h/doc.w));const x=c.getContext('2d');
  try{const f=withSlide(s,()=>flatten(false));if(!s.bg){x.fillStyle='#20212b';x.fillRect(0,0,c.width,c.height)}x.drawImage(f,0,0,c.width,c.height)}catch(e){}return c}
var stripSig='';
function stripSync(force){syncSlideBtn();const el=$('#strip');if(!el)return;if(!deck){el.hidden=true;stripSig='';return}el.hidden=false;
  const sig=deck.slides.map(s=>s.id+s.name).join('|')+deck.cur;
  if(force||sig!==stripSig){stripSig=sig;stripRender()}
  clearTimeout(slThT);slThT=setTimeout(()=>{const s=deck.slides[deck.cur];s._th=slideThumb(s);const cv=el.querySelector('.sl.on canvas');if(cv){cv.getContext('2d').clearRect(0,0,cv.width,cv.height);cv.getContext('2d').drawImage(s._th,0,0,cv.width,cv.height)}},350)}
function stripRender(){const el=$('#strip');const th=el.querySelector('.sthumbs');
  th.innerHTML=deck.slides.map((s,i)=>`<div class="sl${i===deck.cur?' on':''}" data-i="${i}" draggable="true" title="${esc(s.name)}"><canvas width="192" height="${Math.max(60,Math.round(192*doc.h/doc.w))}"></canvas><b>${i+1}</b><span class="cm">${s.cam.mode==='2d'?'2D':s.cam.mode==='2.5d'?'2.5D':'3D'}</span></div>`).join('')+`<button class="sladd" data-a="add" title="Thêm slide (Ctrl+M)">${ic('plus')}</button>`;
  th.querySelectorAll('.sl').forEach((d,i)=>{const s=deck.slides[i];if(!s._th)s._th=slideThumb(s);d.querySelector('canvas').getContext('2d').drawImage(s._th,0,0,192,d.querySelector('canvas').height)});
  const on=th.querySelector('.sl.on');if(on&&on.scrollIntoView)on.scrollIntoView({block:'nearest',inline:'nearest'})}
(function(){const el=document.createElement('div');el.id='strip';el.className='strip';el.hidden=true;
  el.innerHTML=`<div class="sthumbs"></div><div class="stools"><button class="btn" data-a="cam" title="Camera 2D / 2.5D / 3D và timeline chuyển động">${ic('layers')} Camera</button><button class="btn" data-a="ovw" title="Bảng tổng quan (kéo thả, dây nối)">${ic('marq')} Bảng</button><button class="btn" data-a="exp" title="Xuất video MP4, GIF, PNG">${ic('plus')} Xuất</button><button class="btn pri" data-a="play" title="Trình chiếu (F5)">${ic('send')} Chiếu</button></div>`;
  document.querySelector('.status').before(el);
  el.addEventListener('click',e=>{const sl=e.target.closest('.sl'),b=e.target.closest('button');
    if(sl&&!b){gotoSlide(+sl.dataset.i);return}
    if(!b)return;const a=b.dataset.a;if(a==='add')addSlide(false);else if(a==='cam')openCam();else if(a==='exp')exportDlg();else if(a==='ovw')overview();else if(a==='play')present(deck.cur)});
  el.addEventListener('contextmenu',e=>{const sl=e.target.closest('.sl');if(!sl)return;e.preventDefault();const i=+sl.dataset.i;showMenu([{t:'Nhân đôi slide',f:()=>{gotoSlide(i,true);addSlide(true)}},{t:'Xóa slide',f:()=>delSlide(i)},'-',{t:'Trình chiếu từ slide này',f:()=>present(i)}],e.clientX,e.clientY)});
  let di=null;el.addEventListener('dragstart',e=>{const sl=e.target.closest('.sl');if(sl){di=+sl.dataset.i;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain','s')}});
  el.addEventListener('dragover',e=>{if(di!==null)e.preventDefault()});
  el.addEventListener('drop',e=>{const sl=e.target.closest('.sl');e.preventDefault();if(di!==null&&sl)moveSlide(di,+sl.dataset.i);di=null})})();

/* ================= 3D scene ================= */
function bakeLeaf(l,o){const sib=kids(l.parent||null),idx=sib.indexOf(l),stack=[];for(let j=idx+1;j<sib.length&&sib[j].clipTo;j++)if(sib[j].visible)stack.push(sib[j]);
  const anc=ancestors(l),adj=o.bake===false?[]:adjustsFor(l),needFull=stack.length||adj.length||anc.some(maskOn);
  let x0,y0,x1,y1;if(needFull){x0=0;y0=0;x1=doc.w;y1=doc.h}else{const b=bounds(l);x0=Math.max(0,Math.floor(b.x0));y0=Math.max(0,Math.floor(b.y0));x1=Math.min(doc.w,Math.ceil(b.x1));y1=Math.min(doc.h,Math.ceil(b.y1))}
  const bw=x1-x0,bh=y1-y0;if(bw<1||bh<1)return null;
  const full=document.createElement('canvas');full.width=doc.w;full.height=doc.h;
  const was=l.visible;l.visible=true;stopId=null;stopped=false;composeInto(full,[l,...stack],true);l.visible=was;
  anc.forEach(a=>{if(maskOn(a))applyMask(full,a)});adj.forEach(a=>applyAdjustNode(full,a));
  const c=document.createElement('canvas');c.width=bw;c.height=bh;c.getContext('2d').drawImage(full,x0,y0,bw,bh,0,0,bw,bh);
  return{c,x0,y0,w:bw,h:bh,op:anc.reduce((p,a)=>p*(a.opacity==null?1:a.opacity),l.opacity),blend:l.blend,vis:effVis(l),anc}}
function autoDepth(s){const L=exportOrder_of(s).filter(l=>!l.clipTo);const n=L.length;if(!n)return;L.forEach((l,i)=>{l.depth=Math.round(-160+320*(n===1?.5:i/(n-1)))})}
function exportOrder_of(s){return withSlide(s,()=>exportOrder())}
function fitScene(sc,area){const f=Math.min(area.clientWidth/doc.w,area.clientHeight/doc.h);sc.wrap.style.transform=`translate(${(area.clientWidth-doc.w*f)/2}px,${(area.clientHeight-doc.h*f)/2}px) scale(${f})`;sc.f=f}
window.addEventListener('resize',()=>window.__camResize&&window.__camResize());
function syncCamSliders(){const s=deck&&deck.slides[deck.cur];if(!s)return;const c=curKf(s);document.querySelectorAll('#props [data-o="dkcam"]').forEach(i=>{const k=i.dataset.k,v=c[k]??CAMD[k];i.value=v;const o=i.nextElementSibling;if(o)o.textContent=(Math.round(v*100)/100)+CAMR[k][3]})}

/* ---- slide section in properties ---- */
function slideSec(){if(!deck)return '';const s=deck.slides[deck.cur],c=s.cam,m=c.mode,kf=curKf(s);
  const lim=k=>(CAMLIM[m]&&CAMLIM[m][k])||[CAMR[k][0],CAMR[k][1]];
  let h=`<div class="sec"><h4>Slide ${deck.cur+1} / ${deck.slides.length}</h4><div class="row" style="margin-top:0"><input type="text" data-o="dkname" value="${esc(s.name)}" aria-label="Tên slide" style="flex:1"><label class="fld" style="flex:none"><span style="width:auto">Thời lượng</span><input type="number" data-o="dkdur" value="${s.dur}" min="1" max="120" style="width:64px"> s</label></div>
   <div class="row"><label class="fld" style="flex:1"><span style="width:auto">Chuyển cảnh</span><select data-o="dktr">${TRANS.map(t=>`<option value="${t[0]}" ${s.trans.type===t[0]?'selected':''}>${t[1]}</option>`).join('')}</select></label><input type="number" data-o="dktd" value="${s.trans.dur}" step=".1" min=".1" max="3" style="width:60px" aria-label="Thời gian chuyển cảnh"> s</div></div>
   <div class="sec"><h4>Camera</h4><div class="chips" style="margin-bottom:8px">${[['2d','2D phẳng'],['2.5d','2.5D parallax'],['3d','3D']].map(x=>`<button class="chip ${m===x[0]?'on':''}" data-o="dkmode" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>
   <div class="empty" style="margin:0 0 8px">${m==='2d'?'Slide phẳng, camera chỉ dịch / thu phóng (Ken Burns).':m==='2.5d'?'Mỗi layer có độ sâu (Z). Camera trôi và nghiêng nhẹ tạo hiệu ứng parallax chiều sâu.':'Layer là các tấm phẳng trong không gian 3D. Camera xoay, tiến, lùi tự do.'}</div>
   <div class="chips" style="margin-bottom:8px">${(CAMP[m]||[]).map((p,i)=>`<button class="chip" data-o="dkpre" data-i="${i}">${p[0]}</button>`).join('')}</div>
   <div class="chips" style="margin-bottom:6px">${camKeys(s).map((k,n,A)=>`<button class="chip ${camKf===k.id?'on':''}" data-o="dkkf" data-v="${k.id}">${k.id==='start'?'Điểm đầu':k.id==='end'?'Điểm cuối':'Key '+n}</button>`).join('')}</div>`;
  CAMK[m].forEach(k=>{const[a,b]=lim(k),v=kf[k]??CAMD[k];h+=`<div class="rng"><span>${CAML[k]}</span><input type="range" data-o="dkcam" data-k="${k}" min="${a}" max="${b}" step="${CAMR[k][2]}" value="${v}"><output>${Math.round(v*100)/100}${CAMR[k][3]}</output></div>`});
  h+=`<div class="row"><label class="fld" style="flex:1"><span style="width:auto">Chuyển động</span><select data-o="dkease">${EASES.map(t=>`<option value="${t[0]}" ${c.ease===t[0]?'selected':''}>${t[1]}</option>`).join('')}</select></label></div>
   <div class="row"><button class="btn pri" data-o="dkprev">${camOpen?'Đóng Camera & Timeline':'Mở Camera & Timeline'}</button>${m!=='2d'?'<button class="btn" data-o="dkauto" title="Chia độ sâu Z đều theo thứ tự layer">Tự chia độ sâu</button>':''}</div>
   <div class="row"><button class="btn" data-o="dkplay">▶ Trình chiếu từ slide này</button></div>
   <textarea data-o="dknotes" placeholder="Ghi chú người trình bày…" style="margin-top:8px;min-height:54px">${esc(s.notes||'')}</textarea></div>`;return h}
function depthSec(l){if(!deck||isGroup(l)||isAdj(l))return '';const m=deck.slides[deck.cur].cam.mode;
  return `<div class="sec"><h4>Độ sâu 3D & chuyển động (Slide)</h4><div class="row" style="margin:0 0 6px"><button class="btn pri" data-o="dkmotion" data-id="${l.id}">Chuyển động & không gian…</button></div><div class="empty" style="margin:0 0 4px">${m==='2d'?'Slide đang ở 2D nên độ sâu chưa có tác dụng. Đổi camera sang 2.5D hoặc 3D.':'Z lớn = gần người xem. Nghiêng xoay tấm layer quanh trục.'}</div>${rngF({depth:l.depth||0,tiltX:l.tiltX||0,tiltY:l.tiltY||0},'Độ sâu Z','depth',-400,400,1,1,'px').replace('data-k="depth"','data-k="depth" data-ld="1"')}${rngF({tiltX:l.tiltX||0},'Nghiêng X','tiltX',-80,80,1,1,'°').replace('data-k="tiltX"','data-k="tiltX" data-ld="1"')}${rngF({tiltY:l.tiltY||0},'Nghiêng Y','tiltY',-80,80,1,1,'°').replace('data-k="tiltY"','data-k="tiltY" data-ld="1"')}</div>`}
function slOpt(t){const o=t.dataset.o;if(!o||!o.startsWith('dk'))return false;if(!deck)return true;const s=deck.slides[deck.cur];
  if(o==='dkname'){s.name=t.value||s.name;stripSig='';return true}
  if(o==='dkdur'){s.dur=clampv(parseFloat(t.value)||5,1,120);return true}
  if(o==='dktr'){s.trans.type=t.value;return true}
  if(o==='dktd'){s.trans.dur=clampv(parseFloat(t.value)||.6,.1,3);return true}
  if(o==='dkease'){s.cam.ease=t.value;return true}
  if(o==='dknotes'){s.notes=t.value;return true}
  if(o==='dkcam'){const k=t.dataset.k,v=parseFloat(t.value);curKf(s)[k]=v;const out=t.nextElementSibling;if(out)out.textContent=(Math.round(v*100)/100)+CAMR[k][3];if(cs&&window.__stRefresh)window.__stRefresh();return true}
  return true}
function slBtn(b){const o=b.dataset.o;if(!o||!o.startsWith('dk'))return false;if(!deck)return true;const s=deck.slides[deck.cur];
  if(o==='dkmode'){const prev=s.cam.mode;s.cam.mode=b.dataset.v;if(prev==='2d'&&s.cam.mode!=='2d'){const L=exportOrder_of(s);if(L.every(l=>!l.depth)){autoDepth(s);toast('Đã tự chia độ sâu Z cho các layer. Chỉnh lại trong Thuộc tính từng layer.')}}
    if(!CAMP[s.cam.mode])return true;s.cam.mids=[];camKf='start';s.cam.start={...CAMD};s.cam.end={...CAMD};const p=CAMP[s.cam.mode][0];if(p){s.cam.start={...CAMD,...p[1]};s.cam.end={...CAMD,...p[2]}}stripSig='';commit(true,'Đổi chế độ camera');if(camOpen)openCam(cs?cs.T:0,cs?cs.view:'cam');return true}
  if(o==='dkpre'){const p=CAMP[s.cam.mode][+b.dataset.i];s.cam.mids=[];camKf='start';s.cam.start={...CAMD,...p[1]};s.cam.end={...CAMD,...p[2]};commit(true,'Preset camera');if(camOpen)openCam(cs?cs.T:0,cs?cs.view:'cam');return true}
  if(o==='dkkf'){camKf=b.dataset.v;if(cs&&window.__stRefresh)window.__stRefresh();buildProps0();return true}
  if(o==='dkprev'){camOpen?closeCam():openCam();return true}
  if(o==='dkauto'){autoDepth(s);commit(true,'Chia độ sâu');if(camOpen)openCam(cs?cs.T:0,cs?cs.view:'cam');return true}
  if(o==='dkplay'){present(deck.cur);return true}
  if(o==='dkmotion'){openCam(0,'cam',{tab:'layer',layer:b.dataset.id});return true}
  return true}

/* ================= Present ================= */
function present(from){if(!deck)return;syncCur();closeCam();const slides=deck.slides;let idx=from||0,busy=false,curS=null,stopCam=null,auto=false,autoT=0;
  const ov=document.createElement('div');ov.className='pres';ov.innerHTML=`<div class="pst"></div><div class="phud"><span class="pn"></span><span class="sp"></span><label class="row" style="gap:5px;margin:0"><input type="checkbox" id="pAuto"> Tự chạy</label><button class="btn" data-a="x">Thoát (Esc)</button></div><div class="pnote"></div>`;document.body.appendChild(ov);
  const st=ov.querySelector('.pst'),pn=ov.querySelector('.pn'),note=ov.querySelector('.pnote');
  try{(ov.requestFullscreen||(()=>0)).call(ov)}catch(e){}
  const cache=new Map();const getSc=i=>{if(!cache.has(i))cache.set(i,makeScene(slides[i]));return cache.get(i)};
  function show(i,dir){if(i<0||i>=slides.length||busy)return;busy=true;clearTimeout(autoT);if(stopCam){stopCam();stopCam=null}
    const sc=getSc(i),s=slides[i],old=curS;st.appendChild(sc.wrap);fitScene(sc,st);sc.set(s.cam.start,0);idx=i;pn.textContent=(i+1)+' / '+slides.length+' · '+s.name;note.textContent=s.notes||'';note.hidden=!s.notes;
    const d=Math.max(.05,(old?(slides[i].trans.dur):0))*1000,t=old?slides[i].trans.type:'none';
    const base=sc.wrap.style.transform;const A=(el,kf,o)=>el.animate(kf,{duration:d,easing:'ease-in-out',fill:'both',...o});
    const fin=()=>{if(old&&old!==sc){old.wrap.remove()}sc.wrap.getAnimations().forEach(a=>a.cancel());curS=sc;busy=false;stopCam=playCam(sc,()=>{stopCam=null;if(auto&&idx<slides.length-1)autoT=setTimeout(()=>show(idx+1,1),600)})};
    if(!old||t==='none'||d<=0){fin();return}
    sc.wrap.style.zIndex=2;old.wrap.style.zIndex=1;let a;
    if(t==='fade'){A(old.wrap,[{opacity:1},{opacity:0}]);a=A(sc.wrap,[{opacity:0},{opacity:1}])}
    else if(t==='slide'){const w=st.clientWidth*(dir||1);A(old.wrap,[{transform:base},{transform:`translateX(${-w}px) ${base}`}]);a=A(sc.wrap,[{transform:`translateX(${w}px) ${base}`},{transform:base}])}
    else if(t==='zoom'){A(old.wrap,[{opacity:1,transform:base},{opacity:0,transform:base+' scale(1.25)'}]);a=A(sc.wrap,[{opacity:0,transform:base+' scale(.8)'},{opacity:1,transform:base}])}
    else{st.style.perspective='1600px';A(old.wrap,[{transform:base+' rotateY(0)',opacity:1},{transform:base+' rotateY(-90deg)',opacity:0}]);a=A(sc.wrap,[{transform:base+' rotateY(90deg)',opacity:0},{transform:base+' rotateY(0)',opacity:1}])}
    a.onfinish=()=>{st.style.perspective='';fin()}}
  const next=()=>{if(idx<slides.length-1)show(idx+1,1);else close()},prev=()=>show(idx-1,-1);
  function close(){clearTimeout(autoT);if(stopCam)stopCam();window.removeEventListener('keydown',key,true);window.removeEventListener('resize',rs);try{if(document.fullscreenElement)document.exitFullscreen()}catch(e){}ov.remove()}
  const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close()}else if(e.key==='ArrowRight'||e.key===' '||e.key==='PageDown'||e.key==='Enter'){e.preventDefault();e.stopPropagation();next()}else if(e.key==='ArrowLeft'||e.key==='PageUp'||e.key==='Backspace'){e.preventDefault();e.stopPropagation();prev()}};
  const rs=()=>{if(curS)fitScene(curS,st)};window.addEventListener('keydown',key,true);window.addEventListener('resize',rs);
  ov.addEventListener('click',e=>{const b=e.target.closest('button');if(b){close();return}if(e.target.id==='pAuto'){auto=e.target.checked;if(auto&&!stopCam&&!busy)autoT=setTimeout(()=>show(idx+1,1),400);return}if(e.target.closest('.phud'))return;const x=e.clientX/innerWidth;x<.25?prev():next()});
  show(idx,1)}

/* ================= Export (Bravin theo slide) ================= */
async function buildBravin(o){const tracks=[],slidesOut=[];let i=0,t0=0;
  const list=deck?(syncCur(),deck.slides):[{layers,bg:doc.bg,dur:o.duration,cam:null,trans:null,name:doc.name}];
  for(let si=0;si<list.length;si++){const s=list[si],dur=deck?s.dur:o.duration;
    await withSlideAsync(s,async()=>{
      for(const l of exportOrder()){
        if(l.clipTo)continue;const vis=effVis(l);if(!vis&&!o.hidden)continue;
        const b=bakeLeaf(l,o);if(!b)continue;
        tracks.push({id:'track-'+(++i),name:(deck?'S'+(si+1)+' · ':'')+(b.anc.length?b.anc.map(a=>a.name).reverse().join(' / ')+' / ':'')+l.name,index:i-1,enabled:vis,locked:l.locked,clips:[{id:'clip-'+i,name:l.name,start:t0,duration:dur,opacity:b.op,blendMode:l.blend,
          position:{x:b.x0,y:b.y0,width:b.w,height:b.h},...(deck&&s.cam.mode!=='2d'?{depth:{z:l.depth||0,tiltX:l.tiltX||0,tiltY:l.tiltY||0}}:{}),...(l.anim?{motion:l.anim}:{}),media:{type:'image',mime:'image/png',encoding:'data-url',data:b.c.toDataURL('image/png')}}]});
        await new Promise(r=>setTimeout(r,0))}});
    if(deck)slidesOut.push({name:s.name,start:t0,duration:dur,transition:s.trans,camera:{mode:s.cam.mode,ease:s.cam.ease,start:s.cam.start,end:s.cam.end,keys:camKeys(s).map(k=>({t:k.t,...k.c}))}});t0+=dur}
  return JSON.stringify({format:'bravin-project',schema:1,generator:'Antifact 1.1',createdAt:new Date().toISOString(),
    canvas:{width:doc.w,height:doc.h,background:doc.bg||null},timeline:{fps:o.fps,duration:deck?t0:o.duration,trackOrder:'bottom-to-top'},...(deck?{slides:slidesOut}:{}),tracks})}
async function withSlideAsync(s,fn){const L=layers,B=doc.bg;layers=s.layers;doc.bg=s.bg;try{return await fn()}finally{layers=L;doc.bg=B}}
async function exportSlidesPng(){if(!deck)return;syncCur();for(let i=0;i<deck.slides.length;i++){const c=withSlide(deck.slides[i],()=>flatten(!!0));const b=await toBlob(c,'image/png');if(!b)continue;if(!await saveFile(fname('-slide-'+(i+1)+'.png'),b))break}}

/* ================= Stage E: Camera studio + timeline + bảng tổng quan + xuất video/GIF ================= */
/* ---- mô hình thời gian: slide i = [chuyển cảnh td][camera chạy dur] ---- */
const tlModel=()=>{let t=0;const seg=deck.slides.map((s,i)=>{const td=(i>0&&s.trans&&s.trans.type!=='none')?Math.max(0,s.trans.dur||0):0;const g={i,s,t0:t,td,c0:t+td,c1:t+td+s.dur};t=g.c1;return g});return{seg,total:t}};
function tlAt(T){const{seg,total}=tlModel();T=Math.max(0,Math.min(total,T));let g=seg[seg.length-1];for(const x of seg){if(T<x.c1){g=x;break}}
  if(T<g.c0)return{g,ph:'tr',p:g.td?(T-g.t0)/g.td:1,prev:seg[g.i-1],T,total};
  return{g,ph:'cam',p:g.s.dur?Math.min(1,(T-g.c0)/g.s.dur):1,T,total}}
const camKeys=s=>{const m=(s.cam.mids||[]).slice().sort((a,b)=>a.t-b.t);return[{id:'start',t:0,c:s.cam.start},...m.map(x=>({id:'m:'+x.id,t:x.t,c:x.c,mid:x})),{id:'end',t:1,c:s.cam.end}]};
const kfObj=(s,k)=>{if(k==='start')return s.cam.start;if(k==='end')return s.cam.end;const m=(s.cam.mids||[]).find(x=>'m:'+x.id===k);return m?m.c:null};
const curKf=s=>{let o=kfObj(s,camKf);if(!o){camKf='start';o=s.cam.start}return o};
const camAtP=(s,p)=>{const K=camKeys(s);if(K.length===2)return lerpCam(K[0].c,K[1].c,ease(s.cam.ease,p));for(let i=0;i<K.length-1;i++){const a=K[i],b=K[i+1];if(p<=b.t||i===K.length-2){const q=b.t>a.t?Math.max(0,Math.min(1,(p-a.t)/(b.t-a.t))):1;return lerpCam(a.c,b.c,ease(s.cam.ease,q))}}};
const camCommit=label=>{pushHist(label);scheduleSave()};
function transP(type,p0){const p=ease('inout',p0);
  if(type==='fade')return{o:{op:1-p,tx:0,s:1,r:0},n:{op:p,tx:0,s:1,r:0}};
  if(type==='slide')return{o:{op:1,tx:-p,s:1,r:0},n:{op:1,tx:1-p,s:1,r:0}};
  if(type==='zoom')return{o:{op:1-p,tx:0,s:1+.25*p,r:0},n:{op:p,tx:0,s:.8+.2*p,r:0}};
  if(type==='flip')return{o:{op:1-p,tx:0,s:1,r:-90*p},n:{op:p,tx:0,s:1,r:90*(1-p)}};
  return{o:{op:0,tx:0,s:1,r:0},n:{op:1,tx:0,s:1,r:0}}}
const fmtT=t=>{t=Math.max(0,t);const m=Math.floor(t/60),s=t-m*60;return m+':'+(s<10?'0':'')+s.toFixed(1)};
const trName=t=>(TRANS.find(x=>x[0]===t)||[0,'Cắt thẳng'])[1];

/* ---- Camera studio ---- */
var cs=null;
function stScene(s){let sc=cs.scenes.get(s.id);if(!sc){sc=makeScene(s);sc.wrap.dataset.sid=s.id;cs.scenes.set(s.id,sc)}return sc}
function stXf(sc,tp){const area=cs.area,f=Math.min(area.clientWidth/doc.w,area.clientHeight/doc.h)||1;sc.f=f;const aw=area.clientWidth,ah=area.clientHeight,W=doc.w*f,H=doc.h*f,ox=(aw-W)/2,oy=(ah-H)/2;tp=tp||{op:1,tx:0,s:1,r:0};
  sc.wrap.style.opacity=tp.op;sc.wrap.style.transform=`translate(${ox+tp.tx*aw}px,${oy}px) translate(${W/2}px,${H/2}px) rotateY(${tp.r}deg) scale(${tp.s}) translate(${-W/2}px,${-H/2}px) scale(${f})`}
function stShow(T){if(!cs)return;const at=tlAt(T);cs.T=at.T;const list=[];
  if(cs.view==='space'){cs.at=at;camScene={sc:null,area:cs.area,ov:cs.ov,stop:null};stHead();spDraw();return}
  if(at.ph==='tr'&&at.prev){const tp=transP(at.g.s.trans.type,at.p);list.push([at.prev.s,at.prev.s.cam.end,tp.o,at.prev.s.dur],[at.g.s,at.g.s.cam.start,tp.n,0])}
  else list.push([at.g.s,camAtP(at.g.s,at.ph==='tr'?0:at.p),null,at.ph==='tr'?0:at.p*at.g.s.dur]);
  const keep=new Set(list.map(x=>x[0].id));[...cs.area.children].forEach(w=>{if(w.dataset.sid&&!keep.has(w.dataset.sid))w.remove()});
  list.forEach(([s,cam,tp,tau],k)=>{const sc=stScene(s);if(sc.wrap.parentNode!==cs.area)cs.area.appendChild(sc.wrap);sc.wrap.style.zIndex=k;sc.set(cam,tau);stXf(sc,tp)});
  cs.area.style.perspective=list.some(x=>x[2]&&x[2].r)?'1600px':'';
  camScene={sc:stScene(deck.slides[deck.cur]),area:cs.area,ov:cs.ov,stop:null};
  cs.at=at;stHead()}
function stHead(){if(!cs)return;const P=cs.pps||40,{total}=tlModel();
  cs.ph.style.left=(cs.T*P)+'px';cs.time.textContent=fmtT(cs.T)+' / '+fmtT(total);
  if(cs.at)cs.tlin.querySelectorAll('.tlb').forEach(b=>b.classList.toggle('pl',+b.dataset.i===cs.at.g.i));
  if(cs.playing){const sc=cs.tlsc,x=cs.T*P;if(x<sc.scrollLeft||x>sc.scrollLeft+sc.clientWidth-30)sc.scrollLeft=Math.max(0,x-60)}}
const kfT=(i,k)=>{const g=tlModel().seg[i];if(k==='start')return g.c0;if(k==='end')return g.c1;const m=(g.s.cam.mids||[]).find(x=>'m:'+x.id===k);return m?g.c0+m.t*g.s.dur:g.c0};
function stGo(i){if(i!==deck.cur){gotoSlide(i,true);stTop();stSide();tlRender()}}
function stTop(){const s=deck.slides[deck.cur],m=s.cam.mode,i=deck.cur;
  cs.top.innerHTML=`<b class="cmt">Slide ${i+1}/${deck.slides.length}</b>
   <span class="chips" title="Cách xem"><button class="chip ${cs.view==='cam'?'on':''}" data-v="cam">Qua camera</button><button class="chip ${cs.view==='space'?'on':''}" data-v="space">Không gian</button></span>
   <span class="chips" title="Kiểu camera">${[['2d','2D phẳng'],['2.5d','2.5D'],['3d','3D']].map(x=>`<button class="chip ${m===x[0]?'on':''}" data-m="${x[0]}">${x[1]}</button>`).join('')}</span>
   <select data-c="pre" aria-label="Chuyển động mẫu"><option value="">Mẫu chuyển động…</option>${(CAMP[m]||[]).map((p,k)=>`<option value="${k}">${p[0]}</option>`).join('')}</select>
   <label class="fld2">Nhịp <select data-c="ease">${EASES.map(t=>`<option value="${t[0]}" ${s.cam.ease===t[0]?'selected':''}>${t[1]}</option>`).join('')}</select></label>
   <label class="fld2">Dài <input type="number" data-c="dur" min="1" max="120" step=".5" value="${s.dur}"> s</label>
   <label class="fld2">Vào bằng <select data-c="tr" ${i===0?'disabled':''}>${TRANS.map(t=>`<option value="${t[0]}" ${s.trans.type===t[0]?'selected':''}>${t[1]}</option>`).join('')}</select></label>
   <label class="fld2"><input type="number" data-c="td" min=".1" max="3" step=".1" value="${s.trans.dur}" ${i===0||s.trans.type==='none'?'disabled':''} aria-label="Thời gian chuyển cảnh"> s</label>
   <span class="sp"></span><button class="btn" data-a="addkey" title="Thêm key camera tại đầu phát">◆+ Key</button><button class="btn" data-a="delkey" title="Xoá key giữa đang chọn">Xoá key</button><button class="btn" data-a="reset" title="Đặt điểm đang chọn về mặc định">Đặt lại</button><button class="btn" data-a="exp">Xuất video / GIF…</button><button class="btn pri" data-a="x">Xong</button>`}
function stKeyChips(){const s=deck.slides[deck.cur];return camKeys(s).map((k,n)=>`<button class="chip ${camKf===k.id?'on':''}" data-k="${k.id}">◆ ${k.id==='start'?'Đầu':k.id==='end'?'Cuối':'Key '+n} <small>${(k.t*s.dur).toFixed(1)}s</small></button>`).join('')}
function stKeyList(){if(!cs)return;const e=cs.side.querySelector('.kfl');if(e)e.innerHTML=stKeyChips()}
function stCamSide(){const s=deck.slides[deck.cur],m=s.cam.mode,kf=curKf(s);const lim=k=>(CAMLIM[m]&&CAMLIM[m][k])||[CAMR[k][0],CAMR[k][1]];
  return `<div class="chips kfl" style="margin-bottom:6px">${stKeyChips()}</div><div class="row" style="margin:0 0 8px"><button class="btn" data-a="addkey" title="Thêm key camera tại vị trí đầu phát">◆+ Key tại đầu phát</button><button class="btn" data-a="delkey" title="Xoá key đang chọn (Delete)">Xoá key</button></div>
   <div class="empty" style="margin:0 0 8px">${cs.view==='space'?'Đang ở chế độ Không gian: kéo chuột để xoay góc nhìn, Shift+kéo để dịch, cuộn để thu phóng. Camera đầu (xanh lá), cuối (hồng) và đường đi (vàng) hiện trong không gian. ':''}<b>W A S D</b> lướt tới / lùi / trái / phải, <b>Q E</b> xuống / lên (giữ Shift để đi nhanh). ${cs.view==='space'?'':m==='3d'?'Kéo chuột để xoay, Shift+kéo để dịch, cuộn để tiến / lùi.':m==='2.5d'?'Kéo để dịch + nghiêng nhẹ (parallax), cuộn để thu phóng.':'Kéo để dịch, cuộn để thu phóng (Ken Burns).'}</div>`
   +CAMK[m].map(k=>{const[a,b]=lim(k),v=kf[k]??CAMD[k];return `<div class="rng"><span>${CAML[k]}</span><input type="range" data-k="${k}" min="${a}" max="${b}" step="${CAMR[k][2]}" value="${v}"><output>${Math.round(v*100)/100}${CAMR[k][3]}</output></div>`}).join('')
   +(m!=='2d'?`<div class="row"><button class="btn" data-a="auto" title="Chia độ sâu Z đều theo thứ tự layer">Tự chia độ sâu Z</button></div>`:'')
   +`<p class="ohint" style="margin-top:10px">Đưa đầu phát tới thời điểm bất kỳ trong slide rồi kéo / chỉnh camera: key mới tự được tạo ở đó. Kéo ◆ giữa trên timeline để đổi thời điểm. Bấm ▶ để xem lại.</p>`}
function tlTicks(P,total){const step=P>=60?1:P>=26?2:P>=12?5:10;let h='';for(let t=0;t<=total+.001;t+=step)h+=`<i style="left:${t*P}px">${fmtT(t).replace('.0','')}</i>`;return h}
function tlRender(){if(!cs)return;const{seg,total}=tlModel();const sc=cs.tlsc;
  if(!cs.pps)cs.pps=Math.max(14,Math.min(120,(sc.clientWidth-40)/Math.max(1,total)));const P=cs.pps,W=Math.ceil(total*P)+60;
  const col={'2d':'#2fd0ee','2.5d':'#ffd43b','3d':'#ff4f99'};
  let h=`<div class="tlru" style="width:${W}px">${tlTicks(P,total)}</div><div class="tlrow" style="width:${W}px">`;
  seg.forEach(g=>{h+=`<div class="tlb${g.i===deck.cur?' on':''}" data-i="${g.i}" style="left:${g.t0*P}px;width:${Math.max(8,(g.td+g.s.dur)*P-2)}px">${g.td?`<span class="tltr" data-tr="${g.i}" style="width:${g.td*P}px" title="Chuyển cảnh: ${trName(g.s.trans.type)} · bấm để đổi"><em>${trName(g.s.trans.type)}</em></span>`:''}<span class="tln" style="left:${g.td*P+6}px">${g.i+1} · ${esc(g.s.name)}</span><i class="tlrz" data-rz="${g.i}" title="Kéo để đổi thời lượng"></i></div>`});
  h+=`</div><div class="tlrow tlcr" style="width:${W}px">`;
  seg.forEach(g=>{const w=g.s.dur*P,cl=col[g.s.cam.mode];
    const pts=[];for(let k=0;k<=16;k++){const q=k/16;pts.push((q*100).toFixed(1)+','+(100-ease(g.s.cam.ease,q)*100).toFixed(1))}
    h+=`<div class="tlcm" style="left:${g.c0*P}px;width:${Math.max(8,w)}px;--c:${cl}"><svg viewBox="0 0 100 100" preserveAspectRatio="none"><polyline points="${pts.join(' ')}" fill="none" stroke="${cl}" stroke-width="2" vector-effect="non-scaling-stroke" opacity=".85"/></svg><button class="kf ${g.i===deck.cur&&camKf==='start'?'on':''}" data-i="${g.i}" data-k="start" title="Điểm đầu camera">◆</button><button class="kf e ${g.i===deck.cur&&camKf==='end'?'on':''}" data-i="${g.i}" data-k="end" title="Điểm cuối camera">◆</button>${(g.s.cam.mids||[]).map(m=>`<button class="kf m ${g.i===deck.cur&&camKf==='m:'+m.id?'on':''}" data-i="${g.i}" data-k="m:${m.id}" style="left:${m.t*100}%" title="Key camera · kéo để đổi thời điểm">◆</button>`).join('')}<b>${g.s.cam.mode==='2d'?'2D':g.s.cam.mode==='2.5d'?'2.5D':'3D'}</b></div>`});
  h+='</div>';
  const AL=deck.slides.map(x=>exportOrder_of(x).filter(l=>l.anim&&!l.clipTo).reverse()),nrow=Math.min(8,Math.max(0,...AL.map(a=>a.length)));
  if(nrow){h+=`<div class="tlrow tlanr" style="width:${W}px;height:${nrow*18}px">`;seg.forEach(g=>{AL[g.i].slice(0,nrow).forEach((l,k)=>{const a=l.anim,d=g.s.dur;
    h+=`<div class="tlan${l.id===cs.ls?' on':''}" data-i="${g.i}" data-l="${l.id}" style="left:${g.c0*P}px;width:${Math.max(8,d*P)}px;top:${k*18}px">${a.loop&&a.loop!=='none'?'<b class="al"></b>':''}${a.in&&a.in!=='none'?`<b class="ai" style="left:${(a.inD||0)*P}px;width:${Math.max(3,Math.min(a.inL||.6,d)*P)}px"></b>`:''}${a.out&&a.out!=='none'?`<b class="ao" style="left:${Math.max(0,d-(a.outD||0)-(a.outL||.5))*P}px;width:${Math.max(3,(a.outL||.5)*P)}px"></b>`:''}<span>${esc(l.name)}</span></div>`})});h+='</div>'}
  h+=`<div class="tlph" style="left:${cs.T*P}px"><u></u></div>`;
  cs.tlin.style.width=W+'px';cs.tlin.innerHTML=h;{const tl=cs.ov.querySelector('.tl');if(tl)tl.style.height=(182+(nrow?Math.min(nrow,5)*18+8:0))+'px'}cs.ph=cs.tlin.querySelector('.tlph');stHead()}
function kfAdd(T,pose){const s=deck.slides[deck.cur],g=tlModel().seg[deck.cur];const t=(T-g.c0)/g.s.dur;
  const near=camKeys(s).find(k=>Math.abs(k.t-t)*g.s.dur<.08);
  if(near){camKf=near.id;if(pose)Object.assign(near.c,pose);return near.id}
  const mid={id:uid(),t:Math.round(t*1000)/1000,c:{...CAMD,...(pose||camAtP(s,t))}};(s.cam.mids=s.cam.mids||[]).push(mid);camKf='m:'+mid.id;return camKf}
function stEnsureKey(){if(cs.playing)stStop();if(cs.at&&cs.at.g.i!==deck.cur)stGo(cs.at.g.i);
  const s=deck.slides[deck.cur],g=tlModel().seg[deck.cur],T=Math.max(g.c0,Math.min(g.c1,cs.T)),b=camKf,n0=(s.cam.mids||[]).length;
  kfAdd(T,null);if((s.cam.mids||[]).length!==n0||camKf!==b){tlRender();stKeyList();buildProps0()}
  const kt=kfT(deck.cur,camKf);if(Math.abs(cs.T-kt)>.001||!cs.at||cs.at.g.i!==deck.cur||cs.at.ph!=='cam')stShow(kt);
  return curKf(s)}
function stDelKey(){const s=deck.slides[deck.cur];if(!camKf.startsWith('m:')){toast('Chỉ xoá được key giữa. Điểm đầu / cuối dùng "Đặt lại".');return}
  const K=camKeys(s),i=K.findIndex(k=>k.id===camKf);s.cam.mids=(s.cam.mids||[]).filter(m=>'m:'+m.id!==camKf);camKf=K[Math.max(0,i-1)].id;
  stShow(kfT(deck.cur,camKf));tlRender();stSide();stTop();camCommit('Xoá key camera');buildProps0()}
function stAddKey(){if(cs.at&&cs.at.g.i!==deck.cur)stGo(cs.at.g.i);const g=tlModel().seg[deck.cur];if(cs.T<=g.c0+.05||cs.T>=g.c1-.05){toast('Đưa đầu phát vào giữa slide (không sát đầu / cuối) rồi bấm thêm key.');return}
  stEnsureKey();camCommit('Thêm key camera');stSide();stTop();buildProps0();if(cs.view==='space')spDraw()}
function stReqShow(T){cs.pendT=T;if(cs.pr)return;cs.pr=requestAnimationFrame(()=>{cs.pr=0;if(!cs||cs.pendT==null)return;const t=cs.pendT;cs.pendT=null;stShow(t)})}
function stStop(){if(!cs)return;cs.playing=false;cancelAnimationFrame(cs.raf);const b=cs.ov.querySelector('[data-a="tplay"]');if(b)b.textContent='▶';
  if(cs.at&&cs.at.g.i!==deck.cur)stGo(cs.at.g.i)}
function stPlay(){if(!cs)return;if(cs.playing){stStop();return}const{total}=tlModel();if(cs.T>=total-.02)cs.T=0;cs.playing=true;cs.ov.querySelector('[data-a="tplay"]').textContent='⏸';let last=performance.now();
  const step=now=>{if(!cs||!cs.playing)return;const dt=Math.min(.1,(now-last)/1000);last=now;let T=cs.T+dt;if(T>=total){stShow(total);stStop();return}stShow(T);cs.raf=requestAnimationFrame(step)};cs.raf=requestAnimationFrame(step)}
window.__stRefresh=()=>{if(cs){curKf(deck.slides[deck.cur]);stTop();stSide();stShow(kfT(deck.cur,camKf));tlRender()}};
function openCam(T0,view0,opt){if(!deck)return;syncCur();closeCam();camOpen=true;
  const ov=document.createElement('div');ov.className='camv';ov.id='camv';
  ov.innerHTML=`<div class="cmtop"></div><div class="cmmid"><div class="camarea"></div><div class="cmside"></div></div><div class="tl"><div class="tlh"><button class="btn pri" data-a="tplay" aria-label="Phát / dừng">▶</button><button class="btn" data-a="tstart" title="Về đầu">⏮</button><span class="tlt">0:00.0 / 0:00.0</span><span class="sp"></span><span class="ohint">Kéo thước để xem lướt · bấm ◆ chọn key, kéo ◆ giữa để dời · chỉnh camera tại đầu phát để tự tạo key · mép phải khối slide = thời lượng</span><label class="fld2">Thu phóng <input type="range" data-a="tz" min="10" max="160" value="40" style="width:90px"></label></div><div class="tlsc"><div class="tlin"></div></div></div>`;
  document.body.appendChild(ov);
  cs={ov,top:ov.querySelector('.cmtop'),area:ov.querySelector('.camarea'),side:ov.querySelector('.cmside'),tlsc:ov.querySelector('.tlsc'),tlin:ov.querySelector('.tlin'),time:ov.querySelector('.tlt'),scenes:new Map(),T:0,playing:false,raf:0,pps:0,at:null,ph:null,view:'cam',keys:new Set(),sp:null,flyRaf:0,tab:'cam',ls:null};
  camKf='start';stTop();stSide();tlRender();stShow(T0!=null?T0:kfT(deck.cur,'start'));if(opt){cs.tab=opt.tab||'cam';cs.ls=opt.layer||null;stSide()}if(view0==='space')stView('space');
  cs.keyh=e=>{if(!cs)return;if(stFlyKey(e,true))return;const t=e.target;if(t&&/INPUT|SELECT|TEXTAREA/.test(t.tagName)&&e.key!=='Escape')return;
    if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closeCam()}else if((e.key==='Delete'||e.key==='Backspace')&&cs.tab==='cam'){e.preventDefault();e.stopPropagation();stDelKey()}else if(e.key===' '){e.preventDefault();e.stopPropagation();stPlay()}};
  window.addEventListener('keydown',cs.keyh,true);cs.keyu=e=>{stFlyKey(e,false)};window.addEventListener('keyup',cs.keyu,true);
  const area=cs.area;
  /* kéo trong khung xem để chỉnh camera */
  const kfOf=()=>curKf(deck.slides[deck.cur]);
  const ensure=()=>stEnsureKey();
  let dr=null;
  area.addEventListener('contextmenu',e=>{if(cs.view==='space')e.preventDefault()});
  area.addEventListener('pointerdown',e=>{if(e.target.closest('.spbar'))return;if(cs.playing)stStop();if(cs.view==='space'){spDown(e);return}dr={x:e.clientX,y:e.clientY,k:0};area.setPointerCapture(e.pointerId)});
  area.addEventListener('pointermove',e=>{if(cs.view==='space'){spMove(e);return}if(!dr)return;const dx=e.clientX-dr.x,dy=e.clientY-dr.y;if(!dr.k){if(Math.abs(dx)+Math.abs(dy)<2)return;ensure();dr.k=1}dr.x=e.clientX;dr.y=e.clientY;const s=deck.slides[deck.cur],c=kfOf(),m=s.cam.mode,f=stScene(s).f||1;
    if(m==='3d'&&!e.shiftKey){c.yaw=clampv((c.yaw||0)+dx*.35,-180,180);c.pitch=clampv((c.pitch||0)-dy*.35,-90,90)}
    else if(m==='2.5d'&&!e.shiftKey){c.x=clampv((c.x||0)+dx/f,-1200,1200);c.y=clampv((c.y||0)+dy/f,-800,800);c.yaw=clampv((c.yaw||0)+dx*.04,-15,15);c.pitch=clampv((c.pitch||0)-dy*.04,-15,15)}
    else{c.x=clampv((c.x||0)+dx/f,-1200,1200);c.y=clampv((c.y||0)+dy/f,-800,800)}
    stShow(kfT(deck.cur,camKf));stSideSync();syncCamSliders()});
  area.addEventListener('pointerup',()=>{if(cs.view==='space'){spUp();return}if(dr){const k=dr.k;dr=null;if(k)camCommit('Chỉnh camera')}});area.addEventListener('pointercancel',()=>{dr=null;if(cs.view==='space')spUp()});
  area.addEventListener('wheel',e=>{e.preventDefault();if(cs.view==='space'){if(cs.playing)stStop();spWheel(e);return}if(cs.playing)stStop();ensure();const s=deck.slides[deck.cur],c=kfOf();if(s.cam.mode==='3d')c.z=clampv((c.z||0)-e.deltaY*.8,-2500,1000);else c.zoom=clampv((c.zoom||1)*(e.deltaY<0?1.05:.95),.3,3);
    stShow(kfT(deck.cur,camKf));stSideSync();syncCamSliders();clearTimeout(cs.wt);cs.wt=setTimeout(()=>camCommit('Chỉnh camera'),300)},{passive:false});
  /* thanh trên */
  ov.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||!cs)return;
    if(b.dataset.v){stView(b.dataset.v);return}if(b.dataset.sp){spAct(b.dataset.sp);return}
    if(b.dataset.tab){cs.tab=b.dataset.tab;stSide();return}if(b.dataset.ly){cs.ls=b.dataset.ly;stSide();if(cs.view==='space')spDraw();return}
    if(b.dataset.m){if(cs.playing)stStop();slBtn({dataset:{o:'dkmode',v:b.dataset.m}});return}
    if(b.dataset.k&&b.closest('.cmside')){if(cs.playing)stStop();camKf=b.dataset.k;stSide();stShow(kfT(deck.cur,camKf));tlRender();buildProps0();return}
    const a=b.dataset.a;if(!a)return;
    if(a==='x')closeCam();else if(a==='lyplay'){stGo(deck.cur);stStop();stShow(kfT(deck.cur,'start'));stPlay()}else if(a==='lystag')stagAll();else if(a==='lyclr')clrAnim();else if(a==='tplay')stPlay();else if(a==='tstart'){stStop();stShow(0);tlRender()}
    else if(a==='addkey')stAddKey();else if(a==='delkey')stDelKey();
    else if(a==='reset'){const s=deck.slides[deck.cur];Object.assign(curKf(s),CAMD);stShow(kfT(deck.cur,camKf));stSide();tlRender();camCommit('Đặt lại camera')}
    else if(a==='auto'){autoDepth(deck.slides[deck.cur]);commit(true,'Chia độ sâu');openCam(cs.T,cs.view)}
    else if(a==='exp'){stStop();exportDlg()}});
  ov.addEventListener('change',e=>{const t=e.target,c=t.dataset.c,s=deck.slides[deck.cur];if(t.dataset.a==='tz'){return}if(t.dataset.an){setAnim(t.dataset.an,t.value);return}if(!c)return;
    if(c==='pre'){if(t.value==='')return;slBtn({dataset:{o:'dkpre',i:t.value}});return}
    if(c==='ease')s.cam.ease=t.value;else if(c==='dur')s.dur=clampv(parseFloat(t.value)||5,1,120);else if(c==='tr')s.trans.type=t.value;else if(c==='td')s.trans.dur=clampv(parseFloat(t.value)||.6,.1,3);
    commit(true,'Chỉnh slide');if(cs){stTop();tlRender();stShow(cs.T)}});
  ov.addEventListener('input',e=>{const t=e.target;
    if(t.dataset.a==='tz'){cs.pps=+t.value;tlRender();return}
    if(t.dataset.lk){const l=stCurLayer();if(l){const v=parseFloat(t.value)||0;l[t.dataset.lk]=v;const o=t.nextElementSibling;if(o)o.textContent=v+CAMR_U[t.dataset.lk];stShow(cs.T);clearTimeout(cs.wt);cs.wt=setTimeout(()=>commit(false,'Độ sâu layer'),400)}return}
    if(t.dataset.an==='loopS'){const l=stCurLayer();if(l){const a=l.anim||ANDEF();a.loopS=parseFloat(t.value)||1;l.anim=a;const o=t.nextElementSibling;if(o)o.textContent=a.loopS+'×';stShow(cs.T)}return}
    if(t.closest('.cmside')&&t.dataset.k){const k=t.dataset.k,v=parseFloat(t.value);if(cs.playing)stStop();ensure()[k]=v;const o=t.nextElementSibling;if(o)o.textContent=(Math.round(v*100)/100)+CAMR[k][3];stShow(kfT(deck.cur,camKf));syncCamSliders();clearTimeout(cs.wt);cs.wt=setTimeout(()=>camCommit('Chỉnh camera'),400)}});
  /* timeline: tua, chọn, đổi thời lượng */
  const tsc=cs.tlsc;let tdr=null;
  const tOf=e=>{const r=cs.tlin.getBoundingClientRect();return (e.clientX-r.left)/cs.pps};
  tsc.addEventListener('pointerdown',e=>{const t=e.target;
    const an=t.closest('.tlan');if(an){stGo(+an.dataset.i);cs.ls=an.dataset.l;cs.tab='layer';stSide();if(cs.view==='space')spDraw();return}
    if(t.closest('.kf')){const b=t.closest('.kf'),i=+b.dataset.i,k=b.dataset.k;if(cs.playing)stStop();stGo(i);camKf=k;stTop();stSide();stShow(kfT(i,camKf));tlRender();buildProps0();if(k.startsWith('m:')){tdr={mode:'kf',i,k,moved:false};tsc.setPointerCapture(e.pointerId)}return}
    if(t.closest('.tltr')){const i=+t.closest('.tltr').dataset.tr;showMenu(TRANS.map(x=>({t:x[1],on:deck.slides[i].trans.type===x[0],f:()=>{deck.slides[i].trans.type=x[0];if(x[0]!=='none'&&!deck.slides[i].trans.dur)deck.slides[i].trans.dur=.6;commit(true,'Đổi chuyển cảnh');if(cs){stTop();tlRender();stShow(cs.T)}}})),e.clientX,e.clientY);return}
    if(t.closest('.tlrz')){const i=+t.closest('.tlrz').dataset.rz;tdr={mode:'rz',i,x:e.clientX,d0:deck.slides[i].dur};tsc.setPointerCapture(e.pointerId);return}
    if(cs.playing)stStop();tdr={mode:'scrub'};tsc.setPointerCapture(e.pointerId);stShow(tOf(e))});
  tsc.style.touchAction='none';
  tsc.addEventListener('pointermove',e=>{if(!tdr)return;
    if(tdr.mode==='scrub')stReqShow(tOf(e));
    else if(tdr.mode==='kf'){const s=deck.slides[tdr.i],m=(s.cam.mids||[]).find(x=>'m:'+x.id===tdr.k);if(!m)return;const g=tlModel().seg[tdr.i];m.t=Math.max(.02,Math.min(.98,Math.round(((tOf(e)-g.c0)/s.dur)*200)/200));tdr.moved=true;
      const el=cs.tlin.querySelector('.kf.m[data-k="'+tdr.k+'"]');if(el)el.style.left=(m.t*100)+'%';stReqShow(g.c0+m.t*s.dur)}
    else{const s=deck.slides[tdr.i];s.dur=clampv(Math.round((tdr.d0+(e.clientX-tdr.x)/cs.pps)*10)/10,1,120);tlRender();stTop();stShow(cs.T)}});
  const tup=()=>{if(!tdr)return;const m=tdr.mode,i=tdr.i,mv=tdr.moved;tdr=null;if(cs.pendT!=null){const t=cs.pendT;cs.pendT=null;stShow(t)}
    if(m==='kf'){if(mv){tlRender();stKeyList();camCommit('Dời key camera')}return}
    if(m==='rz'){commit(true,'Đổi thời lượng slide')}
    else if(cs.at&&cs.at.g.i!==deck.cur){stGo(cs.at.g.i);stShow(cs.T)}};
  tsc.addEventListener('pointerup',tup);tsc.addEventListener('pointercancel',tup);
  window.__camResize=()=>{if(cs)stShow(cs.T)};buildProps0()}
function closeCam(){const o=$('#camv');if(cs){cancelAnimationFrame(cs.raf);cancelAnimationFrame(cs.flyRaf);window.removeEventListener('keydown',cs.keyh,true);window.removeEventListener('keyup',cs.keyu,true)}if(cs&&cs.sp&&cs.sp.g){try{const x=cs.sp.g.gl.getExtension('WEBGL_lose_context');if(x)x.loseContext()}catch(e){}}if(o)o.remove();cs=null;camScene=null;camOpen=false;window.__camResize=null;if(deck){buildProps0();stripSync(true)}}

/* ================= Bảng tổng quan: kéo thả tự do + dây nối ================= */
const OVW=300;
function thumbBig(s){if(s._thb)return s._thb;const w=360,c=document.createElement('canvas');c.width=w;c.height=Math.max(60,Math.round(w*doc.h/doc.w));const x=c.getContext('2d');
  try{const f=withSlide(s,()=>flatten(false));if(!s.bg){x.fillStyle='#20212b';x.fillRect(0,0,c.width,c.height)}x.drawImage(f,0,0,c.width,c.height)}catch(e){}return s._thb=c}
function overview(){if(!deck)return;syncCur();
  const CH=Math.round(OVW*doc.h/doc.w),NH=40,GAPX=130,GAPY=90;let V={x:40,y:30,z:1};
  deck.slides.forEach(s=>{s._thb=null});
  const ensurePos=()=>{let px=null;deck.slides.forEach((s,i)=>{if(typeof s.bx!=='number'||typeof s.by!=='number'){if(i===0)autoArr(false);else{const p=deck.slides[i-1];s.bx=p.bx+OVW+GAPX;s.by=p.by}}})};
  const autoArr=(h)=>{const n=deck.slides.length,cols=Math.max(1,Math.ceil(Math.sqrt(n*1.3)));deck.slides.forEach((s,i)=>{s.bx=(i%cols)*(OVW+GAPX);s.by=Math.floor(i/cols)*(CH+NH+GAPY)});if(h)pushHist('Sắp xếp bảng')};
  const m=document.createElement('div');m.className='ovw';
  m.innerHTML=`<div class="ovh"><b>Bảng tổng quan</b><span class="ohint">Kéo thẻ để sắp xếp tự do · kéo ● bên phải thẻ sang thẻ khác để nối / đổi thứ tự (thả ra chỗ trống = tạo slide mới) · kéo nền để di chuyển · cuộn để thu phóng · nhấp đúp để mở slide</span><span class="sp"></span><button class="btn" data-a="add">${ic('plus')} Slide mới</button><button class="btn" data-a="arr">Sắp xếp lại</button><button class="btn" data-a="fit">Vừa khung</button><button class="btn" data-a="exp">Xuất…</button><button class="btn pri" data-a="play">Trình chiếu</button><button class="btn" data-a="x">Đóng</button></div>
   <div class="ovb"><div class="ovs"><svg class="ovl" width="1" height="1"><defs><marker id="ovarr" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0L10,5L0,10z" fill="#ff4f99"/></marker></defs><g id="ovp"></g><path id="ovt" fill="none" stroke="#ffd43b" stroke-width="2.5" stroke-dasharray="6 5" hidden/></svg><div id="ovk"></div><div id="ovc"></div></div></div>`;
  const b=m.querySelector('.ovb'),world=m.querySelector('.ovs'),gp=m.querySelector('#ovp'),gk=m.querySelector('#ovk'),gc=m.querySelector('#ovc'),tmp=m.querySelector('#ovt');
  const view=()=>{world.style.transform=`translate(${V.x}px,${V.y}px) scale(${V.z})`;b.style.backgroundPosition=`${V.x}px ${V.y}px`;b.style.backgroundSize=`${22*V.z}px ${22*V.z}px`};
  const portOut=s=>({x:s.bx+OVW,y:s.by+CH/2}),portIn=s=>({x:s.bx,y:s.by+CH/2});
  const curve=(a,c)=>{const d=Math.max(70,Math.min(260,Math.hypot(c.x-a.x,c.y-a.y)*.45));return `M${a.x},${a.y} C${a.x+d},${a.y} ${c.x-d},${c.y} ${c.x},${c.y}`};
  const mid=(a,c)=>{const d=Math.max(70,Math.min(260,Math.hypot(c.x-a.x,c.y-a.y)*.45));const t=.5,u=1-t;return{x:u*u*u*a.x+3*u*u*t*(a.x+d)+3*u*t*t*(c.x-d)+t*t*t*c.x,y:u*u*u*a.y+3*u*u*t*a.y+3*u*t*t*c.y+t*t*t*c.y}};
  const links=()=>{let p='',k='';const S=deck.slides;for(let i=0;i<S.length-1;i++){const a=portOut(S[i]),c=portIn(S[i+1]);p+=`<path d="${curve(a,c)}" fill="none" stroke="#ff4f99" stroke-width="3" marker-end="url(#ovarr)" opacity=".9"/>`;const q=mid(a,c),t=S[i+1].trans.type;
      k+=`<div class="ovk" style="left:${q.x}px;top:${q.y}px"><button data-tr="${i+1}" title="Chuyển cảnh vào slide ${i+2}">${trName(t)}${t!=='none'?' · '+S[i+1].trans.dur+'s':''}</button><button data-ins="${i}" title="Chèn slide giữa ${i+1} và ${i+2}">+</button></div>`}
    gp.innerHTML=p;gk.innerHTML=k};
  const cards=()=>{gc.innerHTML=deck.slides.map((s,i)=>`<div class="ovc${i===deck.cur?' on':''}" data-i="${i}" style="left:${s.bx}px;top:${s.by}px;width:${OVW}px"><canvas width="360" height="${Math.round(360*doc.h/doc.w)}"></canvas><div class="ovn"><b>${i+1}</b><input value="${esc(s.name)}" data-n="${i}" aria-label="Tên slide"><span class="cm">${s.cam.mode==='2d'?'2D':s.cam.mode==='2.5d'?'2.5D':'3D'} · ${s.dur}s</span></div><span class="ovo" data-port="${i}" style="top:${CH/2-11}px" title="Kéo sang thẻ khác để nối"></span><span class="ovi" style="top:${CH/2-6}px"></span></div>`).join('');
    gc.querySelectorAll('.ovc').forEach((d,i)=>{const cv=d.querySelector('canvas');cv.getContext('2d').drawImage(thumbBig(deck.slides[i]),0,0,cv.width,cv.height)})};
  const draw=()=>{ensurePos();cards();links();view()};
  const fit=()=>{const S=deck.slides;let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;S.forEach(s=>{x0=Math.min(x0,s.bx);y0=Math.min(y0,s.by);x1=Math.max(x1,s.bx+OVW);y1=Math.max(y1,s.by+CH+NH)});const bw=b.clientWidth,bh=b.clientHeight,w=x1-x0,h=y1-y0;V.z=Math.max(.2,Math.min(1.2,(bw-90)/w,(bh-90)/h));V.x=(bw-w*V.z)/2-x0*V.z;V.y=(bh-h*V.z)/2-y0*V.z;view()};
  const W2=(e)=>{const r=b.getBoundingClientRect();return{x:(e.clientX-r.left-V.x)/V.z,y:(e.clientY-r.top-V.y)/V.z}};
  const reorder=(from,to)=>{if(from===to)return;syncCur();const S=deck.slides,cur=S[deck.cur],src=S[from],[mv]=S.splice(to,1);const a=S.indexOf(src);S.splice(a+1,0,mv);deck.cur=S.indexOf(cur);pushHist('Nối slide');stripSig='';stripSync(true)};
  const insertAfter=(a,pos)=>{gotoSlide(a,true);addSlide(false);const s=deck.slides[deck.cur];if(pos){s.bx=Math.round(pos.x);s.by=Math.round(pos.y)}else{const p=deck.slides[a];s.bx=p.bx+30;s.by=p.by+CH+NH+40}draw()};
  /* tương tác chuột */
  let drag=null,zTop=10;
  const up=e=>{window.removeEventListener('pointermove',mv);window.removeEventListener('pointerup',up);if(!drag)return;const d=drag;drag=null;
    if(d.t==='card'){if(d.moved){pushHist('Di chuyển slide trên bảng');stripSig=''}}
    else if(d.t==='link'){tmp.setAttribute('hidden','');const el=document.elementFromPoint(e.clientX,e.clientY),c=el&&el.closest&&el.closest('.ovc');
      if(c&&+c.dataset.i!==d.i){reorder(d.i,+c.dataset.i);draw()}
      else if(!c&&d.moved>30){const w=W2(e);insertAfter(d.i,{x:w.x-OVW/2+0,y:w.y-CH/2})}
      else draw()}};
  const mv=e=>{if(!drag)return;const dx=e.clientX-drag.x0,dy=e.clientY-drag.y0;
    if(drag.t==='pan'){V.x=drag.vx+dx;V.y=drag.vy+dy;view()}
    else if(drag.t==='card'){if(Math.abs(dx)+Math.abs(dy)>3)drag.moved=true;if(!drag.moved)return;const s=deck.slides[drag.i],sn=e.shiftKey?1:10;s.bx=Math.round((drag.bx+dx/V.z)/sn)*sn;s.by=Math.round((drag.by+dy/V.z)/sn)*sn;const el=gc.querySelector(`.ovc[data-i="${drag.i}"]`);if(el){el.style.left=s.bx+'px';el.style.top=s.by+'px'}links()}
    else if(drag.t==='link'){drag.moved=Math.hypot(dx,dy);const a=portOut(deck.slides[drag.i]),w=W2(e);tmp.removeAttribute('hidden');tmp.setAttribute('d',curve(a,w));
      const el=document.elementFromPoint(e.clientX,e.clientY),c=el&&el.closest&&el.closest('.ovc');gc.querySelectorAll('.ovc').forEach(x=>x.classList.toggle('tgt',x===c&&+x.dataset.i!==drag.i))}};
  b.addEventListener('pointerdown',e=>{if(e.button!==0)return;const t=e.target;if(t.closest('input,button'))return;
    const port=t.closest('.ovo'),card=t.closest('.ovc');
    if(port){drag={t:'link',i:+port.dataset.port,x0:e.clientX,y0:e.clientY,moved:0}}
    else if(card){const i=+card.dataset.i,s=deck.slides[i];drag={t:'card',i,x0:e.clientX,y0:e.clientY,bx:s.bx,by:s.by,moved:false};card.style.zIndex=++zTop}
    else{drag={t:'pan',x0:e.clientX,y0:e.clientY,vx:V.x,vy:V.y}}
    window.addEventListener('pointermove',mv);window.addEventListener('pointerup',up)});
  b.addEventListener('wheel',e=>{e.preventDefault();const r=b.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top,k=Math.exp(-e.deltaY*(e.ctrlKey?.01:.0015)),z=Math.max(.2,Math.min(2,V.z*k));V.x=px-(px-V.x)*(z/V.z);V.y=py-(py-V.y)*(z/V.z);V.z=z;view()},{passive:false});
  m.addEventListener('dblclick',e=>{const c=e.target.closest('.ovc');if(c&&!e.target.closest('input')){gotoSlide(+c.dataset.i);close()}});
  m.addEventListener('click',e=>{const bt=e.target.closest('button');if(!bt)return;
    if(bt.dataset.tr){const i=+bt.dataset.tr;showMenu(TRANS.map(x=>({t:x[1],on:deck.slides[i].trans.type===x[0],f:()=>{deck.slides[i].trans.type=x[0];if(x[0]!=='none'&&!deck.slides[i].trans.dur)deck.slides[i].trans.dur=.6;pushHist('Đổi chuyển cảnh');links()}})),e.clientX,e.clientY);return}
    if(bt.dataset.ins!=null){insertAfter(+bt.dataset.ins);return}
    const a=bt.dataset.a;if(a==='x')close();else if(a==='add'){const last=deck.slides[deck.slides.length-1];insertAfter(deck.slides.length-1,{x:last.bx+OVW+GAPX,y:last.by})}
    else if(a==='arr'){autoArr(true);draw();fit()}else if(a==='fit')fit();else if(a==='play'){close();present(deck.cur)}else if(a==='exp')exportDlg()});
  m.addEventListener('change',e=>{const i=e.target.dataset.n;if(i!=null){deck.slides[+i].name=e.target.value||('Slide '+(+i+1));pushHist('Đổi tên slide');stripSig=''}});
  m.addEventListener('contextmenu',e=>{const c=e.target.closest('.ovc');if(!c)return;e.preventDefault();const i=+c.dataset.i;showMenu([{t:'Mở slide',f:()=>{gotoSlide(i);close()}},{t:'Nhân đôi',f:()=>{gotoSlide(i,true);addSlide(true);const s=deck.slides[deck.cur],p=deck.slides[i];s.bx=p.bx+30;s.by=p.by+CH+NH+40;draw()}},{t:'Xóa',f:()=>{delSlide(i);draw()}},'-',{t:'Trình chiếu từ slide này',f:()=>{close();present(i)}}],e.clientX,e.clientY)});
  const key=e=>{if(e.key==='Escape'&&!document.querySelector('.modal')&&!document.querySelector('.mpop'))close()};
  function close(){window.removeEventListener('keydown',key);window.removeEventListener('pointermove',mv);window.removeEventListener('pointerup',up);m.remove();stripSync(true)}
  window.addEventListener('keydown',key);
  document.body.appendChild(m);draw();fit()}

/* ================= Renderer xuất video / GIF (WebGL cho 2.5D & 3D) ================= */
const mmul=(a,b)=>{const o=new Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++){let s=0;for(let k=0;k<4;k++)s+=a[k*4+r]*b[c*4+k];o[c*4+r]=s}return o};
const mT=(x,y,z)=>[1,0,0,0,0,1,0,0,0,0,1,0,x,y,z,1],mS=(x,y,z)=>[x,0,0,0,0,y,0,0,0,0,z,0,0,0,0,1];
const mRx=a=>{a*=Math.PI/180;const c=Math.cos(a),s=Math.sin(a);return[1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1]};
const mRy=a=>{a*=Math.PI/180;const c=Math.cos(a),s=Math.sin(a);return[c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1]};
const mRz=a=>{a*=Math.PI/180;const c=Math.cos(a),s=Math.sin(a);return[c,s,0,0,-s,c,0,0,0,0,1,0,0,0,0,1]};
const mApply=(m,x,y,z)=>({x:m[0]*x+m[4]*y+m[8]*z+m[12],y:m[1]*x+m[5]*y+m[9]*z+m[13],z:m[2]*x+m[6]*y+m[10]*z+m[14]});
function makeGL(W,H){const c=document.createElement('canvas');c.width=W;c.height=H;const o={premultipliedAlpha:true,alpha:true,antialias:true,preserveDrawingBuffer:true};
  const gl=c.getContext('webgl2',o)||c.getContext('webgl',o);if(!gl)return null;
  const sh=(t,src)=>{const s=gl.createShader(t);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s};
  const pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,'attribute vec2 a;attribute vec2 uv;uniform mat4 M;uniform vec2 hf;uniform float P;varying vec2 v;void main(){vec4 q=M*vec4(a,0.,1.);float w=(P-q.z)/P;gl_Position=vec4(q.x/hf.x,-q.y/hf.y,0.,w);v=uv;}'));
  gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,'precision mediump float;uniform sampler2D T;uniform float A;varying vec2 v;void main(){gl_FragColor=texture2D(T,v)*A;}'));gl.linkProgram(pr);gl.useProgram(pr);
  const L={a:gl.getAttribLocation(pr,'a'),uv:gl.getAttribLocation(pr,'uv'),M:gl.getUniformLocation(pr,'M'),hf:gl.getUniformLocation(pr,'hf'),P:gl.getUniformLocation(pr,'P'),A:gl.getUniformLocation(pr,'A')};
  const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.enableVertexAttribArray(L.a);gl.enableVertexAttribArray(L.uv);gl.vertexAttribPointer(L.a,2,gl.FLOAT,false,16,0);gl.vertexAttribPointer(L.uv,2,gl.FLOAT,false,16,8);
  gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);gl.viewport(0,0,W,H);
  const isV2=typeof WebGL2RenderingContext!=='undefined'&&gl instanceof WebGL2RenderingContext;
  const tex=cv=>{const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,cv);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    if(isV2&&cv.width>1){gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR)}else gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);return t};
  const quad=(x0,y0,x1,y1,M,P,t,al)=>{gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([x0,y0,0,0, x1,y0,1,0, x0,y1,0,1, x1,y1,1,1]),gl.DYNAMIC_DRAW);
    gl.uniformMatrix4fv(L.M,false,new Float32Array(M));gl.uniform2f(L.hf,doc.w/2,doc.h/2);gl.uniform1f(L.P,P);gl.uniform1f(L.A,al);gl.bindTexture(gl.TEXTURE_2D,t);gl.drawArrays(gl.TRIANGLE_STRIP,0,4)};
  return{c,gl,tex,quad,del:t=>gl.deleteTexture(t)}}
function cssRgba(col){try{const k=document.createElement('canvas');k.width=k.height=1;const x=k.getContext('2d');x.fillStyle=col;x.fillRect(0,0,1,1);const d=x.getImageData(0,0,1,1).data;return[d[0]/255,d[1]/255,d[2]/255,d[3]/255]}catch(e){return[1,1,1,1]}}
/* ---- GIF encoder ---- */
function gifPalette(hist){const it=[];for(let i=0;i<32768;i++)if(hist[i])it.push({i,n:hist[i],r:i>>10,g:(i>>5)&31,b:i&31});
  let boxes=[it];while(boxes.length<256){let bi=-1,bs=1;boxes.forEach((bx,k)=>{if(bx.length>bs){bs=bx.length;bi=k}});if(bi<0)break;const bx=boxes[bi];
    let r0=31,r1=0,g0=31,g1=0,b0=31,b1=0;bx.forEach(p=>{if(p.r<r0)r0=p.r;if(p.r>r1)r1=p.r;if(p.g<g0)g0=p.g;if(p.g>g1)g1=p.g;if(p.b<b0)b0=p.b;if(p.b>b1)b1=p.b});
    const ch=(r1-r0>=g1-g0&&r1-r0>=b1-b0)?'r':(g1-g0>=b1-b0?'g':'b');bx.sort((p,q)=>p[ch]-q[ch]);let tot=0;bx.forEach(p=>tot+=p.n);let acc=0,cut=1;for(let k=0;k<bx.length-1;k++){acc+=bx[k].n;cut=k+1;if(acc>=tot/2)break}
    boxes.splice(bi,1,bx.slice(0,cut),bx.slice(cut))}
  const pal=new Uint8Array(768);boxes.forEach((bx,k)=>{let n=0,r=0,g=0,b=0;bx.forEach(p=>{n+=p.n;r+=p.r*p.n;g+=p.g*p.n;b+=p.b*p.n});if(n){pal[k*3]=Math.round(r/n*8+4);pal[k*3+1]=Math.round(g/n*8+4);pal[k*3+2]=Math.round(b/n*8+4)}});return{pal,count:boxes.length}}
function gifLzw(idx,out){const MIN=8,clear=256,eoi=257;let size=9,next=258,cur=0,sh=0;const bytes=[];const emit=c=>{cur|=c<<sh;sh+=size;while(sh>=8){bytes.push(cur&255);cur>>>=8;sh-=8}};
  let dict=new Map();emit(clear);let ib=idx[0];
  for(let i=1;i<idx.length;i++){const k=idx[i],key=(ib<<8)|k,c=dict.get(key);
    if(c===undefined){emit(ib);if(next===4096){emit(clear);next=258;size=9;dict=new Map()}else{if(next>=(1<<size))size++;dict.set(key,next++)}ib=k}else ib=c}
  emit(ib);emit(eoi);if(sh>0)bytes.push(cur&255);
  out.push(MIN);for(let p=0;p<bytes.length;p+=255){const n=Math.min(255,bytes.length-p);out.push(n);for(let q=0;q<n;q++)out.push(bytes[p+q])}out.push(0)}
const BAY=[0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5];
function gifMap(d,w,h,lut,pal,pc){const idx=new Uint8Array(w*h);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const p=(y*w+x)*4,t=(BAY[(y&3)*4+(x&3)]-7.5)*.6;
    const r=Math.max(0,Math.min(255,d[p]+t))>>3,g=Math.max(0,Math.min(255,d[p+1]+t))>>3,b=Math.max(0,Math.min(255,d[p+2]+t))>>3,key=(r<<10)|(g<<5)|b;let v=lut[key];
    if(v<0){const R=r*8+4,G=g*8+4,B=b*8+4;let best=1e9,bi=0;for(let k=0;k<pc;k++){const dr=pal[k*3]-R,dg=pal[k*3+1]-G,db=pal[k*3+2]-B,dd=dr*dr+dg*dg+db*db;if(dd<best){best=dd;bi=k}}lut[key]=v=bi}
    idx[y*w+x]=v}return idx}
async function exportGif(o,prog,X){const R=slidesRenderer(o.w,o.h),{total}=tlModel(),N=Math.max(2,Math.round(total*o.fps)+1),w=o.w,h=o.h,ctx=R.out.getContext('2d');
  try{const hist=new Uint32Array(32768),ns=Math.min(14,N);
    for(let k=0;k<ns;k++){R.frame(total*k/Math.max(1,ns-1));const d=ctx.getImageData(0,0,w,h).data;for(let p=0;p<d.length;p+=4*2)hist[((d[p]>>3)<<10)|((d[p+1]>>3)<<5)|(d[p+2]>>3)]++;prog(.05*k/ns,'Chuẩn bị bảng màu…');await new Promise(r=>setTimeout(r,0));if(X.cancel)return null}
    const{pal,count}=gifPalette(hist),lut=new Int16Array(32768).fill(-1),out=[];
    out.push(...[71,73,70,56,57,97],w&255,w>>8,h&255,h>>8,0xF7,0,0);for(let i=0;i<768;i++)out.push(pal[i]);
    out.push(0x21,0xFF,0x0B,...[78,69,84,83,67,65,80,69,50,46,48],3,1,0,0,0);
    for(let k=0;k<N;k++){R.frame(Math.min(total,k/o.fps));const d=ctx.getImageData(0,0,w,h).data,idx=gifMap(d,w,h,lut,pal,count),dl=Math.max(2,Math.round(100*(k+1)/o.fps)-Math.round(100*k/o.fps));
      out.push(0x21,0xF9,4,0x04,dl&255,dl>>8,0,0,0x2C,0,0,0,0,w&255,w>>8,h&255,h>>8,0);gifLzw(idx,out);
      prog(.05+.95*(k+1)/N,'Mã hóa khung '+(k+1)+' / '+N);if(k%3===2)await new Promise(r=>setTimeout(r,0));if(X.cancel)return null}
    out.push(0x3B);return new Blob([new Uint8Array(out)],{type:'image/gif'})}
  finally{R.dispose()}}

/* ---- Video (MP4 / WebM) ---- */
function pickMime(){const c=[['video/mp4;codecs=avc1.640028','mp4'],['video/mp4;codecs=avc1.42E01E','mp4'],['video/mp4','mp4'],['video/webm;codecs=vp9','webm'],['video/webm;codecs=vp8','webm'],['video/webm','webm']];
  for(const[m,e]of c){try{if(window.MediaRecorder&&MediaRecorder.isTypeSupported(m))return{mime:m,ext:e}}catch(x){}}return null}
async function exportVideo(o,prog,X){const mt=pickMime();if(!mt){toast('Trình duyệt này chưa hỗ trợ quay video. Hãy dùng Chrome / Edge, hoặc chọn xuất GIF.');return null}
  const R=slidesRenderer(o.w,o.h),{total}=tlModel();
  try{R.frame(0);prepAll();const stream=R.out.captureStream(o.fps),rec=new MediaRecorder(stream,{mimeType:mt.mime,videoBitsPerSecond:Math.round(Math.min(40e6,Math.max(2e6,o.w*o.h*o.fps*.12)))}),chunks=[];
    rec.ondataavailable=e=>{if(e.data&&e.data.size)chunks.push(e.data)};const done=new Promise(r=>rec.onstop=r);rec.start(500);
    await new Promise(res=>{const t0=performance.now();const step=now=>{if(X.cancel){res();return}const T=(now-t0)/1000;R.frame(Math.min(T,total));prog(Math.min(1,T/total),'Đang quay '+fmtT(Math.min(T,total))+' / '+fmtT(total)+' (giữ tab này mở)');if(T<total+.25)requestAnimationFrame(step);else res()};requestAnimationFrame(step)});
    rec.stop();await done;stream.getTracks().forEach(t=>t.stop());if(X.cancel)return null;return{blob:new Blob(chunks,{type:mt.mime.split(';')[0]}),ext:mt.ext}}
  finally{R.dispose()}
  function prepAll(){tlModel().seg.forEach(g=>{try{R.frame(g.c0)}catch(e){}})}}

/* ---- hộp thoại xuất ---- */
function exportDlg(){if(!deck){toast('Chuyển sang chế độ Slide trước khi xuất video / GIF.');return}syncCur();const{total}=tlModel(),mt=pickMime();const X={cancel:false,busy:false};
  const dimsH=hh=>{const h=Math.min(hh,doc.h),w=Math.round(h*doc.w/doc.h);return{w:w&~1,h:h&~1}};
  const m=modal(`<h2>Xuất bản trình bày</h2><p style="margin-bottom:10px">Tổng thời lượng <b>${fmtT(total)}</b>, gồm ${deck.slides.length} slide với camera và chuyển cảnh như trong khung Camera.</p>
   <div class="chips xt" style="margin-bottom:10px"><button class="chip on" data-f="video">Video ${mt?mt.ext.toUpperCase():''}</button><button class="chip" data-f="gif">GIF động</button><button class="chip" data-f="png">Ảnh PNG từng slide</button><button class="chip" data-f="bravin">Bravin (từng layer)</button></div>
   <div id="xo"></div><div class="xp" hidden><div class="xbar"><i></i></div><span class="ohint"></span></div>
   <div class="row" style="justify-content:flex-end;margin-top:14px"><button class="btn" data-a="x">Đóng</button><button class="btn pri" data-a="go">Xuất</button></div>`);
  m.querySelector('.card').style.cssText+=';width:min(520px,94vw)';let fmt='video';
  const opts=()=>{const xo=m.querySelector('#xo');
    if(fmt==='video')xo.innerHTML=`<div class="row"><label class="fld2">Độ phân giải <select id="xr">${[[doc.h,'Gốc '+dimsH(doc.h).w+'×'+dimsH(doc.h).h],[1080,'1080p'],[720,'720p'],[480,'480p']].filter((x,i)=>i===0||x[0]<doc.h).map(x=>`<option value="${x[0]}">${x[1]}</option>`).join('')}</select></label><label class="fld2">Khung hình/giây <select id="xf"><option>24</option><option selected>30</option><option>60</option></select></label></div>
      <p class="ohint" style="margin-top:8px">${mt?(mt.ext==='mp4'?(/avc1/.test(mt.mime)?'Xuất <b>MP4 (H.264)</b>, mở được trên hầu hết mọi nơi.':'Xuất <b>MP4</b> (mã hóa VP9 do trình duyệt này không có H.264), mở tốt trên Chrome, Edge, VLC (QuickTime có thể không mở được).'):'Trình duyệt này chỉ quay được <b>WebM</b>. Dùng Chrome / Edge / Safari bản mới để có MP4.'):'Trình duyệt này không hỗ trợ quay video, hãy dùng GIF.'} Video được quay theo thời gian thực nên mất đúng bằng thời lượng (${fmtT(total)}), giữ tab này mở trong lúc xuất. Chưa có âm thanh.</p>`;
    else if(fmt==='gif')xo.innerHTML=`<div class="row"><label class="fld2">Chiều rộng <select id="xr"><option value="320">320 px</option><option value="480" selected>480 px</option><option value="640">640 px</option><option value="800">800 px</option></select></label><label class="fld2">Khung hình/giây <select id="xf"><option>10</option><option selected>15</option><option>20</option></select></label></div><p class="ohint" style="margin-top:8px">GIF chỉ có 256 màu và nặng hơn video nhiều, hợp để chia sẻ nhanh các đoạn ngắn. Muốn chất lượng tốt hãy chọn Video.</p>`;
    else if(fmt==='png')xo.innerHTML=`<p class="ohint">Xuất mỗi slide thành một ảnh PNG (khung đầu, không gồm chuyển động camera).</p>`;
    else xo.innerHTML=`<p class="ohint">Gửi từng layer sang Bravin thành track riêng, mỗi slide nối tiếp nhau trên timeline, kèm thông tin camera và chuyển cảnh.</p>`;
    m.querySelector('[data-a="go"]').textContent=fmt==='bravin'?'Mở hộp Bravin…':'Xuất'};
  opts();
  m.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;
    if(b.dataset.f&&!X.busy){fmt=b.dataset.f;m.querySelectorAll('.xt .chip').forEach(c=>c.classList.toggle('on',c===b));opts();return}
    if(b.dataset.a==='x'){X.cancel=true;m.remove();return}
    if(b.dataset.a!=='go'||X.busy)return;
    if(fmt==='png'){m.remove();exportSlidesPng();return}if(fmt==='bravin'){m.remove();bravinDialog();return}
    X.busy=true;X.cancel=false;const xp=m.querySelector('.xp'),bar=xp.querySelector('i'),tx=xp.querySelector('span');xp.hidden=false;b.disabled=true;b.textContent='Đang xuất…';
    const prog=(p,t)=>{bar.style.width=Math.round(p*100)+'%';tx.textContent=t||''};
    try{let blob=null,ext='';
      if(fmt==='video'){const d=dimsH(+m.querySelector('#xr').value),fps=+m.querySelector('#xf').value;const r=await exportVideo({w:d.w,h:d.h,fps},prog,X);if(r){blob=r.blob;ext=r.ext}}
      else{const w=Math.min(+m.querySelector('#xr').value,doc.w)&~1,h=Math.round(w*doc.h/doc.w)&~1,fps=+m.querySelector('#xf').value;blob=await exportGif({w,h,fps},prog,X);ext='gif'}
      if(blob&&!X.cancel){prog(1,'Đã xong, đang lưu…');const ok=await saveFile(fname('.'+ext),blob);if(ok){m.remove();return}}
      else if(X.cancel){}
    }catch(err){toast('Không xuất được: '+(err&&err.message||'lỗi'));console.error(err)}
    X.busy=false;b.disabled=false;b.textContent='Xuất';xp.hidden=true});
  const mo=new MutationObserver(()=>{if(!document.body.contains(m)){X.cancel=true;mo.disconnect()}});mo.observe(document.body,{childList:true})}

/* ================= Không gian: nhìn tự do + lướt (bay) trong không gian 3D ================= */
const camMatInv=c=>{const g=k=>c[k]??CAMD[k];return mmul(mS(1/g('zoom'),1/g('zoom'),1),mmul(mRz(-g('roll')),mmul(mRy(-g('yaw')),mmul(mRx(g('pitch')),mT(-g('x'),-g('y'),-g('z'))))))};
function spGLInit(c){const o={premultipliedAlpha:true,alpha:false,antialias:true};const gl=c.getContext('webgl',o)||c.getContext('experimental-webgl',o);if(!gl)return null;
  const mk=(vs,fs)=>{const p=gl.createProgram();[[gl.VERTEX_SHADER,vs],[gl.FRAGMENT_SHADER,fs]].forEach(([t,src])=>{const s=gl.createShader(t);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));gl.attachShader(p,s)});gl.linkProgram(p);return p};
  const pt=mk('attribute vec4 p;attribute vec2 uv;varying vec2 v;void main(){gl_Position=p;v=uv;}','precision mediump float;uniform sampler2D T;uniform float A;varying vec2 v;void main(){gl_FragColor=texture2D(T,v)*A;}');
  const pl=mk('attribute vec4 p;void main(){gl_Position=p;}','precision mediump float;uniform vec4 C;void main(){gl_FragColor=C;}');
  gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);
  const buf=gl.createBuffer();
  const tex=cv=>{const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,cv);[[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE],[gl.TEXTURE_MIN_FILTER,gl.LINEAR],[gl.TEXTURE_MAG_FILTER,gl.LINEAR]].forEach(([a,b])=>gl.texParameteri(gl.TEXTURE_2D,a,b));return t};
  const quad=(v4,t,al)=>{gl.useProgram(pt);gl.bindBuffer(gl.ARRAY_BUFFER,buf);const d=[];for(let i=0;i<4;i++)d.push(...v4[i].c,...v4[i].uv);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(d),gl.DYNAMIC_DRAW);
    const a=gl.getAttribLocation(pt,'p'),u=gl.getAttribLocation(pt,'uv');gl.enableVertexAttribArray(a);gl.enableVertexAttribArray(u);gl.vertexAttribPointer(a,4,gl.FLOAT,false,24,0);gl.vertexAttribPointer(u,2,gl.FLOAT,false,24,16);
    gl.uniform1f(gl.getUniformLocation(pt,'A'),al);gl.bindTexture(gl.TEXTURE_2D,t);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);gl.disableVertexAttribArray(u)};
  const lines=(segs,col)=>{if(!segs.length)return;gl.useProgram(pl);gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(segs.flat()),gl.DYNAMIC_DRAW);const a=gl.getAttribLocation(pl,'p');gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,4,gl.FLOAT,false,16,0);
    gl.uniform4f(gl.getUniformLocation(pl,'C'),col[0]*col[3],col[1]*col[3],col[2]*col[3],col[3]);gl.drawArrays(gl.LINES,0,segs.length)};
  return{gl,tex,quad,lines}}
function spView(name){const sp=cs.sp,v={front:[0,0],top:[0,-89],side:[-90,0],diag:[-32,-18]}[name];if(!v)return;sp.yaw=v[0];sp.pitch=v[1];spDraw()}
function spCamFromView(){const sp=cs.sp,R=mmul(mRx(-sp.pitch),mRy(sp.yaw)),p=mApply(R,-sp.t[0],-sp.t[1],-sp.t[2]);return{x:Math.round(p.x),y:Math.round(p.y),z:Math.round(p.z),yaw:Math.round(sp.yaw*10)/10,pitch:Math.round(sp.pitch*10)/10,roll:0,zoom:1,persp:Math.round(sp.D)}}
function spSetKf(k){if(cs.at&&cs.at.g.i!==deck.cur)stGo(cs.at.g.i);const s=deck.slides[deck.cur],c=spCamFromView(),m=s.cam.mode;
  if(m==='2.5d'){c.yaw=clampv(c.yaw,-15,15);c.pitch=clampv(c.pitch,-15,15);c.z=0;c.roll=0}
  Object.keys(CAMR).forEach(n=>{c[n]=clampv(c[n],CAMR[n][0],CAMR[n][1])});const pose={...CAMD,...c};
  if(k==='start'||k==='end'){s.cam[k]=pose;camKf=k}
  else if(k==='sel'){const o=curKf(s);Object.keys(CAMD).forEach(n=>{o[n]=pose[n]})}
  else{const g=tlModel().seg[deck.cur],T=Math.max(g.c0,Math.min(g.c1,cs.T));if(T<=g.c0+.05||T>=g.c1-.05){toast('Đưa đầu phát vào giữa slide (kéo thước thời gian) rồi bấm thêm key.');return}kfAdd(T,pose)}
  camCommit('Đặt camera từ góc nhìn');stSide();stTop();tlRender();buildProps0();spDraw();toast(k==='new'?'Đã thêm key camera tại đầu phát theo góc nhìn hiện tại.':'Đã gán camera theo góc nhìn hiện tại.')}
function stView(v){if(!cs)return;const s=deck.slides[deck.cur];
  if(v==='space'&&s.cam.mode==='2d'){toast('Slide đang ở 2D. Chuyển sang 2.5D hoặc 3D để dùng chế độ Không gian.');return}
  if(cs.playing)stStop();cs.view=v;
  [...cs.area.children].forEach(w=>{if(w.dataset&&w.dataset.sid)w.remove()});
  if(cs.sp&&cs.sp.c){const d=v==='space'?'':'none';cs.sp.c.style.display=cs.sp.lbl.style.display=cs.sp.bar.style.display=d;if(v==='space'&&cs.sp.g){cs.sp.prepSid=null;spDraw();cs.view='space';stTop();stSide();return}}
  if(v==='space'){const c=document.createElement('canvas');c.className='spc';cs.area.appendChild(c);const lbl=document.createElement('div');lbl.className='splb';cs.area.appendChild(lbl);
    const bar=document.createElement('div');bar.className='spbar';bar.innerHTML=`<span class="ohint">Góc nhìn:</span><button class="chip" data-sp="front">Trước</button><button class="chip" data-sp="top">Trên</button><button class="chip" data-sp="side">Bên</button><button class="chip" data-sp="diag">Chéo</button><span class="sep"></span><button class="btn" data-sp="setstart" title="Đặt điểm đầu camera đúng tại góc nhìn này">◆ Gán làm điểm đầu</button><button class="btn" data-sp="setend" title="Đặt điểm cuối camera đúng tại góc nhìn này">◆ Gán làm điểm cuối</button><button class="btn" data-sp="addkey" title="Thêm key camera tại vị trí đầu phát, theo góc nhìn này">◆+ Key tại đầu phát</button><button class="btn" data-sp="setsel" title="Gán góc nhìn này vào key đang chọn">Gán vào key đang chọn</button><button class="btn pri" data-sp="back">Nhìn qua camera</button>`;cs.area.appendChild(bar);
    const old=cs.sp||{};cs.sp={c,lbl,bar,g:null,yaw:old.yaw??-32,pitch:old.pitch??-18,D:2600,k:old.k??.3,t:old.t||[0,0,0],info:null,prepSid:null};
    try{cs.sp.g=spGLInit(c)}catch(e){cs.sp.g=null}
    if(!cs.sp.g){toast('Trình duyệt không bật được WebGL nên không dùng được chế độ Không gian.');cs.view='cam';c.remove();lbl.remove();bar.remove();cs.sp.c=null}
    else spDraw()}
  if(cs.view==='cam')stShow(cs.T);stTop();stSide()}
/* kéo / cuộn trong khung Không gian */
function spReq(){const sp=cs&&cs.sp;if(!sp||sp.rq)return;sp.rq=requestAnimationFrame(()=>{sp.rq=0;if(cs&&cs.sp===sp&&cs.view==='space')spDraw()})}
function spWheel(e){const sp=cs.sp;sp.k=clampv(sp.k*(e.deltaY<0?1.1:.91),.06,2.5);spReq()}
function spAct(a){if(a==='front'||a==='top'||a==='side'||a==='diag')spView(a);else if(a==='setstart')spSetKf('start');else if(a==='setend')spSetKf('end');else if(a==='addkey')spSetKf('new');else if(a==='setsel')spSetKf('sel');else if(a==='back')stView('cam')}
/* phím lướt: W A S D Q E (Shift = nhanh) */
function stFlyKey(e,down){if(!cs)return false;const k=e.key.toLowerCase();if(!/^[wasdqe]$/.test(k)||e.ctrlKey||e.metaKey||e.altKey)return false;
  const t=e.target;if(t&&/INPUT|SELECT|TEXTAREA/.test(t.tagName)&&t.type!=='range')return false;
  e.preventDefault();e.stopImmediatePropagation();if(down){cs.keys.add(k);cs.fast=e.shiftKey;if(!cs.flyRaf)stFlyLoop()}else cs.keys.delete(k);return true}
function stFlyLoop(){let last=performance.now();cs.fly=false;
  const step=now=>{if(!cs){return}if(!cs.keys.size){cs.flyRaf=0;if(cs.fly){camCommit('Lướt camera');cs.fly=false}return}
    const dt=Math.min(.05,(now-last)/1000);last=now;const k=cs.keys,sp=(cs.fast?3:1)*dt,f=n=>k.has(n)?1:0;
    if(cs.view==='space'&&cs.sp&&cs.sp.g){const S=cs.sp,inv=mmul(mRy(-S.yaw),mRx(S.pitch)),v=700*sp,d=mApply(inv,(f('d')-f('a'))*v,(f('q')-f('e'))*v,(f('s')-f('w'))*v);S.t=[S.t[0]+d.x,S.t[1]+d.y,S.t[2]+d.z];spDraw()}
    else{const s=deck.slides[deck.cur],m=s.cam.mode,v=420*sp;const c=stEnsureKey();
      c.x=clampv((c.x||0)+(f('a')-f('d'))*v,CAMR.x[0],CAMR.x[1]);c.y=clampv((c.y||0)+(f('e')-f('q'))*v,CAMR.y[0],CAMR.y[1]);
      if(m==='3d')c.z=clampv((c.z||0)+(f('w')-f('s'))*v,CAMR.z[0],CAMR.z[1]);else c.zoom=clampv((c.zoom||1)*Math.exp((f('w')-f('s'))*sp*.8),.3,3);
      stShow(kfT(deck.cur,camKf));stSideSync();syncCamSliders()}
    cs.fly=true;cs.flyRaf=requestAnimationFrame(step)};cs.flyRaf=requestAnimationFrame(step)}
function stSideSync(){if(!cs)return;const s=deck.slides[deck.cur],kf=curKf(s);cs.side.querySelectorAll('input[data-k]').forEach(i=>{const k=i.dataset.k,v=kf[k]??CAMD[k];i.value=v;const o=i.nextElementSibling;if(o)o.textContent=(Math.round(v*100)/100)+CAMR[k][3]})}

/* ================= Chuyển động layer + Chuyển thành slide ================= */
const AN_IN=[['none','Không'],['fade','Hiện dần'],['slideL','Trượt từ trái'],['slideR','Trượt từ phải'],['slideU','Trượt từ trên'],['slideD','Trượt từ dưới'],['zoom','Phóng vào'],['pop','Nảy'],['rise','Bay từ chiều sâu'],['flip','Lật 3D'],['spin','Xoay vào'],['drop','Rơi xuống']];
const AN_LOOP=[['none','Không'],['float','Trôi nổi'],['pulse','Nhịp đập'],['sway','Lắc 3D'],['spin','Xoay chậm'],['bob','Nhấp nhô chiều sâu']];
const AN_REST={op:1,dx:0,dy:0,dz:0,sc:1,rot:0,ax:0,ay:0};
const eob=x=>{const c=1.70158,k=c+1;return 1+k*Math.pow(x-1,3)+c*Math.pow(x-1,2)};
const ebounce=x=>{const n=7.5625,d=2.75;if(x<1/d)return n*x*x;if(x<2/d){x-=1.5/d;return n*x*x+.75}if(x<2.5/d){x-=2.25/d;return n*x*x+.9375}x-=2.625/d;return n*x*x+.984375};
function animShape(o,type,q){const W=doc.w,H=doc.h,e=1-q;
  switch(type){
    case'fade':o.op*=e;break;
    case'slideL':o.dx-=q*W*.3;o.op*=Math.min(1,e*2.2);break;
    case'slideR':o.dx+=q*W*.3;o.op*=Math.min(1,e*2.2);break;
    case'slideU':o.dy-=q*H*.35;o.op*=Math.min(1,e*2.2);break;
    case'slideD':o.dy+=q*H*.35;o.op*=Math.min(1,e*2.2);break;
    case'zoom':o.sc*=1-.6*q;o.op*=Math.min(1,e*2.2);break;
    case'pop':o.sc*=Math.max(.001,eob(e));o.op*=Math.min(1,e*5);break;
    case'rise':o.dz-=q*700;o.op*=Math.min(1,e*2.2);break;
    case'flip':o.ay+=90*q;o.op*=Math.min(1,e*2.2);break;
    case'spin':o.rot-=180*q;o.sc*=1-.5*q;o.op*=Math.min(1,e*2.2);break;
    case'drop':o.dy-=(1-ebounce(e))*H*.7;o.op*=Math.min(1,e*5);break}}
function animAt(l,t,dur){const a=l.anim;if(!a)return AN_REST;const o={op:1,dx:0,dy:0,dz:0,sc:1,rot:0,ax:0,ay:0};
  if(a.in&&a.in!=='none'){const p=clampv((t-(a.inD||0))/Math.max(.05,a.inL||.6),0,1);animShape(o,a.in,1-ease(a.inE||'out',p))}
  if(a.out&&a.out!=='none'){const st=dur-(a.outD||0)-(a.outL||.5),p=clampv((t-st)/Math.max(.05,a.outL||.5),0,1);animShape(o,a.out,ease(a.outE||'in',p))}
  if(a.loop&&a.loop!=='none'){const w=t*(a.loopS||1)*2;
    switch(a.loop){case'float':o.dy-=Math.sin(w*.8)*14;o.dx+=Math.sin(w*.5)*6;break;case'pulse':o.sc*=1+.045*Math.sin(w*1.6);break;case'sway':o.ay+=10*Math.sin(w*.9);o.ax+=4*Math.sin(w*.7);break;case'spin':o.rot+=t*28*(a.loopS||1);break;case'bob':o.dz+=Math.sin(w*.9)*70;break}}
  return o}
const hasAnim=s=>withSlide(s,()=>exportOrder().some(l=>l.anim&&!l.clipTo&&effVis(l)));
const ANDEF=()=>({in:'none',inD:0,inL:.6,inE:'out',out:'none',outD:0,outL:.5,outE:'in',loop:'none',loopS:1});
function applyMotion(s,type){withSlide(s,()=>{const L=exportOrder().filter(l=>!l.clipTo),n=L.length,st=Math.min(.3,Math.max(.06,(s.dur*.5)/Math.max(1,n)));
  L.forEach((l,i)=>{if(type==='none'){delete l.anim;return}const a=l.anim||ANDEF();a.in=type;a.inD=Math.round((.1+i*st)*100)/100;a.inL=.6;a.inE='out';l.anim=a})})}
/* chuẩn hóa anim: bỏ nếu tất cả đều 'none' */
const tidyAnim=l=>{const a=l.anim;if(a&&a.in==='none'&&a.out==='none'&&a.loop==='none')delete l.anim};

/* ---- Scene CSS (preview, trình chiếu): mỗi layer là một tấm, có chuyển động theo thời gian ---- */
function makeScene(s){
  const mode=s.cam.mode,anim=hasAnim(s),planes=mode!=='2d'||anim,dur=s.dur,wrap=document.createElement('div');wrap.className='scn';wrap.style.width=doc.w+'px';wrap.style.height=doc.h+'px';
  const persp=document.createElement('div');persp.className='scn-p';const scene=document.createElement('div');scene.className='scn-s';persp.appendChild(scene);wrap.appendChild(persp);
  let items=[];
  if(!planes){const f=withSlide(s,()=>flatten(false));f.className='scn-f';scene.appendChild(f)}
  else{items=withSlide(s,()=>{const out=[];exportOrder().forEach(l=>{if(l.clipTo||!effVis(l))return;const b=bakeLeaf(l,{});if(b)out.push({b,l})});return out});
    if(mode==='2d'){if(s.bg)wrap.style.background=s.bg}
    else if(s.bg){const minZ=Math.min(0,...items.map(i=>i.l.depth||0)),bg=document.createElement('div');bg.className='scn-bg';const K=2.4;bg.style.cssText=`left:${-doc.w*(K-1)/2}px;top:${-doc.h*(K-1)/2}px;width:${doc.w*K}px;height:${doc.h*K}px;background:${s.bg};transform:translateZ(${minZ-2}px)`;scene.appendChild(bg)}
    items.forEach(({b})=>{const c=b.c;c.className='scn-l';c.style.cssText=`left:${b.x0}px;top:${b.y0}px;width:${b.w}px;height:${b.h}px;transform-origin:${doc.w/2-b.x0}px ${doc.h/2-b.y0}px;${b.blend!=='normal'&&BLEND[b.blend]&&BLEND[b.blend]!=='lighter'?'mix-blend-mode:'+b.blend:''}`;scene.appendChild(c)})}
  const place=t=>{const ortho=mode==='2d';items.forEach(({b,l})=>{const a=t==null?AN_REST:animAt(l,t,dur),z=ortho?0:(l.depth||0),tx=ortho?0:(l.tiltX||0),ty=ortho?0:(l.tiltY||0),cx=b.x0+b.w/2-doc.w/2,cy=b.y0+b.h/2-doc.h/2;
    b.c.style.opacity=(b.op==null?1:b.op)*a.op;
    b.c.style.transform=`translate3d(${a.dx}px,${a.dy}px,${z+(ortho?0:a.dz)}px) rotateX(${tx+a.ax}deg) rotateY(${ty}deg) translate(${cx}px,${cy}px) rotateZ(${a.rot}deg) rotateY(${a.ay}deg) scale(${a.sc}) translate(${-cx}px,${-cy}px)`})};
  const set=(c,t)=>{c=c||{};const g=k=>c[k]??CAMD[k];
    if(mode==='2d'){persp.style.perspective='none';scene.style.transform=`translate(${g('x')}px,${g('y')}px) scale(${g('zoom')})`}
    else{persp.style.perspective=g('persp')+'px';scene.style.transform=`translate3d(${g('x')}px,${g('y')}px,${g('z')}px) rotateX(${-g('pitch')}deg) rotateY(${g('yaw')}deg) rotateZ(${g('roll')}deg) scale(${g('zoom')})`}
    if(planes)place(t)};
  set(s.cam.start);return{wrap,set,mode,s}}
function playCam(sc,done){const s=sc.s,dur=Math.max(.3,s.dur)*1000,t0=performance.now();let stop=false;
  const step=now=>{if(stop)return;const el=Math.min(dur,now-t0),t=el/dur;sc.set(camAtP(s,t),el/1000);if(t<1)requestAnimationFrame(step);else if(done)done()};requestAnimationFrame(step);return()=>{stop=true}}

/* ---- Renderer xuất video / GIF (WebGL), có chuyển động layer ---- */
function slidesRenderer(W,H){
  const out=document.createElement('canvas');out.width=W;out.height=H;const o=out.getContext('2d');
  const tA=document.createElement('canvas'),tB=document.createElement('canvas');[tA,tB].forEach(c=>{c.width=W;c.height=H});
  let G=null,glFail=false;const getG=()=>{if(!G&&!glFail){try{G=makeGL(W,H)}catch(e){G=null}if(!G)glFail=true}return G};
  const prep=new Map();
  const prepare=s=>{let p=prep.get(s.id);if(p)return p;
    if(s.cam.mode==='2d'&&!hasAnim(s)){p={flat:withSlide(s,()=>flatten(false))}}
    else{const info=withSlide(s,()=>{const r=[];exportOrder().forEach(l=>{if(l.clipTo||!effVis(l))return;const b=bakeLeaf(l,{});if(b)r.push({b,l})});return r});
      const g=getG();p={info,minZ:Math.min(0,...info.map(i=>i.l.depth||0)),g};
      if(g){info.forEach(i=>{i.t=g.tex(i.b.c)});if(s.bg&&s.cam.mode!=='2d'){const k=document.createElement('canvas');k.width=k.height=1;const x=k.getContext('2d');x.fillStyle=s.bg;x.fillRect(0,0,1,1);p.bgT=g.tex(k)}}}
    prep.set(s.id,p);return p};
  const render=(s,cam,dst,tau)=>{const p=prepare(s),x=dst.getContext('2d'),k=W/doc.w;x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,W,H);
    if(p.flat){x.fillStyle=s.bg||'#ffffff';x.fillRect(0,0,W,H);const g=n=>cam[n]??CAMD[n];x.save();x.translate(W/2+g('x')*k,H/2+g('y')*k);x.scale(g('zoom')*k,g('zoom')*k);x.drawImage(p.flat,-doc.w/2,-doc.h/2);x.restore();return}
    const g=p.g;if(!g){x.fillStyle=s.bg||'#fff';x.fillRect(0,0,W,H);return}
    const gl=g.gl,c=cam,v=n=>c[n]??CAMD[n],bg=s.bg?cssRgba(s.bg):[1,1,1,1],ortho=s.cam.mode==='2d';
    gl.clearColor(bg[0],bg[1],bg[2],1);gl.clear(gl.COLOR_BUFFER_BIT);
    const S=ortho?mmul(mT(v('x'),v('y'),0),mS(v('zoom'),v('zoom'),1)):mmul(mmul(mmul(mmul(mT(v('x'),v('y'),v('z')),mRx(-v('pitch'))),mRy(v('yaw'))),mRz(v('roll'))),mS(v('zoom'),v('zoom'),1)),P=ortho?1e7:v('persp'),cx=doc.w/2,cy=doc.h/2;
    if(p.bgT){const K=2.4;g.quad(-cx*K,-cy*K,cx*K,cy*K,mmul(S,mT(0,0,p.minZ-2)),P,p.bgT,1)}
    const items=p.info.map(i=>{const l=i.l,b=i.b,a=tau==null?AN_REST:animAt(l,tau,s.dur),z=ortho?0:(l.depth||0),tx=ortho?0:(l.tiltX||0),ty=ortho?0:(l.tiltY||0),lx=b.x0+b.w/2-cx,ly=b.y0+b.h/2-cy;
      const M=mmul(S,mmul(mT(a.dx,a.dy,z+(ortho?0:a.dz)),mmul(mRx(tx+a.ax),mmul(mRy(ty),mmul(mT(lx,ly,0),mmul(mRz(a.rot),mmul(mRy(a.ay),mmul(mS(a.sc,a.sc,1),mT(-lx,-ly,0)))))))));
      return{i,M,a,z:ortho?0:mApply(M,0,0,0).z}}).sort((p1,p2)=>p1.z-p2.z);
    items.forEach(({i,M,a})=>{const b=i.b;if(a.op<=.001)return;g.quad(b.x0-cx,b.y0-cy,b.x0+b.w-cx,b.y0+b.h-cy,M,P,i.t,(b.op==null?1:b.op)*a.op)});
    x.drawImage(g.c,0,0,W,H)};
  const put=(src,tp)=>{o.save();o.globalAlpha=tp.op;o.translate(W/2+tp.tx*W,H/2);if(tp.r)o.scale(Math.max(.001,Math.cos(tp.r*Math.PI/180)),1);o.scale(tp.s,tp.s);o.drawImage(src,-W/2,-H/2,W,H);o.restore()};
  const frame=T=>{const at=tlAt(T);o.setTransform(1,0,0,1,0,0);o.globalAlpha=1;o.fillStyle='#000';o.fillRect(0,0,W,H);
    if(at.ph==='tr'&&at.prev){const tp=transP(at.g.s.trans.type,at.p);render(at.prev.s,at.prev.s.cam.end,tA,at.prev.s.dur);render(at.g.s,at.g.s.cam.start,tB,0);put(tA,tp.o);put(tB,tp.n)}
    else{render(at.g.s,camAtP(at.g.s,at.ph==='tr'?0:at.p),tA,at.ph==='tr'?0:at.p*at.g.s.dur);put(tA,{op:1,tx:0,s:1,r:0})}
    return out};
  return{out,frame,glOk:()=>!glFail,dispose(){prep.forEach(p=>{if(p.g){p.info.forEach(i=>i.t&&p.g.del(i.t));if(p.bgT)p.g.del(p.bgT)}});prep.clear();if(G&&G.gl.getExtension('WEBGL_lose_context'))G.gl.getExtension('WEBGL_lose_context').loseContext()}}}

/* ---- Không gian: layer chọn / kéo, có chuyển động ---- */
function spPrep(){const sp=cs.sp;if(sp.prepSid===deck.slides[deck.cur].id)return;const s=deck.slides[deck.cur];
  if(sp.info)sp.info.forEach(i=>i.t&&sp.g.gl.deleteTexture(i.t));
  sp.info=withSlide(s,()=>{const r=[];exportOrder().forEach(l=>{if(l.clipTo||!effVis(l))return;const b=bakeLeaf(l,{});if(b)r.push({b,l,ox:0,oy:0})});return r});
  sp.info.forEach(i=>{i.t=sp.g.tex(i.b.c)});
  const k=document.createElement('canvas');k.width=k.height=1;const x=k.getContext('2d');x.fillStyle=s.bg||'#20212b';x.fillRect(0,0,1,1);sp.bgT=sp.g.tex(k);sp.prepSid=s.id}
function spTau(){const s=deck.slides[deck.cur];return cs.at&&cs.at.g.i===deck.cur?(cs.at.ph==='cam'?cs.at.p*s.dur:0):null}
function spDraw(){const sp=cs&&cs.sp;if(!sp||!sp.g)return;spPrep();const{gl}=sp.g,c=sp.c,W=c.clientWidth,H=c.clientHeight;if(!W||!H)return;if(c.width!==W||c.height!==H){c.width=W;c.height=H}
  gl.viewport(0,0,W,H);gl.clearColor(.027,.03,.047,1);gl.clear(gl.COLOR_BUFFER_BIT);
  const s=deck.slides[deck.cur],tau=spTau(),Vf=mmul(mRx(-sp.pitch),mmul(mRy(sp.yaw),mT(-sp.t[0],-sp.t[1],-sp.t[2]))),hx=W/2/sp.k,hy=H/2/sp.k,D=sp.D,cx=doc.w/2,cy=doc.h/2;
  const clipV=(M,x,y,z)=>{const q=mApply(M,x,y,z);return[q.x/hx,-q.y/hy,0,(D-q.z)/D]};
  const W2C=(x,y,z)=>clipV(Vf,x,y,z);
  const scr=(x,y,z)=>{const q=W2C(x,y,z);if(q[3]<=.02)return null;return{x:(q[0]/q[3]+1)/2*W,y:(1-q[1]/q[3])/2*H}};
  const fy=cy+40,gs=[];for(let z=-2600;z<=1800;z+=200){gs.push(W2C(-2600,fy,z),W2C(2600,fy,z))}for(let x=-2600;x<=2600;x+=200){gs.push(W2C(x,fy,-2600),W2C(x,fy,1800))}
  sp.g.lines(gs,[.55,.6,.8,.16]);
  sp.g.lines([W2C(0,0,0),W2C(420,0,0)],[1,.3,.3,1]);sp.g.lines([W2C(0,0,0),W2C(0,420,0)],[.35,.9,.45,1]);sp.g.lines([W2C(0,0,0),W2C(0,0,420)],[.35,.6,1,1]);
  const bgM=mmul(Vf,mT(0,0,(sp.info.length?Math.min(0,...sp.info.map(i=>i.l.depth||0)):0)-3));
  sp.g.quad([[-cx,-cy,0,0],[cx,-cy,1,0],[-cx,cy,0,1],[cx,cy,1,1]].map(([x,y,u,v])=>({c:clipV(bgM,x,y,0),uv:[u,v]})),sp.bgT,.55);
  const items=sp.info.map(i=>{const l=i.l,b=i.b,a=tau==null?AN_REST:animAt(l,tau,s.dur),lx=b.x0+b.w/2-cx,ly=b.y0+b.h/2-cy;
    const M=mmul(Vf,mmul(mT(a.dx+i.ox,a.dy+i.oy,(l.depth||0)+a.dz),mmul(mRx((l.tiltX||0)+a.ax),mmul(mRy(l.tiltY||0),mmul(mT(lx,ly,0),mmul(mRz(a.rot),mmul(mRy(a.ay),mmul(mS(a.sc,a.sc,1),mT(-lx,-ly,0)))))))));
    return{i,M,a,z:mApply(M,0,0,0).z}}).sort((p,q)=>p.z-q.z);
  const out=[],sel=[];sp.hit=[];
  items.forEach(({i,M,a})=>{const b=i.b,x0=b.x0-cx,y0=b.y0-cy,x1=x0+b.w,y1=y0+b.h;if(a.op>.001)sp.g.quad([[x0,y0,0,0],[x1,y0,1,0],[x0,y1,0,1],[x1,y1,1,1]].map(([x,y,u,v])=>({c:clipV(M,x,y,0),uv:[u,v]})),i.t,(b.op==null?1:b.op)*a.op);
    const P=[[x0,y0],[x1,y0],[x1,y1],[x0,y1]].map(([x,y])=>clipV(M,x,y,0)),tgt=i.l.id===cs.ls?sel:out;for(let k=0;k<4;k++)tgt.push(P[k],P[(k+1)%4]);
    const poly=P.map(q=>q[3]>.02?{x:(q[0]/q[3]+1)/2*W,y:(1-q[1]/q[3])/2*H}:null);if(poly.every(Boolean))sp.hit.push({i,poly})});
  sp.hit.reverse();
  sp.g.lines(out,[1,1,1,.28]);if(sel.length)sp.g.lines(sel,[1,.83,.23,1]);
  const fr=[[-cx,-cy],[cx,-cy],[cx,cy],[-cx,cy]],fo=[];for(let k=0;k<4;k++)fo.push(W2C(fr[k][0],fr[k][1],0),W2C(fr[(k+1)%4][0],fr[(k+1)%4][1],0));sp.g.lines(fo,[1,1,1,.7]);
  const lbl=[];
  const gizmo=(cam,col,name)=>{const Si=camMatInv(cam),P=cam.persp??CAMD.persp,e=mApply(Si,0,0,P),cs4=[[-cx,-cy],[cx,-cy],[cx,cy],[-cx,cy]].map(([x,y])=>mApply(Si,x,y,0)),L=[];
    cs4.forEach((q,k)=>{L.push(W2C(e.x,e.y,e.z),W2C(q.x,q.y,q.z),W2C(q.x,q.y,q.z),W2C(cs4[(k+1)%4].x,cs4[(k+1)%4].y,cs4[(k+1)%4].z))});
    const tm={x:(cs4[0].x+cs4[1].x)/2,y:(cs4[0].y+cs4[1].y)/2,z:(cs4[0].z+cs4[1].z)/2},up=mApply(Si,0,-cy*1.25,0);L.push(W2C(tm.x,tm.y,tm.z),W2C(up.x,up.y,up.z));
    sp.g.lines(L,col);const p=scr(e.x,e.y,e.z);if(p)lbl.push({...p,name,col})};
  const N=40,path=[];for(let q=0;q<=N;q++){const cm=camAtP(s,q/N);path.push(mApply(camMatInv(cm),0,0,(cm.persp??CAMD.persp)))}
  const pl=[];for(let q=0;q<N;q++)pl.push(W2C(path[q].x,path[q].y,path[q].z),W2C(path[q+1].x,path[q+1].y,path[q+1].z));sp.g.lines(pl,[1,.83,.23,.95]);
  gizmo(s.cam.start,[.3,.9,.5,1],'Đầu');camKeys(s).forEach((k,n)=>{if(k.mid)gizmo(k.c,[.45,.7,1,1],'Key '+n)});gizmo(s.cam.end,[1,.31,.6,1],'Cuối');
  if(cs.at&&cs.at.g.i===deck.cur&&cs.at.ph==='cam'&&cs.at.p>.001&&cs.at.p<.999)gizmo(camAtP(s,cs.at.p),[1,1,1,.9],'Đang xem');
  const L=sp.lbl,ax=(x,y,z,col,t)=>{const p=scr(x,y,z);return p?`<span class="ax" style="left:${p.x}px;top:${p.y}px;color:${col}">${t}</span>`:''};
  L.innerHTML=lbl.map(l=>`<span style="left:${clampv(l.x,28,W-28)}px;top:${clampv(l.y,26,H-6)}px;color:rgb(${l.col.slice(0,3).map(v=>Math.round(v*255)).join(',')})">${l.name}</span>`).join('')+ax(420,0,0,'#ff6b6b','X')+ax(0,420,0,'#5fe58a','Y')+ax(0,0,420,'#5f9bff','Z')}
const inPoly=(p,pt)=>{let c=false;for(let i=0,j=p.length-1;i<p.length;j=i++){if(((p[i].y>pt.y)!==(p[j].y>pt.y))&&(pt.x<(p[j].x-p[i].x)*(pt.y-p[i].y)/(p[j].y-p[i].y)+p[i].x))c=!c}return c};
function spDown(e){const sp=cs.sp,r=sp.c.getBoundingClientRect(),pt={x:e.clientX-r.left,y:e.clientY-r.top};
  const pan=e.shiftKey||e.button===1||e.button===2;let hit=null;if(!pan&&sp.hit)hit=sp.hit.find(h=>inPoly(h.poly,pt));
  sp.dr={x:e.clientX,y:e.clientY,pan};
  if(hit){sp.dr.item=hit.i;sp.dr.alt=e.altKey;sp.dr.moved=false;if(cs.ls!==hit.i.l.id||cs.tab!=='layer'){cs.ls=hit.i.l.id;cs.tab='layer';stSide();spDraw()}}
  cs.area.setPointerCapture(e.pointerId)}
function spMove(e){const sp=cs.sp;if(!sp.dr)return;const dx=e.clientX-sp.dr.x,dy=e.clientY-sp.dr.y;sp.dr.x=e.clientX;sp.dr.y=e.clientY;
  if(sp.dr.item){const it=sp.dr.item,l=it.l;sp.dr.moved=true;
    if(sp.dr.alt){l.depth=clampv(Math.round((l.depth||0)-dy*2),-800,800);stLayerSync()}
    else{const inv=mmul(mRy(-sp.yaw),mRx(sp.pitch)),d=mApply(inv,dx/sp.k,dy/sp.k,0);it.ox+=d.x;it.oy+=d.y}
    spReq();return}
  if(sp.dr.pan){const inv=mmul(mRy(-sp.yaw),mRx(sp.pitch)),d=mApply(inv,-dx/sp.k,-dy/sp.k,0);sp.t=[sp.t[0]+d.x,sp.t[1]+d.y,sp.t[2]+d.z]}
  else{sp.yaw=sp.yaw+dx*.4;sp.pitch=clampv(sp.pitch-dy*.4,-89,89)}spReq()}
function spUp(){const sp=cs&&cs.sp;if(!sp||!sp.dr)return;const d=sp.dr;sp.dr=null;if(!d.item||!d.moved)return;const it=d.item,l=it.l;
  if(!d.alt&&(it.ox||it.oy)){l.x=Math.round(l.x+it.ox);l.y=Math.round(l.y+it.oy);it.ox=it.oy=0;sp.prepSid=null}
  cs.scenes.delete(deck.slides[deck.cur].id);camCommit('Di chuyển layer trong không gian');spDraw()}
function stLayerSync(){if(!cs)return;const l=stCurLayer();if(!l)return;cs.side.querySelectorAll('input[data-lk]').forEach(i=>{const k=i.dataset.lk,v=l[k]||0;i.value=v;const o=i.nextElementSibling;if(o)o.textContent=v+CAMR_U[k]})}
const CAMR_U={depth:'px',tiltX:'°',tiltY:'°'};

/* ---- bảng "Layer & chuyển động" trong studio ---- */
const stLayers=()=>exportOrder().filter(l=>!l.clipTo).slice().reverse();
const stCurLayer=()=>stLayers().find(l=>l.id===cs.ls)||null;
function stLayerSide(){const L=stLayers();let l=L.find(x=>x.id===cs.ls)||L[0];cs.ls=l?l.id:null;
  const list=`<div class="lyl">${L.map(x=>`<button class="lyi${l&&x.id===l.id?' on':''}" data-ly="${x.id}"><span>${esc(x.name)}</span>${x.anim?'<i title="Có chuyển động">●</i>':''}</button>`).join('')||'<div class="empty">Slide chưa có layer.</div>'}</div>`;
  if(!l)return list;
  const a=l.anim||ANDEF(),m=deck.slides[deck.cur].cam.mode,op=(arr,v)=>arr.map(t=>`<option value="${t[0]}" ${v===t[0]?'selected':''}>${t[1]}</option>`).join('');
  const rs=(k,lab,mn,mx,v)=>`<div class="rng"><span>${lab}</span><input type="range" data-lk="${k}" min="${mn}" max="${mx}" step="1" value="${v}"><output>${v}${CAMR_U[k]}</output></div>`;
  const num=(k,lab)=>`<label class="fld2">${lab} <input type="number" data-an="${k}" step=".1" min="0" max="60" value="${a[k]}"> s</label>`;
  return list+`<h4 class="lyh">Vị trí trong không gian</h4>`+(m==='2d'?'<div class="empty" style="margin:0">Slide 2D nên độ sâu và nghiêng chưa có tác dụng. Đổi sang 2.5D hoặc 3D.</div>':'')
   +rs('depth','Độ sâu Z',-800,800,l.depth||0)+rs('tiltX','Nghiêng X',-80,80,l.tiltX||0)+rs('tiltY','Nghiêng Y',-80,80,l.tiltY||0)
   +`<h4 class="lyh">Chuyển động của layer</h4>
   <div class="anr"><label>Vào</label><select data-an="in">${op(AN_IN,a.in)}</select></div><div class="anr2">${num('inD','Trễ')}${num('inL','Dài')}<select data-an="inE" aria-label="Nhịp">${op(EASES,a.inE)}</select></div>
   <div class="anr"><label>Ra</label><select data-an="out">${op(AN_IN,a.out)}</select></div><div class="anr2">${num('outD','Trước cuối')}${num('outL','Dài')}<select data-an="outE" aria-label="Nhịp">${op(EASES,a.outE)}</select></div>
   <div class="anr"><label>Lặp</label><select data-an="loop">${op(AN_LOOP,a.loop)}</select></div><div class="rng"><span>Tốc độ</span><input type="range" data-an="loopS" min=".2" max="4" step=".1" value="${a.loopS}"><output>${a.loopS}×</output></div>
   <div class="row"><button class="btn pri" data-a="lyplay">▶ Xem thử</button><button class="btn" data-a="lystag" title="Áp kiểu Vào này cho mọi layer, lần lượt từ dưới lên">Lần lượt cho tất cả</button><button class="btn" data-a="lyclr">Xóa</button></div>
   <p class="ohint" style="margin-top:8px">Thời gian tính từ lúc camera bắt đầu chạy của slide. Trong chế độ Không gian: bấm vào layer để chọn, kéo để dời, Alt+kéo để đổi độ sâu.</p>`}
function stSide(){if(!cs)return;cs.side.innerHTML=`<div class="chips" style="margin-bottom:10px"><button class="chip ${cs.tab==='cam'?'on':''}" data-tab="cam">Camera</button><button class="chip ${cs.tab==='layer'?'on':''}" data-tab="layer">Layer & chuyển động</button></div>`+(cs.tab==='layer'?stLayerSide():stCamSide())}
function setAnim(k,v){const l=stCurLayer();if(!l)return;const a=l.anim||ANDEF();a[k]=/^(in|out|loop|inE|outE)$/.test(k)?v:parseFloat(v)||0;l.anim=a;tidyAnim(l);commit(false,'Chuyển động layer');tlRender();stShow(cs.T);if(/^(in|out|loop)$/.test(k))stSide()}
function stagAll(){const l=stCurLayer();if(!l)return;const t=(l.anim&&l.anim.in)||'fade';applyMotion(deck.slides[deck.cur],t==='none'?'fade':t);commit(true,'Chuyển động lần lượt');tlRender();stShow(cs.T);stSide()}
function clrAnim(){const l=stCurLayer();if(!l)return;delete l.anim;commit(false,'Xóa chuyển động');tlRender();stShow(cs.T);stSide()}

/* ---- Chuyển thành slide ---- */
function syncSlideBtn(){const b=$('#slideBtn');if(!b)return;const t=deck?ic('layers')+' Camera':ic('layers')+' Thành slide';if(b.dataset.t!==t){b.dataset.t=t;b.innerHTML=t}}
function slideDialog(){if(deck){openCam();return}
  let mode='2.5d',mo='fade';const MO=[['none','Không'],['fade','Hiện dần lần lượt'],['slideU','Trượt vào lần lượt'],['rise','Bay từ chiều sâu'],['pop','Nảy lần lượt']];
  const m=modal(`<h2>Chuyển thành slide</h2><p style="margin-bottom:12px">Thiết kế này trở thành slide 1. Mỗi layer là một tấm riêng trong không gian: bạn đặt camera, độ sâu và chuyển động cho từng layer, rồi xuất video hoặc gửi sang Bravin.</p>
   <div class="ohint" style="margin-bottom:5px">Kiểu camera</div><div class="chips" id="sdm" style="margin-bottom:12px">${[['2d','2D phẳng'],['2.5d','2.5D chiều sâu nhẹ'],['3d','3D tự do']].map(x=>`<button class="chip ${x[0]===mode?'on':''}" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>
   <div class="ohint" style="margin-bottom:5px">Chuyển động layer lúc vào</div><div class="chips" id="sdo" style="margin-bottom:12px">${MO.map(x=>`<button class="chip ${x[0]===mo?'on':''}" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>
   <label class="fld2" style="margin-bottom:14px">Thời lượng slide <input type="number" id="sdd" min="2" max="60" step=".5" value="6"> s</label>
   <div class="row" style="justify-content:flex-end"><button class="btn" data-a="x">Hủy</button><button class="btn pri" data-a="go">Chuyển thành slide</button></div>`);
  m.querySelector('.card').style.cssText+=';width:min(520px,94vw)';
  m.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
    if(b.dataset.v){const box=b.parentNode;box.querySelectorAll('.chip').forEach(c=>c.classList.toggle('on',c===b));if(box.id==='sdm')mode=b.dataset.v;else mo=b.dataset.v;return}
    if(b.dataset.a==='x'){m.remove();return}
    if(b.dataset.a==='go'){const dur=clampv(parseFloat(m.querySelector('#sdd').value)||6,2,60);m.remove();convertToDeck();const s=deck.slides[0];s.dur=dur;s.cam.mode=mode;
      if(mode!=='2d')autoDepth(s);const p=CAMP[mode]&&CAMP[mode][0];if(p){s.cam.start={...CAMD,...p[1]};s.cam.end={...CAMD,...p[2]}}
      applyMotion(s,mo);commit(true,'Chuyển thành slide');openCam(0)}})}

/* ---------- boot ---------- */
setTool('select');syncDocUi();refresh();fit();setPa('sw');syncSw();
const fontsReady=Promise.all(FONTS.flatMap(f=>[400,500,700].map(w=>document.fonts.load(`${w} 40px "${f}"`).catch(()=>0)))).then(()=>{render();renderLayers()});
initHome();
document.fonts.ready.then(()=>{render();renderLayers()});
